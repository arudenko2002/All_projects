#scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/velocity_update_daily.py alexey.rudenko2002@205.209.184.35.bc.googleusercontent.com:/tmp/
#scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/ArchiveCollection/archive_operators.py alexey.rudenko2002@205.209.184.35.bc.googleusercontent.com:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/velocity_update_daily.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/velocity_update_daily_apple.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/velocity_operators.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/common_operators.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/gcs_operators.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
scp -i mykeygen /Users/rudenka/workspace/ArchiveCollection/src/Velocity_Queries/test_gcs.py alexey.rudenko2002@swift-airflow.umusic.net:/tmp/
