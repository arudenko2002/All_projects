#!/bin/bash

start=$1
end=$2

i=$start
while [ $i -le $end ]
do
  date=$((1000+$i))"-01-01"
  date_nodash=$((1000+$i))"0101"
  echo $date
  ./$3 $date $date_nodash `date +%Y-%m-%d`
  
  i=$(($i+1))
done