#!/bin/bash
bq --nosync query --batch --allow_large_results --replace --nouse_legacy_sql --destination_table umg-dev:swift_trends.isrc_first_stream_date "$(cat sql/isrc_first_stream_date.sql)"