#!/bin/bash

#partition date in format "YYYY-MM-DD"
partitionDate=$1

#the table is partitioned by day_since_first_stream
#which is integer from 0 to 365. This number is encoded
#in last 3 digits of the partition date.
#so all the records for day 5 will be stored in 1005-01-01,
#and for day 240 in 1240-01-01

#extract day_since_first_stream from partition_date
daySinceFirstStream=${partitionDate:1:3}

bq --nosync query --batch --allow_large_results --replace --nouse_legacy_sql --parameter daySinceFirstStream:STRING:$daySinceFirstStream --destination_table umg-dev:swift_trends.track_archive\$$2 "$(cat sql/track_archive.sql)"