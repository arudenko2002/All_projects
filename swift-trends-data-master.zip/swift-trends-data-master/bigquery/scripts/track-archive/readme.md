## Scripts for building Track Archive table
The purpose of the Track Archive table is to compare tracks during their first few weeks of activity in Spotify. Since the most meaningful period for a track is first weeks since release date, it makes sense to store track daily history along the  normalized date axis, where all activity starts from day 0 and continues to day 365 rather than attached to an actual date. 

### Location

Development: `umg-dev.swift-trends.track_archive`


### Schema

* isrc	
* first_stream_date	
* stream_date
* day_since_first_stream
* user_country_code	
* user_country_name	
* stream_source	
* total_stream_count	
* lean_back_stream_count	
* lean_forward_stream_count	
* load_datetime

### Partitioning

The table is partitioned by `day_since_first_stream` column. Since BigQuery allows partitioning only by date and `day_since_first_stream` column in integer from 0 to 365, we store this integer in last three digits of the year in partition date. 

For example:

* 1000-01-01 represents day 0 of streaming activity
* 1055-01-01: represents day 55 of streaming activity
* 1365-01-01: represents day 365 of streaming activity

To get data for the first 6 weeks (42 days) of streaming activity the following SQL could be used:


```
select isrc, day_since_first_stream, sum(total_stream_count) as total_stream_count
from swift_trends.track_archive
where _partitiontime between timestamp('1000-01-01') 
                     and timestamp('1042-01-01')
       and isrc in ('USUM71404572', 'GBUM71401775')
group by isrc, day_since_first_stream
order by day_since_first_stream, isrc

```

### Building the table

#### Steps Overview

The track archive table is built in a few consequential steps.

1. Creating `isrc_first_stream_date` table that contains the date of the first stream for each track

* isrc
* first_stream_date

2. Create `track_archive_by_stream_date` table, which is the same as `track_archive` table only partitioned by `stream_date` (actual date of the stream). 

3. Repartition `track_archive_by_stream_date` table by `day_since_first_stream` column and store results in the final `track_archive` table.

#### Executing Scripts

Execute the following scripts in sequence

```
$ ./create_tables.sh

```

This will create two empty partitioned tables: `track_archive_by_stream_date` and `track_archive`

```
$ ./create_isrc_first_stream_date.sh

```

This will create and populate `isrc_first_stream_date` table which will contain date of a first stream for every ISRC.


```
$ ./partition_loop_mac_os.sh '2013-09-01' '2017-04-20' track_archive_by_stream_date.sh

```

This will create a matching partition in `track_archive_by_stream_date` table from corresponding partition in `umg-partner.spotify.streams` table for the specified range of dates.

```
$ ./int_loop.sh 0 365 track_archive.sh

```
This will repartition the `track_archive_by_stream_date` table by `day_since_first_stream` column and store results in final `track_archive` table partitioned as 1000-01-01, 1001-01-01, 1002-01-01 and so on, where last three digits of the year represent an integer day since first stream. 






