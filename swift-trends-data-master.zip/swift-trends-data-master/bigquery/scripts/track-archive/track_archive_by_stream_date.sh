#!/bin/bash
partitionDate=$1
bq --nosync query --batch --allow_large_results --replace --nouse_legacy_sql --parameter datePartition:STRING:$partitionDate --destination_table umg-dev:swift_trends.track_archive_by_stream_date\$$2 "$(cat sql/track_archive_by_stream_date.sql)"