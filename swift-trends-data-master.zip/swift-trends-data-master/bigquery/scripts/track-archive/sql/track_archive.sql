select * 
from `umg-dev.swift_trends.track_archive_by_stream_date`
where day_since_first_stream = cast(@daySinceFirstStream as int64)