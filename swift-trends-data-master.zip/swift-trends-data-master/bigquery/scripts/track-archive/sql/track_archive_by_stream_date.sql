SELECT 
s.isrc as isrc, 
fsd.first_stream_date as first_stream_date, 
s.stream_date as stream_date,
date_diff(s.stream_date, fsd.first_stream_date, DAY) as day_since_first_stream,
s.user_country_code as user_country_code, 
s.user_country_name as user_country_name, 
s.stream_source as stream_source,
count(user_id) as total_stream_count, 
count(case when engagement_style = 'Lean Back' then 1 end) as lean_back_stream_count, 
count(case when engagement_style = 'Lean Forward' then 1 end) as lean_forward_stream_count, 
current_timestamp() as load_datetime 
from (
  select * FROM `umg-partner.spotify.streams` 
  where _PARTITIONTIME = timestamp(@datePartition)) s 
inner join `umg-dev.swift_trends.isrc_first_stream_date` fsd on s.isrc = fsd.isrc
where date_diff(s.stream_date, fsd.first_stream_date, DAY) <= 365
group by
isrc, 
first_stream_date,
stream_date,
day_since_first_stream,
user_country_code, 
user_country_name,
stream_source