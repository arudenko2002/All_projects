select isrc, min(stream_date) as first_stream_date
from `umg-partner.spotify.daily_track_history`
group by isrc