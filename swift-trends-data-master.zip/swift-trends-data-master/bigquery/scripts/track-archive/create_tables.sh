#!/bin/bash
bq mk --time_partitioning_type=DAY umg-dev:swift_trends.track_archive_by_stream_date