# swift-trends-data
Data for Swift Trends application on Google Cloud BigQuery + BigTable 
