# swift-dizzee-mongodb
MongogDB Setup and Tools for Swift and Dizzee

## Table of Contents

- [Cluster Connections](https://github.com/umg/swift-dizzee-mongodb/wiki/Mongo-Clusters-Details)
- [Copying a database](https://github.com/umg/swift-dizzee-mongodb/blob/master/README.md#copying-a-database)
- [Exporting/importing data](https://github.com/umg/swift-dizzee-mongodb/blob/master/README.md#exportingimporting-data)

### Copying a database

1. Open the `mongo` client or an app like RoboMongo.

2. Connect to the Mongo server you want to copy the database to.

2. Enter the following Mongo query:

```
   db.copyDatabase(<from_db>, <to_db>, <from_hostname>, <username>, <password>);
```

Where:
- `<from_db>` is the database you want to copy.
- `<to_db>` is the name of the new database.
- `<from_hostname>` is the Mongo URI of the database you want to copy (if it's on a different server). (Optional)
- `<username>` is the username for the database you want to copy. (Optional)
- `<password>` is the password for the database you want to copy. (Optional)

### Exporting/importing data

The recommended way to import and export MongoDB data is via the `mongodump` and `mongorestore` commands, as these will preserve the data's BSON format.

Note: These commands can be performed on your local machine; however, for speed purposes it is more efficient to [SSH into a Mongo instance]((https://console.cloud.google.com/deployments/details/umg-swift-dev-mongodb?project=umg-dev)) and handle the exporting/importing from there.

1. To export data, use the `mongodump` command:

```
   mongodump --host <mongo_uri> --username <username> --password <password> --authenticationDatabase <auth_db> --db <db_name> --collection <collection_name>
```

Where:
- `<mongo_uri>` is the URI of the Mongo instance
- `<username>` is the username for the database you want to export.
- `<password>` is the password for the database you want to export.
- `<auth_db>` is the same as the database you want to export.
- `<db_name>` is the database you want to export.
- `<collection_name>` is the collection you want to export. (Optional)

The `mongodump` command will export the data and place it in a folder called `dump` in whichever directory you ran the command from.

2. To import data, use the `mongorestore` command:

```
   mongorestore --host <mongo_uri> --username <username> --password <password> --authenticationDatabase <auth_db>  --db <db_name> --collection <collection_name> <path_to_exported_data>
```

Where:
- `<mongo_uri>` is the URI of the Mongo instance
- `<username>` is the username for the database you want to export.
- `<password>` is the password for the database you want to export.
- `<auth_db>` is the same as the database you want to export.
- `<db_name>` is the database you want to export.
- `<collection_name>` is the collection you want to export. (Optional)
- `<path_to_exported_data>` is the path to the BSON files created by `mongodump`.
