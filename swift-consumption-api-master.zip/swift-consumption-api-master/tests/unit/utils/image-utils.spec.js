import { describe, it } from 'mocha';
import { expect } from 'chai';
import { checkForImage, getArtistImage } from '../../../src/lib/utils/image-utils';

const artist = 'Jenni Rivera';
const id = '10001184';

describe('Image Utils', () => {

  describe('getArtistImage', () => {
    it('should return image URL', () => {
      expect(getArtistImage(artist, id)).to.equal('');
      
    });
    
  });



});
