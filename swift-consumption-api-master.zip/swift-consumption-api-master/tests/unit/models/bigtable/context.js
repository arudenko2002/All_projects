
import settings from '../../../../src/config';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../../../../src/data/connectors/bigtable';
import { MongoDbConnector, dbcon } from '../../../../src/data/connectors/mongodb';
import { BigTableModels } from '../../../../src/data/models/bigtable';
import { MongoDbModels } from '../../../../src/data/models/mongodb';
import NodeCache from 'node-cache';

/*
  Settings
*/
const { bigtable, mongo } = settings;

/*
  Connector to BigTable
*/

const btOptions = btPrepareOpts(bigtable);
const btConnector = new BigTableConnector(btOptions);
const btModels = new BigTableModels({ connector: btConnector });

/*
  Connector to MongoDB
*/
const mongoConnector = new MongoDbConnector(mongo);
const mongoModels = new MongoDbModels({ connector: mongoConnector });

/*
  Metadata Cache
*/
const metadataCache = new NodeCache( { stdTTL: 300 } );


/*
  Context
*/
const context = {
      bt: btModels,
      mongodb: mongoModels,
      metadataCache: metadataCache
};

export { context, btConnector };

