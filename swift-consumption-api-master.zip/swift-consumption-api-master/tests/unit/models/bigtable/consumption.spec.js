import { inspect } from 'util';
import { describe, it } from 'mocha';
import { expect } from 'chai';
import settings from '../../../../src/config';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../../../../src/data/connectors/bigtable';
import { Consumption } from '../../../../src/data/models/bigtable/consumption';
import NodeCache from 'node-cache';
import { MongoDbConnector } from '../../../../src/data/connectors/mongodb';
import { MongoDbModels } from '../../../../src/data/models/mongodb';

/*
  Settings
*/
const { bigtable, mongo } = settings;

/*
  Connector to BigTable
*/

const btOptions = btPrepareOpts(bigtable);
const btConnector = new BigTableConnector(btOptions);

/*
  Connector to Mongo
*/
var mongoConnector;
var mongoModels; 

/*
  Context
*/

const metadataCache = new NodeCache( { stdTTL: 300 } );

var context;

/*
  Parameters
*/

var dateRange;
var filters;
var select;
var groups;
var key;

/*
  Unit Test
*/


var consumption; 

describe('Consumption BigTable Model', function () {

  this.timeout(10000);

  beforeEach('Create Consumption object', () => {
      consumption = new Consumption(btConnector, btConnector.tableNames.artist);
    });


  describe('Constructor', () => {

    it('Should create an object', () => {

      expect(consumption).not.to.be.empty;
      expect(consumption.connector).not.to.be.empty;
      expect(consumption.table).not.to.be.empty;
    
    });

    it('Should connect to BigTable', async () => {
      
      expect(await consumption.testConnect()).to.be.true;

    });

  });

  describe('Empty filter query options', () => {

    before('Set filters to empty', () => {
      filters = {};
    });

    it('Should prepare empty filters', () => {
      const filterKeys = consumption.filterToKeys(filters);
      expect(filterKeys.partner).to.deep.equal(['ALL']);
      expect(filterKeys.territory).to.deep.equal(['A#ALL']);
      expect(filterKeys.genre).to.deep.equal(['ALL']);
      expect(filterKeys.label).to.deep.equal(['A#ALL']);
    });

  });

  describe('Filter query options with some empty values', () => {

    before('Set some filters to empty', () => {
      filters = { 
        partners: ['1234'], 
        territories: [{type: 'Region', id: '63'}] 
      };
    });

    it('Should prepare empty filters', () => {
      const filterKeys = consumption.filterToKeys(filters);
      expect(filterKeys.partner).to.deep.equal(['1234']);
      expect(filterKeys.territory).to.deep.equal(['R#63']);
      expect(filterKeys.genre).to.deep.equal(['ALL']);
      expect(filterKeys.label).to.deep.equal(['A#ALL']);
    });

  });

  describe('Filter query options with all values selected', () => {

    before('Set some filters to empty', () => {
      filters = { 
        partners: ['1234'], 
        territories: [{type: 'Region', id: '63'}],
        genres: ['GHH'],
        labels: [{type: 'Segment', id: 'GER01'}]
      };
    });

    it('Should prepare empty filters', () => {
      const filterKeys = consumption.filterToKeys(filters);
      expect(filterKeys.partner).to.deep.equal(['1234']);
      expect(filterKeys.territory).to.deep.equal(['R#63']);
      expect(filterKeys.genre).to.deep.equal(['GHH']);
      expect(filterKeys.label).to.deep.equal(['S#GER01']);
    });

  });


  describe('Date Range Daily', () => {

    before('Set daily date range', () => {
      dateRange = {
        precision: 'Day',
        startDate: {
          year: '2016',
          month: '08',
          day: '01'
        },
        endDate: {
          year: '2016',
          month: '08',
          day: '02'
        }
      };
    });

    it('Should return daily date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('D#20160801');
      expect(dateRangeKeys.end).to.equal('D#20160802');
    });

  });

  describe('Date Range Weekly', () => {

    before('Set weekly date range', () => {
      dateRange = {
        precision: 'Week',
        startDate: {
          year: '2016',
          week: '30'
        },
        endDate: {
          year: '2016',
          week: '31'
        }
      };
    });

    it('Should return weekly date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('W#201630');
      expect(dateRangeKeys.end).to.equal('W#201631');
    });

  });

  describe('Date Range Monthly', () => {

    before('Set monthly date range', () => {
      dateRange = {
        precision: 'Month',
        startDate: {
          year: '2016',
          month: '07'
        },
        endDate: {
          year: '2016',
          month: '08'
        }
      };
    });

    it('Should return monthly date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('M#201607');
      expect(dateRangeKeys.end).to.equal('M#201608');
    });

  });

  describe('Date Range Quarterly', () => {

    before('Set quarterly date range', () => {
      dateRange = {
        precision: 'Quarter',
        startDate: {
          year: '2016',
          quarter: '03'
        },
        endDate: {
          year: '2016',
          quarter: '04'
        }
      };
    });

    it('Should return quarterly date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('Q#201603');
      expect(dateRangeKeys.end).to.equal('Q#201604');
    });

  });

  describe('Date Range Yearly', () => {

    before('Set yearly date range', () => {
      dateRange = {
        precision: 'Year',
        startDate: {
          year: '2016'
        },
        endDate: {
          year: '2016'
        }
      };
    });

    it('Should return yearly date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('Y#2016');
      expect(dateRangeKeys.end).to.equal('Y#2016');
    });

  });

   describe('Date Range All (RTD)', () => {

    before('Set all date range', () => {
      dateRange = {
        precision: 'All',
        startDate: {
          year: '2016'
        },
        endDate: {
          year: '2016'
        }
      };
    });

    it('Should return all date range', () => {
      const dateRangeKeys = consumption.dateRangeToKeys(dateRange);
      expect(dateRangeKeys.start).to.equal('A#ALL');
      expect(dateRangeKeys.end).to.equal('A#ALL');
    });

  });

  describe('Build key ranges', () => {

    before('Set filters and date range', () => {
      
      dateRange = {
        precision: 'Day',
        startDate: {
          year: '2016',
          month: '08',
          day: '01'
        },
        endDate: {
          year: '2016',
          month: '08',
          day: '02'
        }
      };

      filters = { 
        partners: ['1234'], 
        territories: [{type: 'Region', id: '63'}],
        labels: [{type: 'Segment', id: 'GER01'}]
      };


    });

    it('Should return key ranges', () => {
      const keyRanges = consumption.buildKeyRanges(filters, dateRange);
      expect(keyRanges).not.to.be.empty;
      expect(keyRanges).to.have.length.above(0);
      expect(keyRanges[0]).to.deep.equal({
        start: 'R#63#1234#S#GER01#D#20160801#',
        end: 'R#63#1234#S#GER01#D#20160803#'
      });
    });

  });

  describe('Build BT Read Options', () => {

    before('Set filters, date range and groups', () => {
      
      dateRange = {
        precision: 'Day',
        startDate: {
          year: '2016',
          month: '08',
          day: '01'
        },
        endDate: {
          year: '2016',
          month: '08',
          day: '02'
        }
      };

      filters = { 
        partners: ['1234'], 
        territories: [{type: 'Region', id: '63'}],
        genres: ['GHH'],
        labels: [{type: 'Segment', id: 'GER01'}]
      };

      select = [{prop: 'AudioStreamUnits'}, {prop: 'AudioStreamAdjustedUnits'}];

      groups = [{type: 'Partner', sort: [{prop: 'AllUnits', ordering: 'Desc'}]}];


    });

    it('Should return BT read options', async () => {

      const btReadOptions = await consumption.buildBtReadOptions(filters, dateRange, '', select, groups, context);
      expect(btReadOptions).not.to.be.empty;
      expect(btReadOptions).to.be.deep.equal(
        { ranges: [ { start: 'R#63#1234#S#GER01#D#20160801#',
                      end: 'R#63#1234#S#GER01#D#20160803#' } ],
          filter: [ 
            { interleave: [ 
              [ { family: 'audio_stream_units' }, { column: RegExp('\\C*pr\\C*') } ],
              [ { family: 'audio_stream_track_adjusted_units' },
              { column: RegExp('\\C*pr\\C*') } ] 
              ] } ] });
      console.log(inspect(btReadOptions, false, null, false));
  
    });

  });

  describe('Substitute keys for required precision', () => {

    before('Set filters, date range and groups', async () => {

      key = 'R#63#1234#S#GER01#M#201607#';

      mongoConnector = new MongoDbConnector(mongo);
      await mongoConnector.connect();
      mongoModels = new MongoDbModels({ connector: mongoConnector });


      context =  {
        mongodb: mongoModels,
        metadataCache: metadataCache
      };


    });

    it('Should return modified key', async () => {
      
       const modifiedKey = consumption.substituteKeyForPrecision(context, key, 'Month', 'Quarter', 5);
       expect(modifiedKey).to.equal('R#63#1234#S#GER01#Q#201603#');
    });

  });
});