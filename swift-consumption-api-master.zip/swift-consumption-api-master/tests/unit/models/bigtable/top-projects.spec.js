import { describe, it } from 'mocha';
import { expect } from 'chai';
import settings from '../../../../src/config';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../../../../src/data/connectors/bigtable';
import { TopProjects } from '../../../../src/data/models/bigtable/top-projects';
import NodeCache from 'node-cache';
import { MongoDbConnector } from '../../../../src/data/connectors/mongodb';
import { MongoDbModels } from '../../../../src/data/models/mongodb';


/*
  Settings
*/
const { bigtable, mongo} = settings;

/*
  Connector to BigTable
*/

const btOptions = btPrepareOpts(bigtable);
const btConnector = new BigTableConnector(btOptions);

/* 
  Connector to Mongo
*/
const mongoConnector = new MongoDbConnector(mongo);
const mongoModels = new MongoDbModels({ connector: mongoConnector });


const metadataCache = new NodeCache( { stdTTL: 300 } );

/*
  Context
*/
const context =  {
  mongodb: mongoModels,
  metadataCache: metadataCache
};


var interval;
var filters;
var paging;
var keyVals;


var topProjects;

describe('Top Projects Consumption BigTable Model', function () {

  this.timeout(10000);

  beforeEach('Create TopProjects object', () => {
      topProjects = new TopProjects(btConnector);
    });


  describe('Constructor', () => {

    it('Should create an object', () => {
      
      expect(topProjects).not.to.be.empty;
      expect(topProjects).not.to.be.empty;
      expect(topProjects.table).not.to.be.empty;
    
    });

    it('Should connect to BigTable', async () => {

      expect(await topProjects.testConnect()).to.be.true;

    });

  });

  

  describe('Execute query', () => {

    before('Set interval, filters and paging', async () => {

      interval = {
        period: 'Month',
        date: {
          year: '2016',
          month: '07'
        }
      };

      filters = { 
        partners: [], 
        territories: [],//[{type: 'Region', id: '63'}],
        genres: ['GHH'],
        labels: [],//[{type: 'Segment', id: 'GER01'}]
        catalogue: 'Yes'
      };

      paging = {
        skip: 0,
        limit: 25
      };


    });

    it('Should return data', async () => {
       const data = await topProjects.executeQuery(context, interval, filters, paging);
       //console.log(JSON.stringify(data));
       expect(data).not.to.be.empty;
       expect(data).length.to.be.above(0);
       
      
    });

  });

});