import { describe, it } from 'mocha';
import { expect } from 'chai';
import settings from '../../../../src/config';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../../../../src/data/connectors/bigtable';
import { ProjectConsumption } from '../../../../src/data/models/bigtable/project-consumption';
import NodeCache from 'node-cache';
import { MongoDbConnector } from '../../../../src/data/connectors/mongodb';
import { MongoDbModels } from '../../../../src/data/models/mongodb';


/*
  Settings
*/
const { bigtable, mongo} = settings;

/*
  Connector to BigTable
*/

const btOptions = btPrepareOpts(bigtable);
const btConnector = new BigTableConnector(btOptions);

/* 
  Connector to Mongo
*/
const mongoConnector = new MongoDbConnector(mongo);
const mongoModels = new MongoDbModels({ connector: mongoConnector });


const metadataCache = new NodeCache( { stdTTL: 300 } );

/*
  Context
*/
const context =  {
  mongodb: mongoModels,
  metadataCache: metadataCache
};

/*
  Parameters
*/
const artistId = '10087148'; //Tove Lo'
const projectId = '11749582'; //Queen of the Clouds

var project = {
  id: projectId, 
  artist: {
    id: artistId
  }
};

var dateRange;
var filters;
var select;
var groups;
var keyVals;
var outputPrecision;

var consumption;

describe('Project Consumption BigTable Model', function () {

  this.timeout(10000);

  beforeEach('Create Consumption object', () => {
      consumption = new ProjectConsumption(btConnector);
    });


  describe('Constructor', () => {

    it('Should create an object', () => {
      
      expect(consumption).not.to.be.empty;
      expect(consumption.connector).not.to.be.empty;
      expect(consumption.table).not.to.be.empty;
    
    });

    it('Should connect to BigTable', async () => {

      expect(await consumption.testConnect()).to.be.true;

    });

  });

  describe('Build key ranges', () => {

    before('Set filters and date range', () => {
      
      dateRange = {
        precision: 'Day',
        startDate: {
          year: '2016',
          month: '08',
          day: '01'
        },
        endDate: {
          year: '2016',
          month: '08',
          day: '02'
        }
      };

      filters = { 
        partners: ['1234'], 
        territories: [{type: 'Region', id: '63'}],
        labels: [{type: 'Segment', id: 'GER01'}]
      };

      keyVals = {
        artistId
      };


    });

    it('Should return key ranges', () => {
      const keyRanges = consumption.buildKeyRanges(filters, dateRange, keyVals);
      expect(keyRanges).not.to.be.empty;
      expect(keyRanges).to.have.length.above(0);
      expect(keyRanges[0]).to.deep.equal({
        start: '10087148#R#63#1234#S#GER01#D#20160801#',
        end: '10087148#R#63#1234#S#GER01#D#20160803#'
      });
    });

  });

  describe('Execute details query', () => {

    before('Set filters, date range and groups', async () => {

      dateRange = {
        precision: 'Month',
        startDate: {
          year: '2016',
          month: '07'
        },
        endDate: {
          year: '2016',
          month: '08'
        }
      };

      outputPrecision = 'Quarter';

      filters = { 
        partners: [], 
        territories: [],//[{type: 'Region', id: '63'}],
        genres: [],
        labels: []//[{type: 'Segment', id: 'GER01'}]
      };

      select = [{prop: 'StreamUnits'}, {prop: 'StreamAdjustedUnits'}];

      groups = [{type: 'Partner', sort: [{prop: 'AllUnits', ordering: 'Desc'}]}];


    });

    it('Should return data', async () => {
       const data = await consumption.executeDetailsQuery(context, project, dateRange, filters, select, groups, outputPrecision);
       //console.log(JSON.stringify(data));
       expect(data).not.to.be.empty;
       expect(data).length.to.be.above(0);
       
      
    });

  });

  describe('Execute artist projects query', () => {

    before('Set filters, date range and groups', async () => {

      dateRange = {
        precision: 'Month',
        startDate: {
          year: '2016',
          month: '07'
        },
        endDate: {
          year: '2016',
          month: '08'
        }
      };

      outputPrecision = 'Quarter';

      filters = { 
        partners: [], 
        territories: [],//[{type: 'Region', id: '63'}],
        genres: [],
        labels: []//[{type: 'Segment', id: 'GER01'}]
      };

      select = [{prop: 'AllUnits'}, {prop: 'AllAdjustedUnits'}];

      groups = [];


    });

    it('Should return data', async () => {
       const data = await consumption.artistProjects(context, artistId, dateRange, filters, select, groups, outputPrecision);
       console.log(JSON.stringify(data));
       expect(data).not.to.be.empty;
       expect(data).length.to.be.above(0);
       
      
    });

  });






});