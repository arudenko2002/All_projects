import settings from '../../../src/config';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../../../src/data/connectors/bigtable';
import { describe, it } from 'mocha';
import { expect } from 'chai';

const { bigtable } = settings;

const btOptions = btPrepareOpts(bigtable);
const btConnector = new BigTableConnector(btOptions);

describe('BigTable Connector', () => {

  describe('constructor', () => {
    it('should create a BigTable instance', () => {
      expect(btConnector.instance).to.exist;
    });
    it('should create an array of table names', () => {
      expect(btConnector._tables).to.exist;
    });
  });
  
  describe('get tableNames', () => {
    it('should return an object of table names', () => {
      expect(btConnector.tableNames).to.equal(btConnector._tables);
    });
  });

  describe('get table', () => {
    it('should return a table', () => {
      expect(btConnector.table('artist').id).to.match(/artist/);
    });
  });

});