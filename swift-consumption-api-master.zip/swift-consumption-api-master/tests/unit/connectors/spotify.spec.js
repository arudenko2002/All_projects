import { describe, it } from 'mocha';
import { expect } from 'chai';
import { Spotify } from '../../../src/data/connectors/spotify';
import { inspect } from 'util';

const spotify = new Spotify();
var isrc;
var albumSpotifyId;
var artistSpotifyId;

describe('Spotify API Connector', function () {

  this.timeout(3600000);

  describe('getToken', () => {
    it('should return OAuth token',  async () => {
      const token = await spotify.getToken();
      //console.log('Token: %s', inspect(token, false, null, false));
      expect(token).to.exist;
      expect(token).to.have.property('access_token');
      
    });
    
  });

  describe('getTrack',  () => {

    before('set isrc', () => {
      isrc = 'CAB391100633';
    });
  
    it('should return a track', async () => {
      const token = await spotify.getToken();
      const result = await spotify.getTrack(isrc, token.access_token);
      //console.log('Track: %s', inspect(result, false, null, false));
      expect(result).to.exist;
      expect(result).to.have.property('tracks');
      expect(result.tracks.items[0].artists[0].id).to.equal('68EB3QvNdVLkC7SAgDbHIR');
      expect(result.tracks.items[0].album.id).to.equal('737av5XsHhJigOC64BV6IY');
      expect(result.tracks.items[0].album.images[0].url).to.equal('https://i.scdn.co/image/c5fb0dbacc6705144c128c502bd450e3bda3887e');
      

    });

  });

  describe('getAlbum',  () => {

    before('set album spotifyId', () => {
      albumSpotifyId = '737av5XsHhJigOC64BV6IY';
    });
  
    it('should return an album', async () => {
      const token = await spotify.getToken();
      const result = await spotify.getAlbum(albumSpotifyId, token.access_token);
      //console.log('Album: %s', inspect(result.images, false, null, false));
      expect(result).to.exist;
      expect(result).to.have.property('images');
      expect(result.images[0].url).to.equal('https://i.scdn.co/image/c5fb0dbacc6705144c128c502bd450e3bda3887e');

    });

  });

  describe('getArtist',  () => {

    before('set artist spotifyId', () => {
      artistSpotifyId = '68EB3QvNdVLkC7SAgDbHIR';
    });
  
    it('should return an artist', async () => {
      const token = await spotify.getToken();
      const result = await spotify.getArtist(artistSpotifyId, token.access_token);
      //console.log('Artist: %s', inspect(result.images, false, null, false));
      expect(result).to.exist;
      expect(result).to.have.property('images');
      expect(result.images[0].url).to.equal('https://i.scdn.co/image/5fae4aa59f348195bc0a50ad8e3168b62c22650e');

    });

  });

 /*describe('429 error handling', () => {

    before('set artist spotifyId', () => {
      artistSpotifyId = '68EB3QvNdVLkC7SAgDbHIR';
    });

    it('should throw 429 error ', async () => {
      const token = await spotify.getToken();
      var count = 0;
      for (var i = 0; i < 2000000; i++) {
        try {
          const result = await spotify.searchItem('artist', 'abba', token.access_token);
          if (result && 
              result.artists.items &&
              result.artists.items.length)
              continue;
          else {
              console.log('Issue on iteration: %s. Response: %s',
                i,
                JSON.stringify(result));
              break;
          }
          
        }  
        catch (err) {
          console.log('Error: %s. Result: %s', 
            inspect(err, false, null, false), 
            inspect(result, false, null, false));
        }
      }

    });

  });*/




});
