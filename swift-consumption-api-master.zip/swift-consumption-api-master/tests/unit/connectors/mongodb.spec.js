import settings from '../../../src/config';
import { MongoDbConnector, dbcon } from '../../../src/data/connectors/mongodb';
import { describe, it } from 'mocha';
import { expect } from 'chai';

const { mongo } = settings;

const mongoConnector = new MongoDbConnector(mongo);

describe('MongoDB Connector', () => {

  describe('constructor', () => {
    it('should define the database pathname', () => {
      expect(mongoConnector.pathname).to.exist;
    });
    it('should define the database auth string', () => {
      expect(mongoConnector.auth).to.exist;
    });
    it('should define the Mongo URI', () => {
      expect(mongoConnector.mongoUri).to.exist;
    });
  });
  
  describe('connect()', () => {
    it('should connect to MongoDB', function * () {
      yield mongoConnector.connect();
      expect(dbcon).not.to.equal(null);
    });
  });

  describe('get collectionNames', () => {
    it('should return a list of collections', () => {
      expect(mongoConnector.collectionNames).to.equal(mongoConnector.collections);
    });
  });

  describe('collection()', () => {
    it('should return the requested collection', () => {
      expect(mongoConnector.collection('artists')).to.exist;
    });
  });
  
  describe('remapIdTo()', () => {

    let result = mongoConnector.remapIdTo({
      _id: '12345'
    }, 'id');

    it('should rename the \'_id\' property to \'id\'', () => {
      expect(result).to.have.ownProperty('id');
    });
  });

  describe('remapAndAppend()', () => {

    let result = mongoConnector.remapAndAppend({
      _id: '12345'
    }, {
      name: 'test'
    }, 'id');

    it('should rename the \'_id\' property to \'id\'', () => {
      expect(result).to.have.ownProperty('id');
    });
    
    it('should append the \'name\' property to the given object', () => {
      expect(result).to.have.ownProperty('name');
      expect(result.name).to.equal('test');
    });
  });

  describe('removeId()', () => {

    let result = mongoConnector.removeId({
      _id: '12345',
      name: 'test'
    });

    it('should remove the \'_id\' property', () => {
      expect(result).not.to.have.ownProperty('_id');
    });
  });

  describe('remapTo()', () => {

    let result = mongoConnector.remapTo({
      _id: '12345',
      name: 'test'
    }, 'name', 'title');

    it('should remap the \'name\' property to \'title\'', () => {
      expect(result).not.to.have.ownProperty('name');
      expect(result).not.to.have.ownProperty('name');
      expect(result).to.have.ownProperty('title');
    });

    it('should set the remapped property equal to the old property', () => {
      expect(result.title).to.equal('test');
    });
  });

});