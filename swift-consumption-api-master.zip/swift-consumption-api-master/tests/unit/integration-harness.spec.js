import { describe, it } from 'mocha';
import { expect } from 'chai';
import { config } from '../integration/config';
import { IntegrationTestHarness } from '../integration/harness';



const harness = new IntegrationTestHarness(
  config.startDate, 
  config.endDate,
  config.territories, 
  config.partners);

describe('Integration Test Harness Unit Test', () => {

  describe('Constructor', () => {

    it('Should return non-empty object', () => {
      expect(harness).to.be.not.empty;
    });

  });

  describe('getPeriod', () => {
    it('Should return correct Day period', () => {
      expect(harness.getPeriod('Day')).to.deep.equal({
        period: 'Day', 
        date: { 
          year: config.startDate.year,
          month: config.startDate.month,
          day: config.startDate.day
        }
      });
    }); 

    it('Should return correct Week period', () => {
      expect(harness.getPeriod('Week')).to.deep.equal({
        period: 'Week', 
        date: { 
          year: config.startDate.year,
          week: config.startDate.week
        }
      });
    });  

    it('Should return correct Month period', () => {
      expect(harness.getPeriod('Month')).to.deep.equal({
        period: 'Month', 
        date: { 
          year: config.startDate.year,
          month: config.startDate.month
        }
      });
    });  

    it('Should return correct Quarter period', () => {
      expect(harness.getPeriod('Quarter')).to.deep.equal({
        period: 'Quarter', 
        date: { 
          year: config.startDate.year,
          quarter: config.startDate.quarter
        }
      });
    });  

    it('Should return correct Year period', () => {
      expect(harness.getPeriod('Year')).to.deep.equal({
        period: 'Year', 
        date: { 
          year: config.startDate.year
        }
      });
    }); 

    it('Should return correct All period', () => {
      expect(harness.getPeriod('All')).to.deep.equal({
        period: 'All',
        date: { 
          year: config.startDate.year
        }
      });
    });   
  });

  describe('getRange', () => {
    it('Should return correct Day range', () => {
      expect(harness.getRange('Day')).to.deep.equal({
        precision: 'Day', 
        startDate: { 
          year: config.startDate.year,
          month: config.startDate.month,
          day: config.startDate.day
        },
        endDate: { 
          year: config.endDate.year,
          month: config.endDate.month,
          day: config.endDate.day
        }
      });
    }); 

    it('Should return correct Week range', () => {
      expect(harness.getRange('Week')).to.deep.equal({
        precision: 'Week', 
        startDate: { 
          year: config.startDate.year,
          week: config.startDate.week
        },
        endDate: { 
          year: config.endDate.year,
          week: config.endDate.week
        }
      });
    });  

    it('Should return correct Month period', () => {
      expect(harness.getRange('Month')).to.deep.equal({
        precision: 'Month', 
        startDate: { 
          year: config.startDate.year,
          month: config.startDate.month
        },
        endDate: { 
          year: config.endDate.year,
          month: config.endDate.month
        }
      });
    });  

    it('Should return correct Quarter period', () => {
      expect(harness.getRange('Quarter')).to.deep.equal({
        precision: 'Quarter', 
        startDate: { 
          year: config.startDate.year,
          quarter: config.startDate.quarter
        },
        endDate: { 
          year: config.endDate.year,
          quarter: config.endDate.quarter
        }
      });
    });  

    it('Should return correct Year period', () => {
      expect(harness.getRange('Year')).to.deep.equal({
        precision: 'Year', 
        startDate: { 
          year: config.startDate.year
        },
        endDate: { 
          year: config.endDate.year
        }
      });
    }); 

    it('Should return correct All period', () => {
      expect(harness.getRange('All')).to.deep.equal({
        precision: 'All',
        startDate: { 
          year: config.startDate.year
        },
        endDate: { 
          year: config.endDate.year
        }
      });
    });   

  });

  describe('getPeriodQueryVars', () => {
    it('Should return array of period query variables', () => {
      const vars = harness.getPeriodQueryVars();
      expect(vars).to.be.not.empty;
      expect(vars.length).to.be.greaterThan(0);
      expect(vars[0]).to.have.property('period');
      expect(vars[0]).to.have.property('date');
      expect(vars[0]).to.have.property('filters');
      expect(vars[0].filters).to.have.property('territories');
      expect(vars[0].filters).to.have.property('partners');

    });

  });

  describe('getRangeQueryVars', () => {
    it('Should return array of range query variables', () => {
      const vars = harness.getRangeQueryVars();
      expect(vars).to.be.not.empty;
      expect(vars.length).to.be.greaterThan(0);
      expect(vars[0]).to.have.property('precision');
      expect(vars[0]).to.have.property('startDate');
      expect(vars[0]).to.have.property('endDate');
      expect(vars[0]).to.have.property('filters');
      expect(vars[0].filters).to.have.property('territories');
      expect(vars[0].filters).to.have.property('partners');

    });

  });

  describe('getTopQueryVars', () => {
    it('Should return array of top query variables', () => {
      const vars = harness.getTopQueryVars(500);
      expect(vars).to.be.not.empty;
      expect(vars.length).to.be.greaterThan(0);
      expect(vars[0]).to.have.property('period');
      expect(vars[0]).to.have.property('date');
      expect(vars[0]).to.have.property('territories');
      expect(vars[0]).to.have.property('partners');
      expect(vars[0]).to.have.property('labels');
      expect(vars[0]).to.have.property('genres');
      expect(vars[0]).to.have.property('paging');
     

    });

  });

});