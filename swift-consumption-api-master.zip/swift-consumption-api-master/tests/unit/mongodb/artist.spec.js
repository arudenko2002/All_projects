import settings from '../../../src/config';
import { MongoDbConnector, dbcon } from '../../../src/data/connectors/mongodb';
import { Artist } from '../../../src/data/models/mongodb/artist';
import { beforeEach, describe, it } from 'mocha';
import { expect } from 'chai';
import { stub } from 'sinon';

const { mongo } = settings;
const mongoConnector = new MongoDbConnector(mongo);

describe('Artist MongoDB Model', () => {

  before(function * () {
    yield mongoConnector.connect();
  });

  describe('constructor', () => {

    it('should expose the MongoDB connector', () => {
      let artist = new Artist({ connector: mongoConnector });
      expect(artist.connector).to.equal(mongoConnector);
    });

    it('should expose the Artists collection', () => {
      let artist = new Artist({ connector: mongoConnector });
      expect(artist.collection).to.exist;
    });
  });

  describe('get()', () => {
    
    it('should return metadata when given an Artist ID', function * () {
      let artist = new Artist({ connector: mongoConnector });
      let result = yield artist.get('10041007');
      expect(dbcon).not.to.equal(null);
      expect(result).to.exist;
    });

    it('should return \'null\' if a given Artist ID returns no metadata', function * () {
      let artist = new Artist({ connector: mongoConnector });
      let result = yield artist.get('0');
      expect(dbcon).not.to.equal(null);
      expect(result).to.equal(null);
    });

  });

});