import { describe, it } from 'mocha';
import { expect } from 'chai';

import schemas from '../../../src/data/schemas';

describe('GraphQL Schemas', () => {

  it('should have a Year type', () => {
    expect(schemas._typeMap.Year).to.exist;
  });

  it('should have a Quarter type', () => {
    expect(schemas._typeMap.Quarter).to.exist;
  });

  it('should have a Month type', () => {
    expect(schemas._typeMap.Month).to.exist;
  });

  it('should have a Week type', () => {
    expect(schemas._typeMap.Week).to.exist;
  });

  it('should have a Day type', () => {
    expect(schemas._typeMap.Day).to.exist;
  });

  it('should have an Interval type', () => {
    expect(schemas._typeMap.Interval).to.exist;
  });

  it('should have a Query type', () => {
    expect(schemas._typeMap.Query).to.exist;
  });

  it('should have an IntervalInput type', () => {
    expect(schemas._typeMap.IntervalInput).to.exist;
  });

  it('should have a Period type', () => {
    expect(schemas._typeMap.Period).to.exist;
  });

  it('should have a CountDateInput type', () => {
    expect(schemas._typeMap.CountDateInput).to.exist;
  });

  it('should have a Sort type', () => {
    expect(schemas._typeMap.Sort).to.exist;
  });

  it('should have a FilterInput type', () => {
    expect(schemas._typeMap.FilterInput).to.exist;
  });

});