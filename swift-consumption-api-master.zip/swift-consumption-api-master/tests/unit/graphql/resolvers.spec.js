import { describe, it } from 'mocha';
import { expect } from 'chai';

import resolvers from '../../../src/data/resolvers/sst.js';

describe('GraphQL Resolvers', () => {

  it('should have a Year resolver', () => {
    expect(resolvers.Year).to.exist;
  });

  it('should have a Quarter resolver', () => {
    expect(resolvers.Quarter).to.exist;
  });

  it('should have a Month resolver', () => {
    expect(resolvers.Month).to.exist;
  });

  it('should have a Week resolver', () => {
    expect(resolvers.Week).to.exist;
  });

  it('should have a Day resolver', () => {
    expect(resolvers.Day).to.exist;
  });

  it('should have an Interval resolver', () => {
    expect(resolvers.Interval).to.exist;
  });

  it('should have a Range resolver', () => {
    expect(resolvers.Range).to.exist;
  });

  it('should have a Units resolver', () => {
    expect(resolvers.Units).to.exist;
  });

  it('should have an AdjustedUnits resolver', () => {
    expect(resolvers.AdjustedUnits).to.exist;
  });

  it('should have a Euro resolver', () => {
    expect(resolvers.Euro).to.exist;
  });

  it('should have a Counts resolver', () => {
    expect(resolvers.Counts).to.exist;
  });

  it('should have an Artist resolver', () => {
    expect(resolvers.Artist).to.exist;
  });

  it('should have a RankedArtist resolver', () => {
    expect(resolvers.RankedArtist).to.exist;
  });

  it('should have a Query resolver', () => {
    expect(resolvers.Query).to.exist;
  });

});