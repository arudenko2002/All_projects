import { describe, it } from 'mocha';
import { expect } from 'chai';
import { graphqlQuery } from '../graphql-client';
import { config } from '../config';
import { IntegrationTestHarness } from '../harness';
import { query } from './gql/track-range-total-query';
import jmespath from 'jmespath';

const trackId = '1016065356'; //Justin Bieber : Love Yourself


describe('Region Aggregations Test', function () {

  this.timeout(30000);

  describe('Region aggregation test', () => {

    const v = {
      precision: 'Day',
      startDate:{
        year:'2017',
        month: '08',
        day: '01'
      },
      endDate:{
        year:'2017',
        month: '09',
        day: '28'
      },
      filters: {
        territories:[
          {
            type: 'Region',
            id:'40'
          }],
        partners:[]
      }
    }

    const variables = {
      id: trackId,
      ...v
    }
    
    

    it('Should return track data', async () => {
      const response = await graphqlQuery(query, variables);
      const data = response.body.data;
      console.log(JSON.stringify(data));
      expect(data).not.equal.empty;
     
    });
  });
});