import { describe, it } from 'mocha';
import { expect } from 'chai';
import { graphqlQuery } from '../graphql-client';
import { config } from '../config';
import { IntegrationTestHarness } from '../harness';
import { query } from './gql/project-range-group-query';
import jmespath from 'jmespath';

const projectId = '11749582'; //Tove Lo - Queen of the Clouds


describe('Project Range Group Queries Integration Test', function () {

  this.timeout(10000);

  const harness = new IntegrationTestHarness(
    config.startDate,
    config.endDate,
    config.territories,
    []//config.partners
  );

  const vars = harness.getRangeQueryVars();

  vars.forEach( v => {
    describe('Period: ' + v.precision +
        ', Start Date: ' + JSON.stringify(v.startDate) + 
        ', End Date: ' + JSON. stringify(v.endDate) +
        ', Partners: ' + JSON.stringify(v.filters.partners) + 
        ', Territories: ' + JSON.stringify(v.filters.territories), () => {

          const variables = {
            id: projectId,
            ...v
          }

          it('Should return project and totals', async () => {
            const response = await graphqlQuery(query, variables);
            const data = response.body.data;
            //console.log(JSON.stringify(data));
            expect(data).not.equal.empty;
            expect(data.project).not.equal.empty;
            expect(data.project.name).not.equal.empty;
            expect(data.project.totals).not.equal.empty;
            expect(data.project.totals).have.length.above(0);
            expect(data.project.totals[0].units.all).to.be.above(0);
            expect(data.project.totals[0].adjustedUnits.all).to.be.above(0);

            //check for partner split, if no partner is selected in filters
            if (v.filters.partners.length == 0) {
              var partners = jmespath.search(data.project, 'totals[*].partner');
              expect(partners).to.have.length.above(1);
              expect(partners[0].id).not.equal.empty;
              expect(partners[0].name).not.equal.empty;

            }



          });
    
    });
  });
});
  



