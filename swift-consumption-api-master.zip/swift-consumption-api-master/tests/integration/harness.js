import { inspect } from 'util';
import cartesian from 'cartesian';


const precisions = ['Day', 'Week', 'Month', 'Quarter', 'Year', 'All'];

export class IntegrationTestHarness {

  constructor(startDate, 
              endDate, 
              territories, 
              partners, 
              labels, 
              genres,
              catalogue) {
    this.startDate = startDate;
    this.endDate = endDate;

    this.territories = [[]];
    if (territories) {
      territories.forEach(element => {
          this.territories.push([element]);
      });
    }

    this.partners = [[]];
    if (partners) {
      partners.forEach(element => {
          this.partners.push([element]);
      });
    }

    this.labels = [[]];
    if (labels) {
      labels.forEach(element => {
          this.labels.push([element]);
      });
    }

    this.genres = [[]];
    if (genres) {
      genres.forEach(element => {
        this.genres.push([element]);
      });
    }
  };

  getPeriod(period) {
    switch (period) {
      case 'Day':
        return {
          period: period,
          date: {
            year: this.startDate.year,
            month: this.startDate.month,
            day: this.startDate.day
          }
        };
      case 'Week':
        return {
          period: period,
          date: {
            year: this.startDate.year,
            week: this.startDate.week
          }
        };
      case 'Month':
        return {
          period: period,
          date: {
            year: this.startDate.year,
            month: this.startDate.month
          }
        };
      case 'Quarter':
        return {
          period: period,
          date: {
            year: this.startDate.year,
            quarter: this.startDate.quarter
          }
        };
      case 'Year':
        return {
          period: period,
          date: {
            year: this.startDate.year
          }
        };
      case 'All':
        return {
          period: period,
          date: {
            year: this.startDate.year
          }
        };
    }

  }

  getRange(period) {
    switch (period) {
      case 'Day':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year,
            month: this.startDate.month,
            day: this.startDate.day
          },
          endDate: {
            year: this.endDate.year,
            month: this.endDate.month,
            day: this.endDate.day
          },
        };
      case 'Week':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year,
            week: this.startDate.week
          },
          endDate: {
            year: this.endDate.year,
            week: this.endDate.week
          }
        };
      case 'Month':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year,
            month: this.startDate.month
          },
          endDate: {
            year: this.endDate.year,
            month: this.endDate.month
          }
        };
      case 'Quarter':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year,
            quarter: this.startDate.quarter
          },
          endDate: {
            year: this.endDate.year,
            quarter: this.endDate.quarter
          }
        };
      case 'Year':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year
          },
          endDate: {
            year: this.endDate.year
          }
        };
      case 'All':
        return {
          precision: period,
          startDate: {
            year: this.startDate.year
          },
          endDate: {
            year: this.endDate.year
          }
        };
    }

  }

  getPeriodQueryVars() {

    const allPeriods = precisions.map(precision => {
      return this.getPeriod(precision);
    });

    const permutations = cartesian(
      {
        period: allPeriods, 
        territories: this.territories, 
        partners: this.partners
      });

    
    const vars = permutations.map(p => {
      return {
        period: p.period.period,
        date: p.period.date,
        filters: {
          territories: p.territories,
          partners: p.partners
        }
      };
    });

    //console.log('Period query vars: %s', inspect(vars, false, null, false));

    return vars;

  }

  getRangeQueryVars() {

    const allRanges = precisions.map(precision => {
      return this.getRange(precision);
    });

    const permutations = cartesian(
      {
        range: allRanges, 
        territories: this.territories, 
        partners: this.partners
      });

    
    const vars = permutations.map(p => {
      return {
        precision: p.range.precision,
        startDate: p.range.startDate,
        endDate: p.range.endDate,
        filters: {
          territories: p.territories,
          partners: p.partners
        }
      };
    });

    //console.log('Period query vars: %s', inspect(vars, false, null, false));

    return vars;

  }

  getTopQueryVars(topLimit) {

    //remove Day and All
    precisions.splice(0,1);
    precisions.splice(4,1);

    const allPeriods = precisions.map(precision => {
      return this.getPeriod(precision);
    });

    const permutations = cartesian(
      {
        period: allPeriods, 
        territories: this.territories, 
        partners: this.partners,
        labels: this.labels,
        genres: this.genres
      });

    
    const vars = permutations.map(p => {
      return {
        period: p.period.period,
        date: p.period.date,
        territories: p.territories,
        partners: p.partners,
        labels: p.labels,
        genres: p.genres,
        paging: {
            skip: 0,
            limit: topLimit
        }
      };
    });

    //console.log('Period query vars: %s', inspect(vars, false, null, false));

    return vars;

  }

}


