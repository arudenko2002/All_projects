const config = {
  
startDate: {
  year: '2016',
  quarter: '03',
  month: '07',
  week: '30',
  day: '22'
},
endDate: {
  year: '2016',
  quarter: '04',
  month: '12',
  week: '52',
  day: '31'
},
territories: [{type: 'Region', id: '63'}, {type: 'Country', id: 'DE'}],
partners: ['117473'],
labels: [{type: 'Segment', id:'GER01'}, {type: 'Family', id: '1001'}],
genres: ['GPP'],
catalogue: ['Yes'],
topLimit: 25
  
}

export { config };