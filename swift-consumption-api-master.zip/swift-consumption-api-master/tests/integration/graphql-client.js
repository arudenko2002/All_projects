/*
  Simple client for querying GraphQL Server
*/

import request from 'request-promise';
import settings from '../../src/config';

function graphqlQuery(query, variables) {
  return request({
    method: 'POST',
    baseUrl : `http://localhost:${settings.gql.port}`,
    uri : '/graphql',
    body : {
      query: query,
      variables: variables
    },
    headers: {
        'Content-Type':'application/json'
    },
    resolveWithFullResponse: true,
    json: true
  })
};

export { graphqlQuery }; 

