import { describe, it } from 'mocha';
import { expect } from 'chai';
import { graphqlQuery } from '../graphql-client';
import { config } from '../config';
import { IntegrationTestHarness } from '../harness';
import { query } from './gql/track-period-query';
import jmespath from 'jmespath';

const trackId = '1015493742'; //Tove Lo : Stay High


describe('Track Period Queries Integration Test', function () {

  this.timeout(10000);

  const harness = new IntegrationTestHarness(
    config.startDate,
    config.endDate,
    config.territories,
    config.partners
  );

  const vars = harness.getPeriodQueryVars();

  vars.forEach( v => {
    describe('Period: ' + v.period +
        ', Date: ' + JSON.stringify(v.date) + 
        ', Partners: ' + JSON.stringify(v.filters.partners) + 
        ', Territories: ' + JSON.stringify(v.filters.territories), () => {

          const variables = {
            id: trackId,
            ...v
          }

          it('Should return track and totals', async () => {
            const response = await graphqlQuery(query, variables);
            const data = response.body.data;
            //console.log(JSON.stringify(data));
            expect(data).not.equal.empty;
            expect(data.track).not.equal.empty;
            expect(data.track.name).not.equal.empty;
            expect(data.track.image).not.equal.empty;
            expect(data.track.image).to.have.string('https://i.scdn.co/image');
            expect(data.track.totals).not.equal.empty;
            expect(data.track.totals).have.length.above(0);
            expect(data.track.totals[0].units.all).to.be.above(0);
            expect(data.track.totals[0].adjustedUnits.all).to.be.above(0);
            expect(data.track.totals[0].euro.all).to.be.above(0);

            //check for partner split, if no partner is selected in filters
            if (v.filters.partners.length == 0) {
              var partners = jmespath.search(data.track, 'totals[*].partner');
              expect(partners).to.have.length.above(1);
              expect(partners[0].id).not.equal.empty;
              expect(partners[0].name).not.equal.empty;

            }

             //check for country split, if no territory is selected or if region selected in filters
            if (v.filters.territories.length == 0 || 
                (v.filters.territories.length == 1 &&
                 v.filters.territories[0].type == 'Region')) {
              var territories = jmespath.search(data.track, 'totals[*].territory');
              expect(territories).to.have.length.above(1);
              expect(territories[0].id).not.equal.empty;
              expect(territories[0].name).not.equal.empty;

            }

          });
    
    });
  });
});
  



