const query = `query Details(
  $id: ID!,
  $period: Period!,
  $date: CountDateInput!,
  $filters: FilterInput
) {
  artist(id: $id) {
    id
    name
    image
    totals: countsFor(
      interval: { period: $period, date: $date },
      filters: $filters,
      
      groupCounts: [
        { type: Totals },
        { type: Partner,
          sort: [
            { prop: AllAdjustedUnits, ordering: Desc },
            { prop: AllEuro, ordering: Desc }
          ]
        },
        { type: Country,
          sort: [
            { prop: AllAdjustedUnits, ordering: Desc },
            { prop: AllEuro, ordering: Desc },
          ]
        }
      ]
    ) {
      interval {
        date {
          year
          quarter
          month
          week
        }
      }
      territory {
        id
        name
        type
      }
      partner {
        id
        name
      }
      genre {
        id
        name
      }
      label {
        id
        type
      }
      units {
        all
        physicalAlbums
        digitalAlbums
        digitalTracks
        streams
        audioStreams
        videoStreams
        airplays
      }
      adjustedUnits {
        all
        physicalAlbums
        digitalAlbums
        digitalTracks
        streams
        audioStreams
        videoStreams
        airplays
      }
      euro {
        all
        physicalAlbums
        digitalAlbums
        digitalTracks
        streams
        audioStreams
        videoStreams
        airplays
      }
    }
  }  
}`;

export { query };