const query = `query TrackRelatedIsrcs(
  $trackId: ID!,
  $period: Period!,
  $date: CountDateInput!,
  $filters: FilterInput
) {
  thisPeriod: trackRelatedIsrcs(
    trackId: $trackId,
  	interval: { period: $period, date: $date },
    filters: $filters,
    select: [{prop: AllUnits}, {prop: AllAdjustedUnits}, {prop: AllEuro}],
    sort:  { prop: AllAdjustedUnits, ordering: Desc }
    
  ) {
    interval {
      date {
        year
        quarter
        month
        week
        day
      }
    }
    isrc {
      id
      name,
      releaseDate,
      earliestReleaseDate
      track {
        id
        name
      }
    }
      units {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
      }
      adjustedUnits {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
      }
    
  }
  
}`;
export { query };