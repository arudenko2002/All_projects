const query = `query ProjectAlbums(
  $projectId: ID!,
  $period: Period!,
  $date: CountDateInput!,
  $filters: FilterInput
) {
  thisPeriod: projectAlbums(
    projectId: $projectId,
  	interval: { period: $period, date: $date },
    filters: $filters,
    select: [{prop: AllUnits}, {prop: AllAdjustedUnits}, {prop: AllEuro}],
    sort:  { prop: AllAdjustedUnits, ordering: Desc }
    
  ) {
    interval {
      date {
        year
        quarter
        month
        week
        day
      }
    }
    album {
      id
      name,
      releaseDate,
     	version
      project {
        id
        name
        artist {
          id
          name
        }
      }
    }
      units {
        all
        digitalTracks
        streams
       
      }
      adjustedUnits {
        all
        digitalTracks
        streams
       
      }
  
  }
}`;

export { query };
