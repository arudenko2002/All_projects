const query = `query ArtistProjects(
  $artistId: ID!,
  $period: Period!,
  $date: CountDateInput!,
  $filters: FilterInput
) {
  thisPeriod: artistProjects(
    artistId: $artistId,
  	interval: { period: $period, date: $date },
    filters: $filters,
    select: [{prop: AllUnits}, {prop: AllAdjustedUnits}, {prop: AllEuro}],
    sort:  { prop: AllAdjustedUnits, ordering: Desc }
    
  ) {
    interval {
      date {
        year
        quarter
        month
        week
        day
      }
    }
    project {
      id
      name,
      releaseDate,
      earliestReleaseDate
      artist {
        id
        name
      }
    }
      units {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
        physicalAlbums
        digitalAlbums
      }
      adjustedUnits {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
        physicalAlbums
        digitalAlbums
      }
    
  }
  
}`;

export { query };