const query = `query ArtistTracks(
  $artistId: ID!,
  $period: Period!,
  $date: CountDateInput!,
  $filters: FilterInput
) {
  thisPeriod: artistTracks(
    artistId: $artistId,
  	interval: { period: $period, date: $date },
    filters: $filters,
    select: [{prop: AllUnits}, {prop: AllAdjustedUnits}, {prop: AllEuro}],
    sort:  { prop: AllAdjustedUnits, ordering: Desc }
    
  ) {
    interval {
      date {
        year
        quarter
        month
        week
        day
      }
    }
    track {
      id
      name,
      releaseDate,
      earliestReleaseDate
      project {
        id
        name
      }
    }
      units {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
      }
      adjustedUnits {
        all
        digitalTracks
        streams
        audioStreams
        videoStreams
      }
    
  }
}`;

export { query };