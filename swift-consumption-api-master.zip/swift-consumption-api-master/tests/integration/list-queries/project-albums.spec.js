import { describe, it } from 'mocha';
import { expect } from 'chai';
import { graphqlQuery } from '../graphql-client';
import { config } from '../config';
import { IntegrationTestHarness } from '../harness';
import { query } from './gql/project-albums-query';
import jmespath from 'jmespath';

const projectId = '11800102'; 


describe('Project Albums Queries Integration Test', function () {

  this.timeout(10000);

  const harness = new IntegrationTestHarness(
    config.startDate,
    config.endDate,
    config.territories,
    []//config.partners
  );

  const vars = harness.getPeriodQueryVars();

  vars.forEach( v => {
    describe('Period: ' + v.period +
        ', Date: ' + JSON.stringify(v.date) + 
        ', Partners: ' + JSON.stringify(v.filters.partners) + 
        ', Territories: ' + JSON.stringify(v.filters.territories), () => {

          const variables = {
            projectId,
            ...v
          }

          it('Should return list of project albums with totals', async () => {
            const response = await graphqlQuery(query, variables);
            const data = response.body.data;
            //console.log(JSON.stringify(data));
            expect(data).not.equal.empty;
            expect(data.thisPeriod).not.equal.empty;

            var albums = jmespath.search(data, 'thisPeriod[*].album');
            expect(albums).to.have.length.above(0);
            expect(albums[0].id).not.equal.empty;
            expect(albums[0].name).not.equal.empty;

            var units = jmespath.search(data, 'thisPeriod[*].units');
            expect(units).to.have.length.above(0);
            expect(units[0].all).not.equal.empty;

            var adjUnits = jmespath.search(data, 'thisPeriod[*].adjustedUnits');
            expect(adjUnits).to.have.length.above(0);
            expect(adjUnits[0].all).not.equal.empty;
            
          
          });
    
    });
  });
});