const query = `query Top($period: Period!, $date: CountDateInput!,  
    $partners: [ID], $genres: [ID], $territories: [TerritoryInput], $labels: [LabelInput], $catalogue: YesNo, $paging: Paging){
  topProjects(
    interval: {
      period: $period, date: $date
    }, 
    filter: {
      partners: $partners, genres: $genres, territories: $territories, labels: $labels, catalogue: $catalogue
    },
    paging: $paging
  ) 
  {
  	project {
      id
      name
      releaseDate
      earliestReleaseDate
      artist {
        id
        name
      }
      image
    }
    rank
    originalRank
    totals {
      interval {
        period
        date {
          year
          quarter
          month
          week
          day
        }
      }
      territory {
        type
        id
      }
      partner {
        id
        name
      }
      genre {
        id
        name
      }
      label {
        type
        id
      }
      units {
        all
        previous
        rtd
        streams
        audioStreams
        videoStreams
        digitalAlbums
        digitalTracks
        physicalAlbums
      }
      adjustedUnits {
        all
        previous
        rtd
        streams
        audioStreams
        videoStreams
        digitalAlbums
        digitalTracks
        physicalAlbums
      }
      euro {
        all
        previous
        rtd
        streams
        audioStreams
        videoStreams
        digitalAlbums
        digitalTracks
        physicalAlbums
      }
    }
  }
}`;

export { query };