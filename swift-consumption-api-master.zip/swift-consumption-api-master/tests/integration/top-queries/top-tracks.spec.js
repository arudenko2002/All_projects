import { describe, it } from 'mocha';
import { expect } from 'chai';
import { graphqlQuery } from '../graphql-client';
import { config } from '../config';
import { IntegrationTestHarness } from '../harness';
import { query } from './gql/top-tracks-query';
import jmespath from 'jmespath';


describe('Top Tracks Queries Integration Test', function () {

  this.timeout(10000);

  const harness = new IntegrationTestHarness(
    config.startDate,
    config.endDate,
    config.territories,
    config.partners,
    config.labels, 
    config.genres
  );

  const vars = harness.getTopQueryVars(config.topLimit);

  vars.forEach( v => {
    describe('Period: ' + v.period +
        ', Date: ' + JSON.stringify(v.date) + 
        ', Partners: ' + JSON.stringify(v.partners) + 
        ', Territories: ' + JSON.stringify(v.territories) +
        ', Labels: ' + JSON.stringify(v.labels) +
        ', Genres: ' + JSON.stringify(v.genres), () => {

          it('Should return tracks and totals', async () => {
            const response = await graphqlQuery(query, v);
            const data = response.body.data;
            //console.log(JSON.stringify(data));
            expect(data).not.equal.empty;
            expect(data.topTracks).not.equal.empty;
            //expect(data.topArtists).to.have.length.of(config.topLimit);
            expect(data.topTracks[0].track).not.equal.empty;
            expect(data.topTracks[0].track.id).not.equal.empty;
            expect(data.topTracks[0].track.name).not.equal.empty;
            expect(data.topTracks[0].totals).not.equal.empty;
            expect(data.topTracks[0].totals.units.all).to.be.above(0);
            expect(data.topTracks[0].totals.adjustedUnits.all).to.be.above(0);
            expect(data.topTracks[0].totals.euro.all).to.be.above(0);
          });
    
    });
  });
});