#!/bin/bash

rm -rf node_modules

# docker build -t us.gcr.io/umg-swift-dev/swift-consumption-api .
docker build -t us.gcr.io/umg-swift-dev/swift-consumption-api .

# docker run -it --rm --name swift-running-api us.gcr.io/umg-swift-dev/swift-consumption-api