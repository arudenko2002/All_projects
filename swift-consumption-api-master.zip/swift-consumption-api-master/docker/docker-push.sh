#!/bin/bash

gcloud docker -- push us.gcr.io/umg-swift-dev/swift-consumption-api