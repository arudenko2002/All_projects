#!/usr/bin/env bash
####
#### RUN: ./run-localhost.sh -k [DECRYPTION_KEY_PATH] -e [ENV]
####
#### The script will run the API service on localhost to simulate a particular env.
####
#### Last Revised: 10/19/2017
#### Author: Alan Ma <alan.ma@umusic.com>


display_usage()
{
cat << EOF
usage: $0 options

example: sh $0 -k /path/to/rsa_key -e qa

OPTIONS:
-h      help
-k      RSA private key to decrypt local secrets (get it from your team lead)
-e      Environment the service shall be running, accepted values are [local|dev|qa|uat|prod]
EOF
}

## default to NOT promoting a deployed version
PROMOTE=false

while getopts ":k:e:h:" arg
do
  case $arg in
      h)
          display_usage
          exit 1
          ;;
      k)
          RSA_KEY=$OPTARG
          ;; 
      e)
          ENV=$OPTARG
          ;; 
      ?)
          display_usage
          exit 1
          ;;
  esac
done

# remove the spaces from the variable using the pattern replacement parameter expansion
if [[ -z "${ENV// }" ]] || [[ -k "${RSA_KEY// }" ]]; then
     display_usage
     exit 1
fi

#### decrypting local secrets
cd pipeline
KEY=swift-dizzee-api-git-secrets-key
openssl rsautl -decrypt -ssl -inkey $RSA_KEY -in $KEY.enc -out $KEY
openssl aes-256-cbc -d -in localhost-secrets.tar.gz.enc -out localhost-secrets.tar.gz -pass file:$KEY
tar -xzvf localhost-secrets.tar.gz
rm -f $KEY
rm -f localhost-secrets.tar.gz

#### Copy gcp service account key files to default path expected by the app
cp secrets/svc-swift-api*.json ../src/config
cat ../src/config/svc-swift-api*.json

#### exporting local secrets per desired env.
echo
source localhost-env-variables-reset.sh
source localhost-env-variables-$ENV.sh
cat localhost-env-variables-$ENV.sh
echo

#### Un-comment to overwrite the SWIFT Web URI
# export UI_ENVIRONMENT_URI='http://localhost:3000'

#### build docker image
docker build -t us.gcr.io/umg-swift-dev/swift-consumption-api .

#### run the service
docker run -it --rm --name swift-running-api us.gcr.io/umg-swift-dev/swift-consumption-api

echo "Service stopped."

rm -f src/config/svc-swift-api*.json
rm -f pipeline/localhost-env-variables-*.sh
