#!/bin/bash
kill -9 `cat pid.txt`
rm pid.txt