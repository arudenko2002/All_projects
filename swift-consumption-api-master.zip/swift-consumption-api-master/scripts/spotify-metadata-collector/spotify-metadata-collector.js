// eslint-disable-next-line no-unused-vars
import logger from '../../src/lib/logger';
import { inspect } from 'util';
import settings from '../../src/config';
import NodeCache from 'node-cache';
import { MongoDbConnector } from '../../src/data/connectors/mongodb';
import { Spotify } from '../../src/data/connectors/spotify';
import sleep from 'system-sleep';
import moment from 'moment';

const { mongo } = settings;

const mongodb = new MongoDbConnector(mongo);


// eslint-disable-next-line no-unused-vars
const cache = new NodeCache();

const spotify = new Spotify();

const STATUS_COLLECTION = 'spotify-metadata-status';
const REJECTED_COLLECTION = 'spotify-rejected-isrcs';
const ISRC_SEQUENCE_COLLECTION = 'isrc_2years_rank';
const SPOTIFY_TRACK_COLLECTION = 'spotify-tracks';
const SPOTIFY_ALBUM_COLLECTION = 'spotify-albums';
const SPOTIFY_ARTIST_COLLECTION = 'spotify-artists';

//maximum number of ISRCS to process
const MAX_NUM_ITERATIONS = 2000000;


async function run() {

  try {

    //connect to Mongo
    await mongodb.connect();

    //set default start sequence id to 1
    var sequenceId = 1;

    //get the last processed isrc sequence
    const status = await mongodb.collection(STATUS_COLLECTION).findOne({});

    //throw an error if not found
    if (status &&
        status.lastProcessed) 
    {
      //if found last processed isrc sequence, increase by 1
      //and use as a start sequence
      sequenceId = parseInt(status.lastProcessed._id) + 1;
    }
    
    //set OAuth token as empty string with expiry time in the past so we can renew it 
    const date = new Date();
    var token = '';
    var tokenExpiryTime = date.getTime() - 10;

    //start looping through ISRC sequence
    for (var i = 0; i < MAX_NUM_ITERATIONS; i++) {
    
      //get next ISRC to process
      var isrcSequence = await mongodb.collection(ISRC_SEQUENCE_COLLECTION).findOne({_id: sequenceId.toString()});
      
      //if not found, throw an error 
      if (!isrcSequence) 
        throw new Error(`No ISRC sequence found with _id: ${sequenceId}`);

      //obtain new OAuth token, if previous one is expired
      if (date.getTime() > tokenExpiryTime) {
      
        const tokenResponse = await spotify.getToken();

        //if no correct token response, throw an error
        if (!tokenResponse ||
          !tokenResponse.access_token ||
          !tokenResponse.expires_in)
          throw new Error('Error obtaining Spotify OAuth token');

        tokenExpiryTime = (date.getTime() + tokenResponse.expires_in) - 10;
        token = tokenResponse.access_token;

        logger.info('Obtained new OAuth token: %s', token);
      
      }

      //search ISRC from Spotify API
      const trackResponse = await spotify.getTrack(isrcSequence.isrc, token);

      if (!trackResponse ||
          !trackResponse.tracks ||
          !trackResponse.tracks.items.length ||
          !trackResponse.tracks.items[0].id ||
          !trackResponse.tracks.items[0].artists.length ||
          !trackResponse.tracks.items[0].artists[0].id ||
          !trackResponse.tracks.items[0].album.id) {

        //save into rejected collection and continue
        const rejectedWriteResponse =  await mongodb.collection(REJECTED_COLLECTION).save(isrcSequence);
        if (!rejectedWriteResponse ||
          !rejectedWriteResponse.result ||
          !(rejectedWriteResponse.result.n === 1) ||
          !(rejectedWriteResponse.result.ok === 1) )
          throw new Error('Error saving Spotify rejected ISRC to Mongo');
        
        sequenceId++;
        continue;
      }
       

      const track = {
        _id: isrcSequence.trackId,
        isrc: isrcSequence.isrc,
        ...trackResponse.tracks.items[0],
        updatedAt: new Date(date.getTime())
      };

      //save track Spotify metadata in Mongo collection
      const trackWriteResponse =  await mongodb.collection(SPOTIFY_TRACK_COLLECTION).save(track);
      if (!trackWriteResponse ||
          !trackWriteResponse.result ||
          !(trackWriteResponse.result.n === 1) ||
          !(trackWriteResponse.result.ok === 1) )
        throw new Error('Error saving Spotify track metadata to Mongo');

      //if we didn't save album metadata as part of this process,
      //get it from Spotify API and save in Mongo
      if (!cache.get('album:' + isrcSequence.projectId)) {
        
        const albumResponse = await spotify.getAlbum(track.album.id, token);

        if (!albumResponse) 
          throw new Error (`Error obtaining album from Spotify API by id ${track.album.id}. Response ${inspect(albumResponse, false, null, false)}`);

        const album = {
          _id: isrcSequence.projectId,
          ...albumResponse,
          updatedAt: new Date(date.getTime())

        };

        const albumWriteResponse =  await mongodb.collection(SPOTIFY_ALBUM_COLLECTION).save(album);
        if (!albumWriteResponse ||
          !albumWriteResponse.result ||
          !(albumWriteResponse.result.n === 1) ||
          !(albumWriteResponse.result.ok === 1) )
          throw new Error('Error saving Spotify album metadata to Mongo');

        //update cache so we skip saving same album on a next loop for different ISRC
        cache.set('album:' + isrcSequence.projectId);
      }

      //if we didn't save artist metadata as part of this process,
      //get it from Spotify API and save in Mongo
      if (!cache.get('artist:' + isrcSequence.artistId)) {
        
        const artistResponse = await spotify.getArtist(track.artists[0].id, token);

        if (!artistResponse) 
          throw new Error (`Error obtaining artist from Spotify API by id ${track.artists[0].id}. Response ${inspect(artistResponse, false, null, false)}`);

        const artist = {
          _id: isrcSequence.artistId,
          ...artistResponse,
          updatedAt: new Date(date.getTime())

        };

        const artistWriteResponse =  await mongodb.collection(SPOTIFY_ARTIST_COLLECTION).save(artist);
        if (!artistWriteResponse ||
          !artistWriteResponse.result ||
          !(artistWriteResponse.result.n === 1) ||
          !(artistWriteResponse.result.ok === 1) )
          throw new Error('Error saving Spotify artist metadata to Mongo');

        //update cache so we skip saving same artist on a next loop for different ISRC
        cache.set('artist:' + isrcSequence.artistId);
      }

      //save last processed status to Mongo
      const status = {
        _id: 1,
        lastProcessed: isrcSequence,
        updatedAt: new Date(date.getTime())

      };

      const statusWriteResponse = await mongodb.collection(STATUS_COLLECTION).save(status);
      if (!statusWriteResponse ||
          !statusWriteResponse.result ||
          !(statusWriteResponse.result.n === 1) ||
          !(statusWriteResponse.result.ok === 1) )
        throw new Error('Error saving Spotify metadata collection status to Mongo');

      console.log('%s: Processed %s: %s - %s', 
      moment().format(),
      isrcSequence._id,
      isrcSequence.artistName,
      isrcSequence.trackTitle);

      sequenceId++;

    }
  }
  catch (err) {
    if (err.message.includes('429') ||
        err.message.includes('502') ||
        err.message.includes('503')) {
      logger.info(err.message);
      logger.info('Restarting...');
      sleep(10000);
      run();
    } else {
      logger.error(err.message);
    }

  }
}

run();




