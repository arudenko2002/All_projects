## Spotify Metadata Collector
Script that collects metadata from Spotify API and stores it in MongoDB. 

The main purpose for this script is to reliably identify, obtain and cache image URLs for artists and albums to present in UI. 

### Logic of the script
The only way to reliably associate UMG product metadata (artist, projects and tracks) with Spotify metadata is by ISRC code.

There are close to 2 mln ISRC codes in UMG product metadata, so to optimize the Spotify metadata collection we should start from most popular items and go in descending order of popularity.

A sequence list of ISRC has been produced from UMG Spotify Datamart, with a popularity rank for the past 2 years (June 2015 - June 2017). The rank #1 means most popular. 

The script will loop through this list of ranked ISRCs and obtain Spotify metadata about track first. Then from Spotify track metadata, the Spotify IDs for album and artist are known and can be obtained reliably from Spotify API. Therefore there can be up to 3 calls to Spotify API per ISRC: one for track, one for album and one for artist. 

If one track for the same artist and same album has already been processed, the script skips API calls for album and artist and only gets the metadata for track. 

### MongoDB Collections

#### Spotify Metadata collections

The script stores the metadata obtained from Spotify API in the following collections in MongoDB

* spotify-artists
* spotify-albums
* spotify-tracks

The schema of the documents is identical to how it is received from Spotify with 3 exceptions:

1. The `_id` value of each document is matching UMG metadata id, in order to maintain the link between UMG metadata and Spotify metadata.
2. `updatedAt` timestamp added to each document to know when the metadata has been last updated from Spotify API. 
3. `ISRC` property added to `spotify-tracks` document.

#### ISRC Sequence
The JSON document structure of ranked sequence is the following:
```
{
    "_id" : "1",
    "isrc" : "USCM51600028",
    "trackId" : "1016380701",
    "trackTitle" : "One Dance",
    "projectId" : "11813390",
    "projectTitle" : "Views",
    "artistId" : "10041007",
    "artistName" : "Drake",
    "streams" : "1243481100",
    "rank" : "1"
}
```
The `_id` of the structure is similar to `rank`, but it's unique. The two ISRCs can have same `rank` value, but `_id` values will be different. The processing of the ISRCs will be happening in ascending order of `_id` values. 

The ISRC sequence documents are stored in `isrc_2years_rank` collection in MongoDB

#### Status Document
To make the script restartable, the last processed ISRC sequence is stored in MongoDB as the following JSON document:

```
{
    "_id" : 1,
    "lastProcessed" : {
        "_id" : "18935",
        "isrc" : "USUM70826456",
        "trackId" : "100174242",
        "trackTitle" : "Single",
        "projectId" : "10130119",
        "projectTitle" : "The Block",
        "artistId" : "10028829",
        "artistName" : "New Kids on the Block",
        "streams" : "1906812",
        "rank" : "18916"
    },
    "updatedAt" : ISODate("2017-06-22T15:02:32.159Z")
}
```
where `_id` is constant and always equals to `1`, as it gets updated with every new processed ISRC. 

If script is stopped or fails, next time it starts it will look up into this status document to start processing from the next `_id` value. 

#### Rejected ISRCs
Although list of ranked ISRCs has been obtained from UMG Spotify Datamart, for some reason not all the ISRCs are found in the Spotify API. These "rejected" ISRC sequences are stored in `spotify-rejected-isrcs` collection in MongoDB with the same document structure as ISRC Sequence (see above). This will require further look into how to reliably obtain metadata for these ISRCs. 

### Operating the script

#### Starting and stopping
The script is made to run on the background, so it can be left unattended for long period of time, if needed.

There are two files to start and stop the script:
* start.sh
* stop.sh

Make sure that these files are made executable by running the following command in the script directory:
```
$ chmod +x *.sh
``` 

Then to start the script do
```
$ ./start.sh
```

And to stop the script to 
```
$ ./stop.sh
```

#### Monitoring progress
Once the script is started, it doesn't output anything to the console, since it's a background process. Instead it outputs the processed ISRCs to the log file `spotify-metadata-collector.log`

If you are logged in to the machine where the script is running, to check the ongoing process just output the latest status with the following command:

```
$ tail spotify-metadata-collector.log
```

The output should be in the following format:
```
2017-06-22T08:54:09-07:00: Processed 20070: R5 - One Last Dance
2017-06-22T08:54:10-07:00: Processed 20071: Rihanna - Here I Go Again
2017-06-22T08:54:11-07:00: Processed 20072: Hans Zimmer - Oogway Ascends
2017-06-22T08:54:12-07:00: Processed 20073: DJ Snake - Propaganda
2017-06-22T08:54:13-07:00: Processed 20074: Eddie Santiago - Tú Me Quemas
2017-06-22T08:54:14-07:00: Processed 20075: Christophe Beck - The Great Thaw (Vuelie Reprise)
2017-06-22T08:54:15-07:00: Processed 20077: SoMo - Want It
```

It's possible to estimate how long the script will be running to process certain number of ISRCs, by comparing logged timestamps and sequence IDs. 

Also it's possible to see the progress by getting the status document from MongoDB by using Robomongo, for example. Querying it continuesly multiple times will tell if the script is still running, if the value of `lastProcessed._id` changes. 

### Error Handling
The script is made to automatically restart after 10 sec pause after encountering the following errors:

* 429 - API rate limit exceeded
* 502 - Bad Gateway

All the other errors will stop the script, so the script needs to be checked periodically if it is still running. 











