#!/bin/bash
nohup npm run spotify-metadata-collector >> spotify-metadata-collector.log 2>&1 &
echo $! > pid.txt