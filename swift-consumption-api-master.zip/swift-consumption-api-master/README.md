# Swift Consumption API

[![Build Status](https://travis-ci.com/umg/swift-consumption-api.svg?token=AxHxbpiXC6yoM1yxcAti&branch=master)](https://travis-ci.com/umg/swift-consumption-api)

API project for SWIFT Consumption Reporting.

## Prerequisite

### Install homebrew

[Homebrew installation](https://github.com/umg/swift-frontends-deployment/blob/master/homebrew-ruby.MD)

### Update openssl

```
$ brew tap homebrew/dupes
$ brew install openssh --with-brewed-openssl --with-keychain-support
```

### Install nodejs

```
brew install node
```

### ES6/7 + Babel

This project relies on having access to ES6 (supported in node6+) and ES7 features
so it is utilizing [Babel.js](https://babeljs.io/)

When running locally without transpiling all of the code first, this project uses
[local.xxx.js] to register babel and start execution of the main file

### Linting

This project relies on [ESLint](http://eslint.org/)
It's set up to use the YAML style (less verbose) config file [.eslintrc.yml](.eslintrc.yml)

Also currently making use of the [Babel ESLint Plugin](https://github.com/babel/eslint-plugin-babel) to leverage Babel transpiling to allow more ES2017 features than ESLint currently supports

### Koa 2.0

This project relies on Koa v2 which uses `async/await` from ES7 to make promise-based
execution write/read like linear code.

Built over again, this is a much cleaner framework than Koa v1 which utilized generators.

Try to see if middleware for Koa has a version that works with Koa v2 and install
that one.  Examples in this project are:
- [koa-66](https://github.com/menems/koa-66) - used for routing - built from the ground up to only work with Koa v2
- [koa-bodyparser](https://github.com/koajs/bodyparser) - original and popular body parser for Koa, it has a version
that works with Koa v2 and must be installed used `npm install koa-bodyparser@next`

For those middleware that only work with Koa v1, use `koa-convert`, example:
- [koa-mount](https://github.com/koajs/mount) - very useful to mount a Koa App as middleware to specific path
instead of having to inspect the path of every incoming request

## GETTING STARTED

### Install dependencies and compile build
```
$ npm install
$ npm run build
```
### Run service

Please replace the path of the RSA key file `id_rsa_swift_github` to match your local machine.

```
./run-localhost.sh -k ~/.ssh/id_rsa_swift_github -e local
```

### Verify service

Navigate to the following URL to verify that your application is running.

	http://localhost:8080/graphiql

Expecting SWIFT Web is running at http://localhost:3000. If you are running Web service from a different port. Please refer to the end of run-loaclhost.sh for `Un-comment to overwrite the SWIFT Web URI`.
