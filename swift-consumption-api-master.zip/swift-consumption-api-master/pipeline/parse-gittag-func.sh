#!/usr/bin/env bash
####
#### Call the func: parse_gittag gcp/dev/0-3-0
####
#### Last Revised: 09/18/2017
#### Author: Alan Ma <alan.ma@umusic.com>

parse_version() { 
	local tag="$@"
	local output
	output=`echo $tag | awk '{split($0,v,"/"); print v[2] "-" v[3]}'`
    echo $output
}

parse_env() { 
	local tag="$@"
	local output
	output=`echo $tag | awk '{split($0,v,"/"); print v[2]}'`
    echo $output
}