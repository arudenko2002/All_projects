#!/bin/bash
####
#### RUN: ./manual-deploy.sh -t [GIT_TAG] -n [SERVICE_ACCOUNT_NAME] -p [SERVICE_ACCOUNT_PATH]
####
#### example: manual-deploy.sh -t gcp/dev/0-8-0 -n svc-swift-cicd@umg-swift-ae-dev.iam.gserviceaccount.com -p /path/to/svc.json
#### Manually deploy version dev-0-8-0 artifact to GAE.
####
#### Last Revised: 10/03/2017
#### Author: Alan Ma <alan.ma@umusic.com>

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd "${dir}"

# include bash utils function
source bash-flow-control-func.sh
# include gittag parsing function
source parse-gittag-func.sh

display_usage()
{
cat << EOF
usage: $0 options

example: sh $0 -t gcp/dev/0-8-0 -n svc-swift-cicd@umg-swift-ae-dev.iam.gserviceaccount.com -p /path/to/svc-swift-cicd

OPTIONS:
-h      help
-t      Git tag extracted by CI system or provided manually. The format is gcp/[dev|qa|uat|prod]/version
-n      GCP project service account name 
-p      Path to the GCP project service account key file (json format)
EOF
}

## default to NOT promoting a deployed version
PROMOTE=false

while getopts ":t:n:p:h:" arg
do
  case $arg in
      h)
          display_usage
          exit 1
          ;;
      t)
          GIT_TAG=$OPTARG
          ;; 
      n)
          SERVICE_ACCOUNT_NAME=$OPTARG
          ;;
      p)
          SERVICE_ACCOUNT_PATH=$OPTARG
          ;;     
      ?)
          display_usage
          exit 1
          ;;
  esac
done

if [ -z "$GIT_TAG" ]; then
  display_usage
  exit 1
fi   

# Extract service version from the tag
echo "Current building from branch: "$GIT_TAG
GAE_SERVICE_ENV=`echo $GIT_TAG | awk '{split($0,v,"/"); print v[2]}'`
GAE_SERVICE_VERSION=`echo $GIT_TAG | awk '{split($0,v,"/"); print v[2] "-" v[3]}'`
echo "export GAE_SERVICE_VERSION=${GAE_SERVICE_VERSION}" > deployment-variables.sh
echo "export GAE_SERVICE_ENV=${GAE_SERVICE_ENV}" >> deployment-variables.sh
echo "Version "$GAE_SERVICE_VERSION" will now be deployed to GCP..." 

PROJECT_PREFIX="umg-swift-ae"
if [ "$GAE_SERVICE_ENV" == "dev" ]; then
  export PROJECT_ID=$PROJECT_PREFIX"-"$GAE_SERVICE_ENV
elif [ "$GAE_SERVICE_ENV" == "qa" ]; then 
  export PROJECT_ID=$PROJECT_PREFIX"-"$GAE_SERVICE_ENV
elif [ "$GAE_SERVICE_ENV" == "uat" ]; then
  export PROJECT_ID=$PROJECT_PREFIX"-"$GAE_SERVICE_ENV
elif [ "$GAE_SERVICE_ENV" == "prod" ]; then 
  export PROJECT_ID=$PROJECT_PREFIX
else
  display_usage
    die "[ERROR] Invalid environment argument: $GAE_SERVICE_ENV. Should be one of [dev|qa|uat|prod]."
fi
echo "export PROJECT_ID=${PROJECT_ID}" >> deployment-variables.sh

echo "export SERVICE_ACCOUNT_NAME=${SERVICE_ACCOUNT_NAME}" >> deployment-variables.sh
echo "export SERVICE_ACCOUNT_PATH=${SERVICE_ACCOUNT_PATH}" >> deployment-variables.sh

cat deployment-variables.sh

if [ -f secrets/app-secrets-$GAE_SERVICE_ENV.yaml ]; then

  # Copy gcp service account key files to default path expected by the app
  cp secrets/svc-swift-api*.json ../src/config
  cat ../src/config/svc-swift-api*.json
  
  # Injected decrypted env specific config into app.yaml
  GAE_CONFIG_FILE="../app.yaml"
  cat app-config-$GAE_SERVICE_ENV.yaml > $GAE_CONFIG_FILE && echo >> $GAE_CONFIG_FILE && cat secrets/app-secrets-$GAE_SERVICE_ENV.yaml >> $GAE_CONFIG_FILE
  cat $GAE_CONFIG_FILE
  echo
  # Set the correct project to deploy to
  gcloud config set project $PROJECT_ID
  gcloud auth activate-service-account $SERVICE_ACCOUNT_NAME --key-file $SERVICE_ACCOUNT_PATH
  gcloud config list

  gcloud app deploy ../app.yaml --verbosity=info --version=$GAE_SERVICE_VERSION

  rm -f ../src/config/svc-swift-api*.json
  echo "gcloud app deploy $GAE_CONFIG_FILE --verbosity=info --version=$GAE_SERVICE_VERSION"
else
  echo "Missing required secrets file for Manual deployment!"
fi

# Clean up intermediate files
rm -f deployment-variables.sh
