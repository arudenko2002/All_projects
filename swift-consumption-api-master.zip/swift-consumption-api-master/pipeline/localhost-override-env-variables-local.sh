#!/bin/bash
####
#### source localhost-env-variables-local-override.sh
####
#### Manually override localhost running env. variables needed for the service.
####
#### Last Revised: 11/15/2017
#### Author: Alan Ma <alan.ma@umusic.com>

export NODE_ENV='local'
export SERVER_PORT=8080
export BIGTABLE_PROJECT='umg-swift'
export BIGTABLE_KEY_FILE='svc-swift-api@umg-swift.json'
export BIGTABLE_INSTANCE='swift-consumption'
export BIGTABLE_TOP_ARTISTS_TABLE='top_artist_v2'
export BIGTABLE_TOP_PROJECTS_TABLE='top_project_v2'
export BIGTABLE_TOP_TRACKS_TABLE='top_track_v2'
export BIGTABLE_ARTISTS_TABLE='artist_v2'
export BIGTABLE_PROJECTS_TABLE='project_v2'
export BIGTABLE_ALBUMS_TABLE='album_v2'
export BIGTABLE_TRACKS_TABLE='track_v2'
export BIGTABLE_ISRCS_TABLE='isrc_v2'
export UI_ENVIRONMENT_URI='http://localhost:3000'
