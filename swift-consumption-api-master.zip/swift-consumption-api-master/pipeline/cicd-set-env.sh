#!/usr/bin/env bash
####
#### RUN: ./cicd-set-env.sh
####
#### The script will prase out the git tag and set env. variable to drive the deployment process.
####
#### Last Revised: 10/14/2017
#### Author: Alan Ma <alan.ma@umusic.com>

set -ev

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd "${dir}"

# include gittag parsing function
source parse-gittag-func.sh

# Decrypt the credentials we added to the repo using the key we added with the Travis command line tool
openssl aes-256-cbc -K $encrypted_3ee061291814_key -iv $encrypted_3ee061291814_iv -in credentials.tar.gz.enc -out credentials.tar.gz -d

# Unarchive the protected files into their original dir layout
tar -xzf credentials.tar.gz
ls -la secrets

GIT_TAG=$TRAVIS_TAG
echo "Current building from branch: "$GIT_TAG

# GIT_TAG != '' || ($TRAVIS_PULL_REQUEST = false && $TRAVIS_BRANCH = master)
if [ ! -z "$GIT_TAG" ] && [[ $GIT_TAG =~ ^gcp/(dev|qa|uat|prod)/.*$ ]]; then

  # Extract service version from the tag
  echo "Current building from branch: "$GIT_TAG
  GAE_SERVICE_ENV=`parse_env $GIT_TAG`
  GAE_SERVICE_VERSION=`parse_version $GIT_TAG`
  echo "## Generated from deployment process. DO NOT MODIFY!!!" >> deployment-variables.sh
  echo "export GAE_SERVICE_VERSION=${GAE_SERVICE_VERSION}" >> deployment-variables.sh
  echo "export GAE_SERVICE_ENV=${GAE_SERVICE_ENV}" >> deployment-variables.sh

  SERVICE_NAME="swift"
  PROJECT_PREFIX="umg-${SERVICE_NAME}-ae"
  # create env. variables for service accounts
  if [ "$GAE_SERVICE_ENV" == "prod" ]; then 
    SECRETS_PATH_ENV=
    PROJECT_ID=$PROJECT_PREFIX
  else  
    SECRETS_PATH_ENV="-"$GAE_SERVICE_ENV
    PROJECT_ID=$PROJECT_PREFIX"-"$GAE_SERVICE_ENV
  fi    
  SERVICE_ACCOUNT_NAME="svc-$SERVICE_NAME-cicd@umg-$SERVICE_NAME-ae${SECRETS_PATH_ENV}.iam.gserviceaccount.com"
  SERVICE_ACCOUNT_PATH="pipeline/secrets/svc-$SERVICE_NAME-cicd@umg-$SERVICE_NAME-ae${SECRETS_PATH_ENV}.json"
  echo "export SERVICE_ACCOUNT_NAME=${SERVICE_ACCOUNT_NAME}" >> deployment-variables.sh
  echo "export SERVICE_ACCOUNT_PATH=${SERVICE_ACCOUNT_PATH}" >> deployment-variables.sh
  echo "export PROJECT_ID=${PROJECT_ID}" >> deployment-variables.sh
  
  cat deployment-variables.sh
  echo
  echo "Version "$GAE_SERVICE_VERSION" will now be deployed to GCP..."
  echo

  # Copy gcp service account key files to default path expected by the app
  cp secrets/svc-swift-api*.json ../src/config
  ls -la ../src/config
  
  # Injected decrypted env specific config into app.yaml
  GAE_CONFIG_FILE="../app.yaml"
  cat app-config-$GAE_SERVICE_ENV.yaml > $GAE_CONFIG_FILE && echo >> $GAE_CONFIG_FILE && cat secrets/app-secrets-$GAE_SERVICE_ENV.yaml >> $GAE_CONFIG_FILE
  head -n 20 $GAE_CONFIG_FILE
  echo "... skipping the rest of app.yaml for security reason... "

fi

