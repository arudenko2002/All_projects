#!/usr/bin/env bash
####
#### Common flow control functions
####
#### Last Revised: 09/18/2017
#### Author: Alan Ma <alan.ma@umusic.com>

yell() { echo "$0: $*" >&2; }
die() { yell "$*"; exit 111; }
try() { "$@" || die "cannot $*"; }