#!/bin/bash
####
#### Run unit and integration tests. Called by CICD tools. Not intended to be invoked manually.
####
#### Last Revised: 09/10/2017
#### Author: Alan Ma <alan.ma@umusic.com>

npm test