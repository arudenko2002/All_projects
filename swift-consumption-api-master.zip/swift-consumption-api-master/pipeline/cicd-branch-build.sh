#!/usr/bin/env bash
####
#### RUN: ./cicd-branch-build.sh
####
#### example: ./cicd-branch-build.sh
#### The above example will build the app for each branch update.
####
#### Last Revised: 10/23/2017
#### Author: Alan Ma <alan.ma@umusic.com>

set -ev 

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd "${dir}"
pwd

cd ../

npm run build

ls -lt .

exit 0
