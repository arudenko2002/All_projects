const config = {
  // options to the logger (pino in this case)
  logs: {
    prettyPrint: true,
    // for sensitive data not to be logged
    redactKeys: [
      // example - currently not working
      'mongo.password',
    ],
  },
  metrics: {
    endpoint: process.env.METRICS_ENDPOINT || '/metrics',
    excludedPaths: process.env.METRICS_EXCLUDED_PATHS || ['/metrics', '/service/healthz'],
  },
  healthCheck: {
    endpoint: process.env.HEALTH_CHECK_ENDPOINT || '/healthz',
  },
  caching: {
    public: process.env.CACHE_PUBLIC || true,
    maxAge: process.env.CACHE_MAX_AGE || 28800, // 8 hours
  },
  compression: {
    threshold: process.env.COMPRESSION_THRESHOLD || 1024, // bytes
  },
  optics: {
    apiKey: process.env.OPTICS_API_KEY,
    reportTraces: process.env.OPTICS_REPORT_TRACES || true,
    reportVariables: process.env.OPTICS_REPORT_VARIABLES || true,
    printReports: process.env.OPTICS_PRINT_REPORTS || false,
  },
  mongo: {
    hosts: [{
      hostname: process.env.MONGO_HOST,
      port: process.env.MONGO_PORT,
    }, ],
    // backwards compatible
    host: process.env.MONGO_HOST,
    port: process.env.MONGO_PORT,
    database: process.env.MONGO_DB,
    replicaSet: process.env.MONGO_REPLICA_SET,
    readPreference: process.env.MONGO_READ_PREFERENCE,
    username: process.env.MONGO_USERNAME,
    password: process.env.MONGO_PASSWORD,
    authSource: process.env.MONGO_AUTH_SOURCE,
    collections: {
      album: 'album',
      spotifyAlbum: 'spotify-albums',
      artist: 'artist',
      calendar: 'day',
      spotifyArtist: 'spotify-artists',
      country: 'country',
      genre: 'genre',
      isrc: 'isrc',
      labelFamily: 'label_family',
      partner: 'partner',
      project: 'project',
      region: 'region',
      sapSegment: 'sap_segment',
      track: 'track',
      spotifyTrack: 'spotify-tracks'
    }
  },
  bigtable: {
    // Key file path is relative to `src/config` or is an absolute path
    keyFile: process.env.BIGTABLE_KEY_FILE,
    projectId: process.env.BIGTABLE_PROJECT,
    instance: process.env.BIGTABLE_INSTANCE,
    tables: {
      topArtists: process.env.BIGTABLE_TOP_ARTISTS_TABLE,
      topProjects: process.env.BIGTABLE_TOP_PROJECTS_TABLE,
      topTracks: process.env.BIGTABLE_TOP_TRACKS_TABLE,
      artist: process.env.BIGTABLE_ARTISTS_TABLE,
      project: process.env.BIGTABLE_PROJECTS_TABLE,
      album: process.env.BIGTABLE_ALBUMS_TABLE,
      track: process.env.BIGTABLE_TRACKS_TABLE,
      isrc: process.env.BIGTABLE_ISRCS_TABLE,
    },
    dayWeekThreshold: '201725'
  },
  spotify: {
    albumUrl: process.env.SPOTIFY_ALBUM_URL,
    artistUrl: process.env.SPOTIFY_ARTIST_URL,
    searchUrl: process.env.SPOTIFY_SEARCH_URL,
    tokenUrl: process.env.SPOTIFY_TOKEN_URL,
    clientId: process.env.SPOTIFY_CLIENT_ID,
    clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
  },
  auth: {
    secret: process.env.COOKIE_SECRET,
    uiEnvironmentUri: process.env.UI_ENVIRONMENT_URI,
    disabled: process.env.DISABLE_AUTH || false, // quickly disable endpoint auth for debugging purposes - CAREFUL!

  }
};

export default config;
