const config = {
  api: {
    port: 5666,
  },
  gql: {
    port: process.env.SERVER_PORT,
    useMocks: false,
    preserveResolvers: true,
  },
};

export default config;