import { merge } from 'lodash';
import all from './env/all';

let env = {};
let envName = process.env.NODE_ENV || 'dev';
let envPath = `./env/${envName}`;
try {
  env = require(envPath);
  if (env.default) {
    env = env.default;
  }
}
catch (err) {
  console.info(`no env file for "${envName}" - will only use what's in all.js`);
  // swallow missing file
}

const settings = merge({}, all, env);

export default settings;