import Router from 'koa-66';
import _ from 'lodash';
// import Promise from 'bluebird';
// TODO: import routes here
import example from './example-router';

/**
 * @swagger
 * definitions:
 *   Error:
 *     type: object
 *     required:
 *       - message
 *     properties:
 *       message:
 *         type: string
 *       code:
 *         type: integer
 *         format: int32
 */

const routes = {
  // TODO: put routes here
  example,
};

export default function indexRoutes(options, routers) {
  const indexRouter = new Router();


  _.forEach(routes, (router, route) => {
    const r = new router(options);
    indexRouter.mount(`/${route}`, r.router);
  });

  if (routers) {
    _.forEach(routers, (r, path) => {
      if (r) {
        indexRouter.mount(`/${path}`, r);
      }
    });
  }

  return indexRouter.routes({ throw: true });
}