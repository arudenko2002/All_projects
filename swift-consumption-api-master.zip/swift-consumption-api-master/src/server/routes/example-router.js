import Router from 'koa-66';
// import _ from 'lodash';

// const example = {
//   name: 'my-name',
//   requiredStuff: 'something I want to put here',
//   otherStuff: 32,
//   anotherThing: 'and another thing...',
// };

/**
 * @swagger
 * definitions:
 *   ExampleUpdate:
 *     type: object
 *     required:
 *       - requiredStuff
 *     properties:
 *       otherStuff:
 *         type: integer
 *         format: int32
 *         default: 0
 *       requiredStuff:
 *         type: string
 *   Example:
 *     type: object
 *     allOf:
 *       - $ref: '#/definitions/ExampleUpdate'
 *       - required:
 *         - name
 *         - requiredStuff
 *         - otherStuff
 *         - anotherThing
 *       - properties:
 *           name:
 *             type: string
 *           anotherThing:
 *             type: string
 */

// const httpStatuses = {
//   notFound: 404,
//   notAllowed: 405,
//   conflict: 409,
// };

class ExampleRouter {

  constructor(options) {
    // console.log('DeploymentsRouter::ctor:options:\n', options);
    this._router = new Router();
    const otherThing = new options.Thing();
    this.setupRoutes(this._router, options, otherThing);
  }

  get router() {
    return this._router;
  }

  get routes() {
    return this._router.routes();
  }

  setupRoutes(router, { deployments }, otherThing) {

    router.param('name', (ctx, next, name) => {
      ctx.state.name = name;
      ctx.state.other = otherThing;
      return next();
    });

/**
 * @swagger
 * /examples:
 *   post:
 *     tags:
 *       - examples
 *     operationId: create example
 *     description: |
 *       Creates an `Example`.
 *     parameters:
 *       - name: name
 *         in: path
 *         description: Name of the Example
 *         required: true
 *         type: string
 *       - name: example
 *         in: body
 *         description: Example data to use
 *         required: true
 *         type: object
 *         schema:
 *           $ref: '#/definitions/ExampleUpdate'
 *     responses:
 *       # Response code
 *       200:
 *         description: Successfully updated the Example
 *         schema:
 *           $ref: '#/definitions/Example'
 *       201:
 *         description: Successful creation of Example
 *         schema:
 *           $ref: '#/definitions/Example'
 *       default:
 *         description: unexpected error
 *         schema:
 *           $ref: '#/definitions/Error'
 */

    router.post('/', async (ctx, next) => {
      // console.log('api: request body:\n', ctx.request.body);
      const { body } = ctx.request;
      const { name } = ctx.state;

      ctx.status = 201;
      const rv = Object.assign({
        otherStuff: 0,
      }, body, {
        name,
        anotherThing: 'and another thing...',
      });
      ctx.body = {
        example: rv,
      };
      return await next();
    });

/**
 * @swagger
 * /examples/{name}:
 *   put:
 *     tags:
 *       - examples
 *     operationId: set example
 *     description: |
 *       Creates or Updates an `Example`.
 *     parameters:
 *       - name: name
 *         in: path
 *         description: Name of the Example
 *         required: true
 *         type: string
 *       - name: example
 *         in: body
 *         description: Example data to use
 *         required: true
 *         type: object
 *         schema:
 *           $ref: '#/definitions/ExampleUpdate'
 *     responses:
 *       # Response code
 *       200:
 *         description: Successfully updated the Example
 *         schema:
 *           $ref: '#/definitions/Example'
 *       201:
 *         description: Successful creation of Example
 *         schema:
 *           $ref: '#/definitions/Example'
 *       default:
 *         description: unexpected error
 *         schema:
 *           $ref: '#/definitions/Error'
 */

    router.put('/:name', async (ctx, next) => {
      // console.log('api: request body:\n', ctx.request.body);
      const { body } = ctx.request;
      const { name } = ctx.state;
      const create = true;

      ctx.status = create ? 201 : 200;
      const rv = Object.assign({
        otherStuff: 0,
      }, body, {
        name,
        anotherThing: 'and another thing...',
      });
      ctx.body = {
        example: rv,
      };
      return await next();
    });

/**
 *  @swagger
 *  /examples/{name}:
 *    get:
 *      tags:
 *        - examples
 *      description: Retrieve an `Example`
 *      operationId: get example
 *      parameters:
 *        - name: name
 *          in: path
 *          description: Name of the Example
 *          required: true
 *          type: string
 *      responses:
 *        "200":
 *          description: successfully retrieved Example
 *          schema:
 *            $ref: '#/definitions/Example'
 *        "404":
 *          description: Example not found
 *          schema:
 *            $ref: '#/definitions/Error'
 *        default:
 *          description: unexpected error
 *          schema:
 *            $ref: '#/definitions/Error'
 */

    router.get('/:name', async (ctx, next) => {
      const { name } = ctx.state;
      ctx.status = 200;
      ctx.body = {
        example: {
          name: `a-name as '${name}'`,
          requiredStuff: 'something I want to put here',
          otherStuff: 32,
          anotherThing: 'and another thing...',
        },
      };
      return await next();
    });

/**
 * @swagger
 * /examples/{name}:
 *   delete:
 *     tags:
 *       - examples
 *     description: |
 *       Delete an `Example`
 *
 *       Returns original `Example`
 *     operationId: delete example
 *     parameters:
 *       - name: name
 *         in: path
 *         description: Name of the `Example`
 *         required: true
 *         type: string
 *     responses:
 *       "202":
 *         description: successfully deleted `Example`
 *         schema:
 *           $ref: '#/definitions/Example'
 *       "404":
 *         description: Example not found
 *         schema:
 *           $ref: '#/definitions/Error'
 *       default:
 *         description: unexpected error
 *         schema:
 *           $ref: '#/definitions/Error'
 */

    router.delete('/:name', async (ctx, next) => {
      const { name } = ctx.state;
      ctx.status = 200;
      ctx.body = {
        example: {
          name: `a-name as '${name}'`,
          requiredStuff: 'something I want to put here',
          otherStuff: 32,
          anotherThing: 'and another thing...',
        },
      };
      return await next();

    });


    return router;
  }

}

export default ExampleRouter;