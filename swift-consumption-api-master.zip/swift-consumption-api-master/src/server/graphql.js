import { merge } from 'lodash';
import { inspect } from 'util';
import moment from 'moment';
import Koa from 'koa';
import cors from 'kcors';
import bodyParser from 'koa-bodyparser';
import koaRouter from 'koa-router';
import koaJwt from 'koa-jwt';
import path from 'path';
import fs from 'fs';
import https from 'https';
import enforceHttps from 'koa-sslify';
import Cleanup from '../lib/utils/cleanup';
import settings from '../config';
import { graphqlKoa, graphiqlKoa } from 'graphql-server-koa';
import schema from '../data/schemas';
import pkg from '../../package.json';
import logger from '../lib/logger';
import koaLogger from '../lib/logger/koa-logger';
import { BigTableConnector, prepareOptions as btPrepareOpts } from '../data/connectors/bigtable';
import DiagnosticMiddleware from '../middleware/endpoint/diagnostic-middleware';
import APIMiddleware from '../middleware/endpoint/api-middleware';
import { MongoDbConnector } from '../data/connectors/mongodb';
import { BigTableModels } from '../data/models/bigtable';
import { MongoDbModels } from '../data/models/mongodb';
import NodeCache from 'node-cache';

const started = moment();

const { gql, bigtable, mongo, auth, healthCheck } = settings;

const getUserInfo = function({ request }) {
  if (!request || !request.body || !request.body.userInfo)
    return null;

  return request.body.userInfo;
};

const btOptions = btPrepareOpts(bigtable);

const btConnector = new BigTableConnector(btOptions);
const mongoConnector = new MongoDbConnector(mongo);
const metadataCache = new NodeCache( { stdTTL: 300 } );

async function start() {
  const btModels = new BigTableModels({ connector: btConnector });
  await mongoConnector.connect();
  const mongoModels = new MongoDbModels({ connector: mongoConnector });

  const app = new Koa();

  app.use(koaLogger());

  app.use(cors({
    origin: auth.uiEnvironmentUri,
    allowMethods: ['GET', 'POST', 'OPTIONS'],
    allowHeaders: ['Content-Type,Cookie'],
    credentials: true,
    exposeHeaders: ['Set-Cookie', 'Cookie']
  }));

  console.log('Auth enabled: ', !auth.disabled);
  if (!auth.disabled) {
    app.use(async (ctx, next) => {
      return await next().catch((err) => {
        if (401 == err.status) {
          ctx.status = 401;
          ctx.body = 'Protected resource, use Authorization header to get access\n';
        }
      });
    });

    app.use(koaJwt({
      secret: auth.secret,
      cookie:'swiftConsumption'
    }).unless({ path: [/^\/service/, /^\/diagnostic/, /^\/metrics/]}));
  }

  app.use(async (ctx, next) => {
    const started = new moment();
    logger.info(`api: ${ctx.method.toUpperCase()} ${ctx.originalUrl} started ${started.toISOString()}`);
    await next();
    const elapsedMs = +moment() - +started;
    logger.info(`api: ${ctx.method.toUpperCase()} ${ctx.originalUrl} took ${elapsedMs} ms`);
    ctx.set('X-Accel-Buffering', 'no');
  });

  app.use(bodyParser());

  const apiRouter = APIMiddleware.configure(mongoModels, metadataCache);
  const diagnosticRouter = DiagnosticMiddleware.configure();

  const middlewares = [apiRouter, diagnosticRouter];
  
  middlewares.forEach(middleware => {
    app.use(middleware.routes());
    app.use(middleware.allowedMethods());
  });


  const serviceRouter = new koaRouter({
    prefix: '/service'
  });

  // health check endpoint
  serviceRouter.get(healthCheck.endpoint, async (ctx, next) => {
    ctx.status = 200;
    ctx.body = {
      status: 'ok',
    };
    return await next();
  });

  app.use(serviceRouter.routes());
  app.use(serviceRouter.allowedMethods());

  const gqlRouter = new koaRouter();

  // cache static metadata
  const currentYear = new Date().getFullYear();
  const calendar = await mongoModels.calendar.getRange(currentYear - 2,  currentYear);

  for (var i = 0; i < calendar.length; i++) {
    metadataCache.set('day:' + calendar[i].day, calendar[i], 1000000000);
  }

  var gqlOptions = {
    schema: schema,
    context: {
      bt: btModels,
      mongodb: mongoModels,
      metadataCache: metadataCache
    },
    logger: {
      log: (err) => logger.info('GraphQL General Error: %s', inspect(err, false, null, false)),
    },
  };

  gqlRouter.post('/graphql', graphqlKoa(ctx =>     
    merge(gqlOptions, {
      context: {
        ...gqlOptions.context,
        userInfo: getUserInfo(ctx)
      }
    })
  ));
  gqlRouter.get('/graphql', graphqlKoa(gqlOptions));
  gqlRouter.get('/graphiql', graphiqlKoa({ endpointURL: '/graphql', query: '' }));

  app.use(gqlRouter.routes());
  app.use(gqlRouter.allowedMethods());

  const cert = path.join(__dirname, '..', 'config', 'certs', 'cert.pem');
  const key = path.join(__dirname, '..', 'config', 'certs', 'key.pem');

  let environment = '';

  if(process.env.NODE_ENV === 'local') {
    environment = 'https://localhost:8886';
    app.use(enforceHttps());
    var options = {
      key: fs.readFileSync(key),
      cert: fs.readFileSync(cert)
    };
    https.createServer(options, app.callback()).listen(8886);
  } else {
    environment = `http://localhost:${gql.port}`;
    app.listen(gql.port, () => logger.info(`Started API GraphQL server version ${pkg.version} @ ${started.format('YYYY-MM-DD hh:mm:ss')}`)); 
  }
  logger.info(`start listening on server ${environment}`);
}


function stop(app) {
  console.log('Stopping GraphQL Server');
  app.close();
}

Cleanup(async function () {
  logger.info('Attempting to cleanup');
});

module.exports = {
  start,
  stop
};
