// leave comment: babel cannot correctly transpile import on first line of invoked script
import graphqlServer from './graphql';

graphqlServer.start();