const HttpConstants = {
  OK: 200,
  BADREQUEST: 400,
  UNAUTHORIZED: 401,
  SERVERERROR: 500
};

export default HttpConstants;