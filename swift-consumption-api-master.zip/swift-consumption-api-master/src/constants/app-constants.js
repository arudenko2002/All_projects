const APPConstants = {
  APP_NAME: 'swiftConsumption'
};

export default APPConstants;