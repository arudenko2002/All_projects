export default class CookieHelper {
  setCookie(ctx, name, value, domain, expire) {
    ctx.cookies.set(name, value, { domain: domain, expires: expire, httpOnly: false});
  }

  getCookie(ctx, name) {
    return ctx.cookies.get(name);
  }
}