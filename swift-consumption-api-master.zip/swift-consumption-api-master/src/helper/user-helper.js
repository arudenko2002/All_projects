export default class UserHelper {
  async getUserArtists(userInfo, mongodb, metadataCache) {
    const artists = [];
    
    if(!userInfo) {
      return artists;
    }
  
    if(Array.isArray(userInfo.accessArtists)) {
      userInfo.accessArtists.forEach(artist => {
        artists.push(artist._id);
      });
    }
    
    if(userInfo.defaultLabel && userInfo.defaultLabel.id) {
      let labelArtists = null;
      
      let cacheKey = 'label' + userInfo.defaultLabel.id;
      labelArtists = metadataCache.get(cacheKey);
      if(!labelArtists) {
        labelArtists = await mongodb.artist.getArtistsByLabel(userInfo.defaultLabel.id);
        if(labelArtists) {
          metadataCache.set(cacheKey, labelArtists);
        }     
      }
      if(Array.isArray(labelArtists)) {
        labelArtists.forEach(artist => {
          artists.push(artist._id);
        });
      }
    }
    
    return artists;
  }
}