/**
 * Label Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var LabelSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Label Family ID',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Label Title',
    trim: true
  },
  financialLabel: {
    type: String,
    trim: true
  },
  subLabels: [{
    type: Schema.ObjectId,
    ref: 'Label'
  }],
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Label', LabelSchema);

LabelSchema.pre('save', function(next) {
  var label = this;
  label.lastUpdated = Date.now();
  console.log(`Label ${label.title} updated on ${label.lastUpdated}`);
  next();
});

module.exports = LabelSchema;