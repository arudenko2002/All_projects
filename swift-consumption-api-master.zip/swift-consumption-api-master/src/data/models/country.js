/**
 * Country Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var CountrySchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Country Code',
    trim: true,
    unique: true
  },
  name: {
    type: String,
    required: 'Please enter a Country Name',
    trim: true
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Country', CountrySchema);

CountrySchema.pre('save', function(next) {
  var country = this;
  country.lastUpdated = Date.now();
  console.log(`Country ${country.name} updated on ${country.lastUpdated}`);
  next();
});

module.exports = CountrySchema;