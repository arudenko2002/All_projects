/**
 * Genre Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var GenreSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Genre Code',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Genre Title',
    trim: true
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Genre', GenreSchema);

GenreSchema.pre('save', function(next) {
  var genre = this;
  genre.lastUpdated = Date.now();
  console.log(`Genre ${genre.title} updated on ${genre.lastUpdated}`);
  next();
});

module.exports = GenreSchema;