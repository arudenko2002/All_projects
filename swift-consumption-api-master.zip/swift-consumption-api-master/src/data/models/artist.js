/**
 * Artist Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var ArtistSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Master Artist ID',
    trim: true,
    unique: true
  },
  name: {
    type: String,
    required: 'Please enter an Artist Name',
    trim: true
  },
  genres: [{
    type: String,
    ref: 'Genre'
  }],
  imageUrl: {
    type: String,
    required: 'Please enter the Artist Image URL',
    trim: true
  },
  projects: [{
    type: Schema.ObjectId,
    ref: 'Project'
  }],
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

const ArtistModel = mongoose.model('Artist', ArtistSchema);

ArtistSchema.pre('save', function(next) {
  var artist = this;
  artist.lastUpdated = Date.now();
  console.log(`Artist ${artist.name} updated on ${artist.lastUpdated}`);
  next();
});

export { ArtistSchema };
export default ArtistModel;
