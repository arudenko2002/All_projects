/**
 * Release Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var ReleaseSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Release ID',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Release Version Title',
    trim: true
  },
  artist: {
    type: Schema.ObjectId,
    ref: 'Artist',
    required: 'Please specify the Artist for this Release'
  },
  project: {
    type: Schema.ObjectId,
    ref: 'Project',
    required: 'Please specify the Project for this Release'
  },
  product: {
    type: Schema.ObjectId,
    ref: 'Product',
    required: 'Please specify the Product for this Release'
  },
  releaseType: {
    type: String,
    required: 'Please enter a Release Type',
    enum: ['A', 'T', 'V']
  },
  genre: {
    type: Schema.ObjectId,
    ref: 'Genre',
    required: 'Please specify the Genre for this Release'
  },
  upc: {
    type: String,
    required: 'Please enter a UPC for this Release'
  },
  isrc: {
    type: String,
    required: 'Please enter an ISRC for this Release'
  },
  product_release_date: {
    type: Date
  },
  origin_release_date: {
    type: Date
  },
  project_release_date: {
    type: Date
  },
  earliest_resource_release_date: {
    type: Date
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Release', ReleaseSchema);

ReleaseSchema.pre('save', function(next) {
  var release = this;
  release.lastUpdated = Date.now();
  console.log(`Release ${release.title} updated on ${release.lastUpdated}`);
  next();
});

module.exports = ReleaseSchema;