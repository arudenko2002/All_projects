/**
 * Partner Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var PartnerSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Partner ID',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Partner Title',
    trim: true
  },
  invoiceAccount: {
    type: String,
    trim: true
  },
  subAccountCode: {
    type: String,
    trim: true
  },
  subAccountName: {
    type: String,
    trim: true
  },
  gtCountryCode: {
    type: Schema.ObjectId,
    ref: 'Country'
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Partner', PartnerSchema);

PartnerSchema.pre('save', function(next) {
  var partner = this;
  partner.lastUpdated = Date.now();
  console.log(`Partner ${partner.title} updated on ${partner.lastUpdated}`);
  next();
});

module.exports = PartnerSchema;