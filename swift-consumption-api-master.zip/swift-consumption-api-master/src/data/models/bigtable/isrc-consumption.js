/*

Encapsulates consumption metrics at the ISRC level

*/

// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';

export class IsrcConsumption extends Consumption {
  
  constructor(connector) {
    super(connector, connector.tableNames.isrc);
    this.level = 'track';
    this.families = ['units', 
      'euro',
      'track_adjusted_units'
    ];


    //101520114#C#GB#ALL#S#UK02#D#20161109#USIR19600471#
    this.periodPositionInKey = 6;

  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    return keyVals.trackId + '#' 
      + super.buildStartKey(filters, datePeriod);

  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {

    return keyVals.trackId + '#' 
      + super.buildEndKey(filters, datePeriod);

  }

  //override
  reverseKey(rowKey) {
    const [trackId, territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate, isrc] = rowKey.split('#');
    return {
      trackId,
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId,
      isrc
    };
  }

  
  async relatedIsrcs(context, trackId, dateRange, filters = {}, select = [],  sort = [], requestedPrecision) {

    const keyVals = {
      trackId
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    return await this.listData(context, btReadOptions, dateRange, requestedPrecision, this.periodPositionInKey);
    
  }


  
}

