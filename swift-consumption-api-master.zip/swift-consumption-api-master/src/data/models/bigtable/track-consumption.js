/*

Encapsulates consumption metrics at the track level

*/

// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';

export class TrackConsumption extends Consumption {
  
  constructor(connector) {
    super(connector, connector.tableNames.track);
    this.level = 'track';
    this.families = ['units', 
      'euro',
      'audio_stream_units',
      'audio_stream_euro',
      'video_stream_units',
      'video_stream_euro',
      'digital_track_units',
      'digital_track_euro',
      'track_adjusted_units',
      'audio_stream_track_adjusted_units',
      'video_stream_track_adjusted_units',
      'digital_track_track_adjusted_units',
      'album_adjusted_units',
      
    ];

    //10087148#R#63#1234#S#GER01#D#20160803#
    this.periodPositionInKey = 6;

  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    return keyVals.artistId + '#' 
      + super.buildStartKey(filters, datePeriod);

  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {

    return keyVals.artistId + '#' 
      + super.buildEndKey(filters, datePeriod);

  }

  //override
  reverseKey(rowKey) {
    const [artistId, territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate, projectId, trackId] = rowKey.split('#');
    return {
      artistId,
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId,
      projectId, 
      trackId
    };
  }

  async executeDetailsQuery(context, track, dateRange, filters = {}, select = [], groups = [], outputPrecision) {

    const keyVals = {
      artistId: track.artist.id,
      projectId: track.project.id,
      trackId: track.id
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, groups, context);

    // add a row filter by key for ranges 
    // so we need to construct a filter that would wildcard the dates 
    // so it looks like 10143644#A#ALL#ALL#S#GER01#\C*#\C*#10143644#11817960#
    if (btReadOptions.ranges) {

      //construct RegEx for the row filter
      const rowFilter = new RegExp(
      '\\C*' + '#' + 
      track.id + '#');

      btReadOptions.filter.push({row: rowFilter});

    } else if (btReadOptions.keys) {
      //if it's just one key, we need to add projectId and trackId at the end of it
      btReadOptions.keys[0] += keyVals.projectId + '#' + keyVals.trackId + '#';

    }

    console.log(inspect(btReadOptions, false, null, false));


    return await this.detailsData(context, btReadOptions, dateRange, 
      groups, outputPrecision, this.periodPositionInKey);
    
  }

  async artistTracks(context, artistId, dateRange, filters = {}, select = [],  sort = [], requestedPrecision) {

    const keyVals = {
      artistId
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    return await this.listData(context, btReadOptions, dateRange, requestedPrecision, this.periodPositionInKey);
    
  }

  async projectTracks(context, project, dateRange, filters = {}, select = [],  sort = [], requestedPrecision) {

    const keyVals = {
      artistId: project.artist.id,
      projectId: project.id
    };

    const btReadOptions = await super.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    // add a row filter by key for ranges 
    if (btReadOptions.ranges) {

      //construct RegEx for the row filter
      const rowFilter = new RegExp(
      '\\C*#' + keyVals.projectId + '#\\C*');

      btReadOptions.filter.push({row: rowFilter});

    } else if (btReadOptions.keys) {
      //if it's just one key, we need to add projectId and trackId at the end of it
      btReadOptions.keys[0] += keyVals.projectId + '#' + keyVals.trackId + '#';

    }

    console.log(inspect(btReadOptions, false, null, false));



    return await this.listData(context, btReadOptions, dateRange, requestedPrecision, this.periodPositionInKey);
    
  }


  
}

