import pad from 'pad-left';

import { debugLog, dumpLog } from '../../../lib/logger';
const debug = debugLog('models', 'bigtable', 'keymappers');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('models', 'bigtable', 'keymappers');


/**
 * maps a Period value to the representation of a Period
 * in BigTable
 * 
 * @param {Period} period 
 * @returns string used for the Period in a BigTable Row Key
 */
function periodToKey(period) {
  //console.log('Period: %s', period);
  return period.toString()[0].toUpperCase();
}
export { periodToKey };


/**
 * maps an Interval value with a Period and Date to the 
 * representation of the Date in BigTable
 * 
 * @param {string} period period of the Interval
 * @param {object} date date of the Interval
 * @param {string} date.year year of the date
 * @param {string} date.quarter quarter for the date if period = Quarter
 * @param {string} date.month month for the date if period = Month | Day
 * @param {string} date.week week in year for the date if period = Week
 * @param {string} date.day day in the month for the date if period = Day
 * @returns string used for the Interval Date in a BigTable Row Key
 */
function intervalToDateKey(period, { year, quarter, month, week, day }) {
  debug('intervalToDateKey called with period %s', period);
  debug('intervalToDateKey called with date: year=%s, quarter=%s, month=%s, week=%s, day=%s',
    year, quarter, month, week, day);
  switch (period) {
    case 'Year':
      return year.toString();
    case 'Quarter':
      return `${year}${pad(quarter, 2, '0')}`;
    case 'Month':
      return `${year}${pad(month, 2, '0')}`;
    case 'Week':
      return `${year}${pad(week, 2, '0')}`;
    case 'Day':
      return `${year}${pad(month, 2, '0')}${pad(day, 2, '0')}`;
  }
  return 'ALL';
}
export { intervalToDateKey };

function territoryTypeToKey(territoryType = 'A') {
  return territoryType.toString()[0].toUpperCase();
}
export { territoryTypeToKey };

function territoryToKey({ type, id } = { type: 'A', id: 'ALL' }) {
  return `${territoryTypeToKey(type)}#${id}`;
}
export { territoryToKey };

function partnerToKey(partnerId) {
  return partnerId.toString();
}
export { partnerToKey };

function labelTypeToKey(labelType = 'A') {
  //we only write to keys if it's 'A' or 'S' (segment)
  return labelType === 'Segment' ? 'S' : 'A'; 
}
export { labelTypeToKey };

function labelToKey({ type, id } = { type: 'A', id: 'ALL' }) {
  //we only write to keys if it's 'A' or 'S' (segment)
  return type === 'Segment' ? `${labelTypeToKey(type)}#${id}` : 'A#ALL';
}
export { labelToKey };

function rankToKey(rank = 0, filters = {}) {
  //if top performers need to be filtered by metadata stored inside column families in BT
  //we need to "cast wider net" in key ranges 
  if ((filters.genres && filters.genres.length) || // if genre filter is selected
      (filters.labels && filters.labels.length && filters.labels[0].type == 'Family') || //or if label family filter is selected
    filters.catalog ) {

    return '10001';

  } else {

    return pad(`${rank + 1}`, 5, '0');
  }
      
}
export { rankToKey };
