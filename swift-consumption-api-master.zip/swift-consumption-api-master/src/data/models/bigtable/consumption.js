// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import cartesian from 'cartesian';
import RxNode from 'rx-node';
import { map, mapValues, chain, orderBy, isFunction } from 'lodash';
import { getDayMetadata, getTerritoryMetadata } from '../../../lib/utils/metadata-utils';
import { getMonthQuarter } from '../../scalars/date-scalars';
import { tryParseFloat } from '../../../lib/utils/bigtable-utils';
import * as columnMap from './column-mappers';
import { Observable, CompositeDisposable } from 'rx';
import { LEVEL_TO_METADATA_COLUMN_FAMILY_MAP, ARTIST_PROJECT_PROP_MAP, TRACK_PROP_MAP, REVERSE_COUNT_TYPE_MAP } from './column-mappers';
import logger from '../../../lib/logger';
import intersect from 'intersect';
import diff from 'arr-diff';

/*
  Parent class for all consumption classes
*/
export class Consumption {

  constructor(connector, table) {
    this.connector = connector;
    this.table = connector.table(table);
    this.level = ''; //override in the child classes to 'artist, 'project', 'track'
    this.families = ['units', 
      'digital_track_units',
      'stream_units',
      'airplay_units',
      'audio_stream_units',
      'video_stream_units',
      'track_adjusted_units',
      'digital_track_track_adjusted_units',
      'stream_track_adjusted_units',
      'audio_stream_track_adjusted_units',
      'video_stream_track_adjusted_units',
      'euro',
      'physical_album_euro',
      'digital_album_euro',
      'digital_track_euro',
      'stream_euro',
      'airplay_euro',
      'audio_stream_euro',
      'video_stream_euro'];
    this.regionAggregationStrategy = null; //AddCountries or NegateFromGlobal are the options
    this.regionAggregateCode = null; //stores the region code to substitute in keys with country aggregates
    
  }

  /*
    Tests connectivity. Returns true if connected successfully to a table in BigTable
  */
  async testConnect() {
    const rows = await this.table.getRows({limit: 1});
    if(rows && 
       rows[0][0].id &&
       rows[0][0].data);
    return true;

  }

  /*
    Constructs select filter for reducing the number of columns returned from BT
  */
  getSelectFilter(userInfo, filters, select = [], groupCounts = []) {


    //declare default filter that is equivalent to no filter at all
    var filter = { all: true };
    var columnFilters;

    //filter out column families that user is not supposed to see
    const allowedFamilies = [];

    //if we have explicit selection of columns
    if (select.length) {
      for (var i=0; i<select.length; i++) {
        if (!(select[i].prop.toLowerCase().includes('euro') && !userInfo.canView)) {
          
          allowedFamilies.push(this.level == 'artist' || 
                    this.level == 'project' ||
                    this.level == 'album' ? ARTIST_PROJECT_PROP_MAP[select[i].prop] : TRACK_PROP_MAP[select[i].prop]);
        }
      } // else, if there is no explicit selection, but there is a restriction on euro
    } else if (!select.length && !userInfo.canView) {
      
      for (var j=0; j<this.families.length; j++){
        if (!this.families[j].includes('euro')) {
          allowedFamilies.push(this.families[j]);
        }
      }
    }

    // if there are no groupCounts or if groupCounts type = Totals we only select family filter
    if (allowedFamilies.length &&
        (!groupCounts || groupCounts.length == 0 ||
        (groupCounts && 
         groupCounts.length && 
         groupCounts[0].type == 'Totals'))) {
      columnFilters = allowedFamilies.map(f => {
        return [ 
          {
            family: f
          }
        ];
      });
    // if groupCounts are not Totals we add RegEx on column filter
    } else if (allowedFamilies.length &&
              groupCounts && 
              groupCounts.length) {
      columnFilters = allowedFamilies.map(f => {
        return [ 
          {
            family: f
          },
          {
            column: new RegExp('\\C*' + REVERSE_COUNT_TYPE_MAP[groupCounts[0].type]  + '\\C*')
          }
        ];
      });
    }
    //console.log('Column Filters: %s', inspect(columnFilters, false, null, false));
    // if there is more than one column to return, add 'interleave' 
    //to achieve 'OR' logic
    if (allowedFamilies.length) {
      if (columnFilters.length === 1) {
        filter = columnFilters[0];
        
      } else {
        filter = {
          interleave: 
            columnFilters
          
        };
      }
    }
    return filter;
  }


  /*
    Constructs filter that filters by metadata stored in BT
  */
  getMetadataFilter(filters) {

    //declare default filter that is equivalent to no filter at all
    var filter = { all: true };

    //build filters that go into metadata column families in BT: genres, label families and catalogue
    if ((filters.genres && filters.genres.length) || // if genre filter is selected
      (filters.labels && filters.labels.length && filters.labels[0].type == 'Family') || //or if label family filter is selected
      this.filters.catalog) //or if catalog toggle is selected
    {
      //check if there is mapping defined between query type and metadata column family
      const metadataFamily = LEVEL_TO_METADATA_COLUMN_FAMILY_MAP[this.level];
      if (!metadataFamily) {
        throw new Error('There is no mapping defined between query type and metadata column family in column-mappers');
      }

      //we should construct  'condition' statement
      //read more on it: https://googlecloudplatform.github.io/google-cloud-node/#/docs/bigtable/0.9.1/bigtable/filter?method=condition
      filter = {
        condition: {
          test: [],
          pass: []
        }
      };

      //in order to implement 'AND' logic on filters we need to chain them by writing another 'condition'
      //into the 'pass' part of the previous 'condition'

      // write test part of the condition for genre filter

      //console.log('Genres length: %s', );

      
      filter.condition.test.push(
        {
          family: metadataFamily
        },
        {
          column: 'gnr',
          cellLimit: 1
        },
        {
          value: new RegExp('\\C*' + 
            ((filters.genres && filters.genres.length) ? filters.genres[0] : '' )  + '\\C*')
        }

      );

      // write test part of the condition for label family into pass part of the genre filter
      filter.condition.pass.push(
        {
          condition: {
            test: [
              {
                family: metadataFamily
              },
              {
                column: 'lfm',
                cellLimit: 1
              },
              {
                value: new RegExp('\\C*' + 
                  ( (filters.labels && filters.labels.length && filters.labels[0].type == 'Family') ? filters.labels[0].id : '')   + '\\C*')
              }
            ],
            pass: [ 
              {
                all: true
              }
            ]
          }
        }

      );
    
    }
    
    return filter;
  }
  
  /*
    Apply some logic transforming the values depending on keys
  */
  applyTransform(key, value) {

    //Transformation for region aggregation
    if (this.regionAggregationStrategy == 'NegateFromGlobal') {

      //negation from global, will have two types of region keys returned 
      //#A#ALL for Global and #C#<country code> for regions we need to negate
      //so we just negate the ones that don't have 'A' in them
      const keyParts = key.split('#');
      if (keyParts[1] == 'A')
        return value;
      else 
        return -value;
    } else {
      return value;
    }

  }

  /*
    Convert filters to keys be used in BT query options
  */
  filterToKeys(filters = {}) {

    let { 
      partners:partner = ['ALL'], 
      territories:territory = [{ type: 'A', id: 'ALL' }], 
      genres:genre = ['ALL'], 
      labels:label = [{ type: 'A', id: 'ALL' }],
      catalogue:catalogue = 'ALL'
    } = filters || {};

    if (!partner.length) 
      partner = ['ALL'];
    if (!territory.length)
      territory = [{ type: 'A', id: 'ALL' }];
    if (!genre.length)
      genre = ['ALL'];
    if (!label.length)
      label = [{ type: 'A', id: 'ALL' }];
   
    switch(catalogue.toLowerCase()) {
      case 'yes':
        catalogue =  ['Y'];
        break;
      case 'no':
        catalogue = ['N'];
        break;
      default: 
        catalogue = ['ALL'];
    }
  

    return {
      territory: territory.map(t => {
        return ((t.type == 'Region') ? 'R' : 
                (t.type == 'Country') ? 'C' : 'A') + '#' + t.id;
      }),
      partner: partner,
      genre: genre,
      label: label.map(t => {
        return ((t.type == 'Segment') ? 'S' : 
                (t.type == 'Family') ? 'F' : 'A') + '#' + t.id;
      }),
      catalogue: catalogue
    };
  }

  /*
    Converts date range to keys to be used in BT query options
  */
  dateRangeToKeys(dateRange) {

    const p = dateRange.precision.toLowerCase();

    switch (p) {
      
      case 'year':
        //Y#YYYY
        return {
          start: 'Y#' + dateRange.startDate.year,
          end: 'Y#' + dateRange.endDate.year
        };
      case 'quarter':
        //Q#YYYYQQ
        return {
          start: 'Q#' + dateRange.startDate.year + dateRange.startDate.quarter,
          end: 'Q#' + dateRange.endDate.year + dateRange.endDate.quarter
        };
      case 'month':
        //M#YYYYMM
        return {
          start: 'M#' + dateRange.startDate.year + dateRange.startDate.month,
          end: 'M#' + dateRange.endDate.year + dateRange.endDate.month
        };
      case 'week':
        //W#YYYYWW
        return {
          start: 'W#' + dateRange.startDate.year + dateRange.startDate.week,
          end: 'W#' + dateRange.endDate.year + dateRange.endDate.week
        };
      case 'day':
        //D#YYYYMMDD
        return {
          start: 'D#' + dateRange.startDate.year + dateRange.startDate.month + dateRange.startDate.day,
          end: 'D#' + dateRange.endDate.year + dateRange.endDate.month + dateRange.endDate.day
        };
      default:
        return {
          start: 'A#ALL',
          end: 'A#ALL'
        };

    }

  }

  /*
    Builds a start key for BigTable based on date ranges and filters
  */
  // eslint-disable-next-line no-unused-vars
  buildStartKey(filters, datePeriod, keyVals = {}) {

    const { territory, partner, label } = filters;

    return territory + '#' +
      partner + '#' +
      label + '#' +
      datePeriod + '#';
    
   
  }

  /*
    Builds an end key for BigTable based on date ranges and filters
  */

  // eslint-disable-next-line no-unused-vars
  buildEndKey(filters, datePeriod, keyVals = {}) {

    //this is almost identical to buildStartKey, but it adds +1 into the endDate
    //because to get the data from BT for month 201610, for example
    //you need to specify 
    //start:10001184#C#US#ALL#S#LAT01#M#201610
    //end: 10001184#C#US#ALL#S#LAT01#M#201611

    //if we need to get for month 201612, we will still add +1 
    //making it as
    //start: 10001184#C#US#ALL#S#LAT01#M#201612
    //end: 10001184#C#US#ALL#S#LAT01#M#201613
    //Despite, 201613 is incorrect month, BT doesn't care 
    //and since the next correct month key is 201701,
    //lexicographically it will still return the correct result

    //DS: (2017-96-19) this logic has been updated with a new node client
    //so we don't need this anymore. Will keep this message for history,
    //and will remove it at some point once all testing goes through successfully

    const { territory, partner, label } = filters;

    var key = territory + '#' +
      partner + '#' +
      label + '#';

    var adjustedEndDate = (datePeriod == 'A#ALL') ? 'B#ALL' : 
      (datePeriod.split('#')[0] + '#' + (parseInt(datePeriod.split('#')[1]) + 1));

    return key + adjustedEndDate + '#';

   

  }

  /*
    Builds key ranges for the BigTable query options
  */
  async buildKeyRanges(filters, dateRange, keyVals = {}, context) {

    try {

      //clear state
      this.regionAggregationStrategy = null; //AddCountries or NegateFromGlobal are the options
      this.regionAggregateCode = null; //stores the region code to substitute in keys with country aggregates
      

      const filterKeys = this.filterToKeys(filters);
      const dateRangeKeys = this.dateRangeToKeys(dateRange);

      const [territoryType, territoryCode] = filterKeys.territory[0].split('#');
      //console.log('Territory type: %s', territoryType);
      //console.log('Territory code: %s', territoryCode);

      //if region aggregations required build ranges of countries instead
      if (territoryType == 'R' && (
          this.constructor.name == 'AlbumConsumption' ||
          this.constructor.name == 'ArtistConsumption' ||
          this.constructor.name == 'IsrcConsumption' ||
          this.constructor.name == 'ProjectConsumption' ||
          this.constructor.name == 'TrackConsumption')) {

        //create new territory keys, because we are going to be replacing them
        //with list of countries
        filterKeys.territory = [];

        //remember the region code
        this.regionAggregateCode = territoryCode;

        //get region metadata from mongo

        const region = await getTerritoryMetadata(territoryType, territoryCode, context);

        const regionCountries = region.countries;
        //console.log('region countries:', regionCountries);

        //get all countries from mongo
        const countries = await context.mongodb.territory.getAllCountries();
        
        const allCountries = countries.map(function(c) { return c._id; });
        //console.log('all countries:', allCountries);

        console.log('Intersect: %s', intersect(regionCountries, allCountries));
        
        console.log('Difference: %s', diff(allCountries, regionCountries));

        //check if region has more than half of the total list of countries
        //if it does, we can subtract difference of the region from the ALL aggregate.
        //for example, Global ex. US region would have list of all the countries, 
        //except US. Therefore, it's much more performance efficient to 
        //query just two aggregates for Global and US and subtract
        //Global ex. US = Global - US, than add all the aggregates for all the countries.
        //This will work well for "Global Ex. x " regions, but some small regions that 
        //contain only a few countries, should query the actual country aggregates.


        const countryIntersect = intersect(regionCountries, allCountries);

        if (countryIntersect.length > allCountries.length/2 ) {
          console.log('Region has more than half of all the countries. Using Global - [diff]');
          this.regionAggregationStrategy = 'NegateFromGlobal';

          //get countries that don't belong to the region
          const diffCountries = diff(allCountries, regionCountries);

          //add global 
          filterKeys.territory.push('A#ALL');

          //add diff countries
          diffCountries.map( function(c) { filterKeys.territory.push('C#' + c); } );


        } else {

          this.regionAggregationStrategy = 'AddCountries';

          regionCountries.map(function(c) { filterKeys.territory.push('C#' + c); } );

        }
        console.log('Filter keys: %s', JSON.stringify(filterKeys));
    

      }
      

      const permutations = cartesian(
        { partner: filterKeys.partner, 
          territory: filterKeys.territory, 
          genre: filterKeys.genre, 
          label: filterKeys.label,
          catalogue: filterKeys.catalogue });

    
      const keyRanges =  permutations.map(p => ({
        start: this.buildStartKey({
          territory:p.territory, 
          partner: p.partner, 
          label: p.label, 
          genre: p.genre, 
          catalogue: p.catalogue 
        }, dateRangeKeys.start, keyVals),
        end: this.buildEndKey( {
          territory: p.territory, 
          partner: p.partner, 
          label: p.label, 
          genre: p.genre, 
          catalogue: p.catalogue
        }, dateRangeKeys.end, keyVals)
      }));
      
      return keyRanges;

    } catch(err) {
      console.log(err);
    }

  }

  /*
    Build options for BigTable read operation
  */

  async buildBtReadOptions(filters, dateRange, keyVals = {}, select = '', groups  = '', context = null) {

    const keyRanges = await this.buildKeyRanges(filters, dateRange, keyVals, context);

    const btReadOptions =  {
      ranges: keyRanges,
      filter: [
        this.getSelectFilter(context.userInfo, filters, select, groups)
      ],
    };

    return btReadOptions;

  }

   /*
    this is a part of Aggregator functionality. It substitutes the country keys
    for region key, when region values are summated from country aggregates
  */
  substituteKeyForRegion(key) {

    //if there is no aggregation for region happening
    //return key as is
    if (!this.regionAggregateCode)
      return key;
    
    //recreate the key, by substituting country codes with region aggregate codes
    const keyParts = key.split('#');

    var newKey = '';
    for (var i = 0; i < keyParts.length; i++) {
      if (i == 1) {
        newKey += 'R#';
      } else if (i == (2)) {
        newKey += this.regionAggregateCode + '#';
      } else if(keyParts[i] && keyParts[i].length) {
        newKey += keyParts[i] + '#';
      }
    }

    return newKey;

  }

  /*
    this is a part of Aggregator functionality. It substitutes the keys of 
    higher granularity (precision) that come from BigTable with keys of
    lower requested granularity, to be later summarized inside the 
    observable sequence. 
  */
  substituteKeyForPrecision(context, key, keyPrecision, outputPrecision, periodPositionInKey) {

    //if precision doesn't change, return key as is
    if (keyPrecision == outputPrecision)
      return key;

    // break the key into parts
    const keyParts = key.split('#');
    var newPeriodType = 'ALL';
    var newPeriod = 'ALL';

    if (keyPrecision == 'Day' && outputPrecision == 'Week' ) {
      // need to substitute daily key in BT for weekly key
      
      newPeriodType = 'W';
      
      //get calendar data for the date
      const day = keyParts[periodPositionInKey + 1];
      const calendar = getDayMetadata(day, context);
      //console.log('calendar: %s', inspect(calendar,false, null, false));
      newPeriod = calendar.week;

      //console.log('Substitution of day: %s for week: %s', day, newPeriod);

    } else if (keyPrecision == 'Month' && outputPrecision == 'Quarter') {
      // need to substitute monthly key in BT for quarterly key
      
      newPeriodType = 'Q';
      const month = keyParts[periodPositionInKey + 1].substring(4, 6);
      const year = keyParts[periodPositionInKey + 1].substring(0, 4);
      const quarter = getMonthQuarter(month);

      newPeriod = year + quarter;   

    } else if (keyPrecision == 'Month' && outputPrecision == 'Year') {
      // need to substitute monthly key in BT for yearly key
      // 10050354#C#DE#ALL#S#GER01#M#201607#10000315#100099972#
      // the period type is on 6, and month is on 7

      newPeriodType = 'Y';
      newPeriod = keyParts[periodPositionInKey + 1].substring(0, 4);

    }

    var newKey = '';
    for (var i = 0; i < keyParts.length; i++) {
      if (i == periodPositionInKey) {
        newKey += newPeriodType + '#';
      } else if (i == (periodPositionInKey + 1)) {
        newKey += newPeriod + '#';
      } else if(keyParts[i] && keyParts[i].length) {
        newKey += keyParts[i] + '#';
      }
    }

    return newKey;

  }

  /*
    Sorts group data and paginates the results
  */
  sortNpageGroup(source, inclusion) {
    if (inclusion) {
      let { 
        skip = 0, 
        limit = -1, 
        sort = [] 
      } = inclusion;
      skip = skip > -1 ? skip : 0;
      if (sort.length) {
      //debug('going to sort using:', sort);
        source = source.toArray()
        // .do(sup => {
        //   debug('before orderBy pSource is:', sup);
        // })
        .map(partners => {
          let sorted = orderBy(partners,
            sort.map(s => columnMap.mapSortToProp(s.prop, this.level))
              .filter(p => p)
              .map(p => isFunction(p) ? p : c => (c.values[p] || 0)),
            sort.map(({ ordering = 'asc' }) => ordering.toLowerCase())
          );
          // debug('sorted inside stream:', sorted);
          return Observable.from(sorted);
        })
        .concatAll();
        // .do(p => debug('SORTED partner is:', p));
      // TODO: HOW do I get the array result of map back into a sequenced Observable
      }
      source = source.skip(skip);
      if (limit > 0) {
        source = source.take(limit);
      }
    }
    return source;
  }

  /*
    Changes key from a string to an object
  */
  reverseKey(rowKey) {
    const [territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate] = rowKey.split('#');
    return {
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId
    };
  }

  /*
    Reranking top performer list in case if some values were filtered out due to a filter applied
  */
  rerank(rankedList) {

    for(var i=0; i< rankedList.length; i++) {
      rankedList[i].originalRank = rankedList[i].rank;
      rankedList[i].rank = i + 1; 

    }

    return rankedList;
  }

  /*
    Gets source data stream for BigTable
  */
  getSource (context, btReadOptions, dateRange, outputPrecision, periodPositionInKey) {
    
    return RxNode.fromReadableStream(this.table.createReadStream(btReadOptions))
    .selectMany(
        ({ id, data }) => {
          return map(data, (counts, family) => ({
            rowKey: this.substituteKeyForRegion(
        
              this.substituteKeyForPrecision(context, 
                id, dateRange.precision, outputPrecision, periodPositionInKey)
            ),
            family,
            counts: mapValues(counts, ([val]) => {
              return this.applyTransform(id, tryParseFloat(val.value)); }
              )
          }));
        });

  }

  /*
    Source transformations for total counts
  */
  getTotalsSource (source, includeTotals) {
    return source
      .where(({ family }) => !!includeTotals && columnMap.isTotalCount(family))
      .selectMany(
        ({ rowKey, family, counts }) => (map(counts, (value, column) => {
          return {
            rowKey,
            family,
            total: columnMap.parseTotalColumn(family, column),
            value
          };
        }))
      )
      .groupBy(({ rowKey }) => rowKey)
      .flatMap(rkGroup => {
        return rkGroup
            .reduce(({ values: { ...counts }, ...remain }, { total, value }) => (
              {
                ...remain,
                values: {
                  ...counts,
                  [total]: (counts[total] ? counts[total] : 0 ) + value,
                },
              }),
              // initial value for reduce
          {
            rowKey: rkGroup.key,
            values: {},
          });
      });
  }

  /*
    Generic source transformations for all groups
  */
  getGroupsSource(source) {
    return source
      .where(({ family }) => !columnMap.isTotalCount(family))
      .selectMany(
        ({ rowKey, family, counts }) => (map(counts, (value, column) => {
          const mappedCol = columnMap.parseColumn(family, column);
          return {
            rowKey,
            family,
            [mappedCol.name]: mappedCol.id,
            value
          };
        }))
      )
      //.do(row => console.log('Row: %s', inspect(row, false, null, false)))
      ;
  }

  /*
    Transformations for Partner group source
  */
  getPartnersSource(groupSource, includePartner) {
    return groupSource.filter(({ partner }) => !!includePartner && !!partner)
      .groupBy(({ rowKey }) => rowKey)
      .flatMap(rkGroup => {
        let pSource = rkGroup
          .groupBy(({ partner }) => partner)
          
          .flatMap(partnerGroup => {
            return partnerGroup
              
              .reduce(({ values: { ...counts }, ...remain }, { family, value }) => (
                {
                  ...remain,
                  values: {
                    ...counts,
                    [family]: (counts[family] ? counts[family] : 0 ) + value,
                  },
                }
              ),
              // initial value for reduce
              {
                rowKey: rkGroup.key,
                partnerId: partnerGroup.key,
                values: {},
              });
          });
        
        return this.sortNpageGroup(pSource, includePartner);
        
      });

  }

  /*
    Tranformations for Country group source
  */
  getCountriesSource(groupSource, includeCountry) {
    return groupSource
      .filter(({ country }) => !!includeCountry && !!country)
      .groupBy(({ rowKey }) => rowKey)
      .flatMap(rkGroup => {
        let cnSource = rkGroup
          .groupBy(({ country }) => country)
          .flatMap(cnGroup => {
            const countryCode = cnGroup.key;
            return cnGroup
              .reduce(({ values: { ...counts }, ...remain }, { family,  value }) => (
                {
                  ...remain,
                  values: {
                    ...counts,
                    [family]: (counts[family] ? counts[family] : 0 ) + value,
                  },
                }
              ),
              // initial value for reduce
              {
                rowKey: rkGroup.key,
                // country: cnGroup.key,
                territoryType: 'C',
                territoryCode: countryCode,
                values: {},
              });
          });

        return this.sortNpageGroup(cnSource, includeCountry);
      });

  }

  /*
    Transformations for Free vs. Paid Partners group source
  */
  getFreePaidSource(source, includeFreePaid) {
    return source
      .where(({ family }) => !!includeFreePaid && !columnMap.isTotalCount(family) )
      .selectMany(
        ({ rowKey, family, counts }) => (map(counts, (value, column) => {
          //const mappedCol = columnMap.parseColumn(family, column);

          const [countType, id, freePaid] = column.split(':');
          const columnName =  columnMap.countTypeName(countType);
            
          return {
            rowKey,
            family: (freePaid && !(family.includes('euro'))) ? freePaid.toLowerCase() + '_' + family : family,
            [columnName]:id,
            value
          };
        }))
      )
      .filter(({ partner_fp }) => !!includeFreePaid && !!partner_fp)
      //.do(row => console.log('Row: %s', inspect(row, false, null, false)))
      .groupBy(({ rowKey }) => rowKey)
      .flatMap(rkGroup => {
        let pSource = rkGroup
          .groupBy(({ partner_fp }) => partner_fp)
          
          .flatMap(partnerGroup => {
            return partnerGroup
              .reduce(({ values: { ...counts }, ...remain }, { family, value }) => (
                {
                  ...remain,
                  values: {
                    ...counts,
                    [family]: (counts[family] ? counts[family] : 0 ) + value,
                  },
                }
              ),
              // initial value for reduce
              {
                rowKey: rkGroup.key,
                partnerId: partnerGroup.key,
                values: {},
              });
          });
        
        return this.sortNpageGroup(pSource, includeFreePaid);       
      })
      //.do(row => console.log('Row: %s', inspect(row, false, null, false)))
      ;
    
  }

  /*
    Gets the stream of detailed data, such as Artist, Track, Project details with splits by Partner, Country, Locale etc.
  */
  async detailsData(context, btReadOptions, dateRange, groups, outputPrecision, periodPositionInKey) {

    const detailsData = [];

    const groupsToReturn = !groups.length ? groups : chain(groups)
      .keyBy(gc => gc.type.toLowerCase())
      .mapValues(({ paging: { skip = 0, limit = -1 } = { skip: 0, limit: -1 }, sort = [] }) => ({ skip, limit, sort }))
      .value();

    const {
      totals:includeTotals,
      partner:includePartner,
      country:includeCountry,
      freepaid: includeFreePaid
    } = groupsToReturn;

    const source = this.getSource(context, btReadOptions, dateRange, outputPrecision, periodPositionInKey);
    
    const totalsSource = this.getTotalsSource(source, includeTotals);
    
    const groupSource = this.getGroupsSource(source);

    const partnersSource = this.getPartnersSource(groupSource, includePartner);

    const countriesSource = this.getCountriesSource(groupSource, includeCountry);

    const freePaidSource = this.getFreePaidSource(source, includeFreePaid);

    const allSub = Observable.merge(
      totalsSource,
      partnersSource,
      countriesSource,
      freePaidSource
    )
      .subscribe(
        ({ rowKey, values, ...groups }) => {
          // grab the filtering values and interval from the rowKey itself
          const objFromKey = this.reverseKey(rowKey);
          // include additional filtering values depending on the groups this unit counts belongs to
          const keyVals = Object.assign({}, 
            objFromKey,
            groups,
          );
          const aggregate = {
            ...keyVals,
            values,
          };
         
          detailsData.push(aggregate);
        },
        (unitsErr) => logger.error('Error encountered on units subscription:', unitsErr),
        () => logger.info('Units Subscrption completed')
      );

    const promises = Promise.all([
      totalsSource.toPromise(), 
      partnersSource.toPromise(),
      countriesSource.toPromise(),
      freePaidSource.toPromise()
    ]);

    const subscriptions = new CompositeDisposable(
     
      allSub,

    );

    try {

      await promises;
    
      subscriptions.dispose();
     
    }
    catch (err) {
      logger.error('executeQuery error occurred during Observable sequence', err);
      throw(err);
    }

    return detailsData;

  }

  /*
    Returns lists data, such as lists of Projects, Tracks and Albums
  */
  async listData(context, btReadOptions, dateRange, outputPrecision, periodPositionInKey) {

    const listData = [];

    // eslint-disable-next-line no-unused-vars
    const source = RxNode.fromReadableStream(this.table.createReadStream(btReadOptions))
    .selectMany(
        ({ id, data }) => {
          return map(data, (counts, family) => ({
            rowKey: this.substituteKeyForRegion(
              this.substituteKeyForPrecision(
                context, id, dateRange.precision, outputPrecision, periodPositionInKey)
              ),
            family,
            counts: mapValues(counts, ([val]) => {
              return this.applyTransform(id, tryParseFloat(val.value)); }
              )
          }));
        })
    .selectMany(
        ({ rowKey, family, counts }) => (map(counts, (value, column) => {
          return {
            rowKey,
            family,
            total: columnMap.parseTotalColumn(family, column),
            value
          };
        }))
      )
    .groupBy(({ rowKey }) => rowKey)
    .flatMap(rkGroup => {
      return rkGroup
          .reduce(({ values: { ...counts }, ...remain }, { total, value }) => (
            {
              ...remain,
              values: {
                ...counts,
                [total]: (counts[total] ? counts[total] : 0 ) + value,
              },
            }),
            // initial value for reduce
        {
          rowKey: rkGroup.key,
          values: {},
        });
    })
    .map(({ rowKey, values }) => {

      const {
        id,
        ...keyParts,
      } = this.reverseKey(rowKey);

      return {
        id,
        ...keyParts,
        values: {
          ...values
        }
      };    
    })
    .do(row => listData.push(row))
    .toPromise();

    try {

      await source;
    }
    catch (err) {
      logger.error('List data error occurred during Observable sequence: %s', err);
      throw(err);

    }
   
    return await listData;

  }
  
}