// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';
import pad from 'pad-left';
import * as keyMap from './key-mappers';
import logger from '../../../lib/logger';
import * as columnMap from './column-mappers';
import { mapKeys, mapValues } from 'lodash';
import RxNode from 'rx-node';
import { tryParseFloat } from '../../../lib/utils/bigtable-utils';

const DEFAULT_SKIP = 0;
const DEFAULT_LIMIT = 50;

export class TopProjects extends Consumption {

  constructor(connector) {
    super(connector, connector.tableNames.topProjects);
    this.level = 'project';
    this.families = ['project',
      'units', 
      'euro',
      'album_adjusted_units'];

  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    const {territory, partner, label, genre, catalogue} = filters;

    //A#ALL#10101#A#ALL#GPP#ALL#Q#201604#00012#
    return territory + '#' 
      + partner + '#'
      + label + '#'
      + genre + '#'
      + catalogue + '#' 
      + datePeriod + '#' 
      + pad(`${(keyVals.skip || DEFAULT_SKIP) + 1}`, 5, '0') + '#'; 
  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {

    const {territory, partner, label, genre, catalogue} = filters;
    
    return territory + '#' 
      + partner + '#'
      + label + '#'
      + genre + '#'
      + catalogue + '#' 
      + datePeriod + '#' 
      + keyMap.rankToKey((keyVals.skip || DEFAULT_SKIP) + keyVals.limit, {territory, partner, label} || DEFAULT_LIMIT);

  }

  //override
  reverseKey(rowKey) {
    // eslint-disable-next-line no-unused-vars
    const [territoryType, territoryCode, partnerId, labelType, labelId, genre, catalogue, intervalPeriod, intervalDate, rank] = rowKey.split('#');
    return {
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId,
      genre,
      catalogue
    };
  }

  async executeQuery(context, interval, filters = {}, paging = {}) {

    let { skip = DEFAULT_SKIP, limit = DEFAULT_LIMIT } = paging;

    const dateRange = {
      precision: interval.period,
      startDate: interval.date,
      endDate: interval.date
    };

    const keyVals = {
      skip,
      limit
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, '', '', context);


    const topData = [];

    const topSource = RxNode.fromReadableStream(this.table.createReadStream(btReadOptions))
    .map(({ id, data }) => {
      const {
        rank,
        ...totalsQualifiers,
      } = this.reverseKey(id);

      const { project, units, album_adjusted_units, euro = {} } = data;

      const projectValues = mapValues(project, ([val]) => {
        return val.value; }
      );

      const unitValues = mapKeys(units, (_, colName) => {
        return columnMap.parseColumn(columnMap.UNITS, colName).name;
      });
      const unitFloatValues = mapValues(unitValues, ([val]) => {
        return tryParseFloat(val.value); }
      );
     
      const adjustedUnitValues = mapKeys(album_adjusted_units, (_, colName) => {
        return columnMap.parseColumn(columnMap.ALBUM_ADJUSTED_UNITS, colName).name;
      });
      const adjustedUnitFloatValues = mapValues(adjustedUnitValues, ([val]) => {
        return tryParseFloat(val.value); }
      );
     

      const euroValues = mapKeys(euro, (_, colName) => {
        return columnMap.parseColumn(columnMap.EURO, colName).name;
      });
      const euroFloatValues = mapValues(euroValues, ([val]) => {
        return tryParseFloat(val.value); }
      );
     

      return {
        project: projectValues,
        rank,
        totals: {
          ...totalsQualifiers,
          values: {
            ...unitFloatValues,
            ...adjustedUnitFloatValues,
            ...euroFloatValues,
          },
        },
      };
    })
    .do((rankedProject) => topData.push(rankedProject))
    .toPromise();

    try {
      
      await topSource;
      
    }
    catch (err) {
      logger.error('Error getting top data occurred during Observable sequence: %s', err);
      throw(err);
    }
   
    return this.rerank(topData);

  }

}

