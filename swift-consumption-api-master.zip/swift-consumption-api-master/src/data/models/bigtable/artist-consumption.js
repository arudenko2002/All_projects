/*

Encapsulates consumption metrics at the artist level

*/

// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';

export class ArtistConsumption extends Consumption {
  
  constructor(connector) {
    super(connector, connector.tableNames.artist);
    this.level = 'artist';
    this.families = ['units', 
      'euro',
      'album_adjusted_units',
      'audio_stream_units',
      'video_stream_units',
      'audio_stream_album_adjusted_units',
      'video_stream_album_adjusted_units',
      'audio_stream_euro',
      'video_stream_euro',
      'physical_album_units',
      'digital_album_units',
      'digital_track_units',
      'digital_track_album_adjusted_units',
      'physical_album_euro',
      'digital_album_euro',
      'digital_track_euro',
      'digital_album_album_adjusted_units'
    ];


  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    const {territory, partner, label } = filters;

    return keyVals.artistId + '#' + 
      territory + '#' +
      partner + '#' +
      label + '#' +
      datePeriod + '#'; 

  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {
    
    const {territory, partner, label} = filters;

    return keyVals.artistId + '#' + 
      territory + '#' +
      partner + '#' +
      label + '#' +
      datePeriod + '#'; 


  }

  //override
  reverseKey(rowKey) {
    //console.log('key: %s', rowKey);
    const [artistId, territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate] = rowKey.split('#');
    return {
      artistId,
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId
    };
  }

  async executeDetailsQuery(context, artistId, dateRange, filters = {}, select = [], groups = [], outputPrecision) {

    const keyVals = {
      artistId: artistId
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    console.log(inspect(btReadOptions, false, null, false));

    //10087148#R#63#1234#S#GER01#D#20160803#
    const periodPositionInKey = 6;

    return await this.detailsData(context, btReadOptions, dateRange, groups, outputPrecision, periodPositionInKey);
    
  }


  
}

