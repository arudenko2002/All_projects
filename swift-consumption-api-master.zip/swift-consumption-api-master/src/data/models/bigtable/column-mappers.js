import { isNil } from 'lodash';
// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';

const UNITS = 'units';
const ALBUM_ADJUSTED_UNITS = 'album_adjusted_units';
const TRACK_ADJUSTED_UNITS = 'track_adjusted_units';
const EURO = 'euro';
const TOTAL_COUNTS = [
  UNITS,
  ALBUM_ADJUSTED_UNITS,
  TRACK_ADJUSTED_UNITS,
  EURO,
];

const COUNT_TYPE_MAP = {
  pr: 'partner',
  cn: 'country',
  rg: 'region',
  trr: 'territory',
  mt: 'media_type',
  cg: 'consumer_group',
  pd: 'period',
  utt: 'partner_fp'
};

const REVERSE_COUNT_TYPE_MAP = {
  Partner: 'pr',
  Country: 'cn',
  Region: 'rg',
  Territory: 'trr',
  MediaType: 'mt',
  ConsumerGroup: 'cg',
  Period: 'pd',
  FreePaid: 'utt'
};

const MEDIA_TYPE_MAP = {
  pa: 'physical_album',
  da: 'digital_album',
  dt: 'digital_track',
  s: 'stream',
  ap: 'airplay',
  as: 'audio_stream',
  vs: 'video_stream',
};

const PERIOD_TYPE_MAP = {
  tp: 'this_period',
  lp: 'last_period',
  lptd: 'last_period_to_date',
  rtd: 'release_to_date',
};

const COUNT_TYPE_TO_COUNTER_MAP = {
  mt: MEDIA_TYPE_MAP,
  pd: PERIOD_TYPE_MAP,
};

const LEVEL_TO_METADATA_COLUMN_FAMILY_MAP = {

  artist: 'artist',
  project: 'project',
  track: 'track'
};

const ARTIST_PROJECT_PROP_MAP = {
  AllUnits: 'units',
  PhysicalAlbumUnits: 'physical_album_units',
  DigitalAlbumUnits: 'digital_album_units',
  DigitalTrackUnits: 'digital_track_units',
  StreamUnits: 'stream_units',
  AirplayUnits: 'airplay_units',
  AudioStreamUnits: 'audio_stream_units',
  VideoStreamUnits: 'video_stream_units',
  AllAdjustedUnits: 'album_adjusted_units',
  DigitalAlbumAdjustedUnits: 'digital_album_album_adjusted_units',
  AllPreOrderUnits: 'preorder_units',
  DigitalAlbumPreOrderUnits: 'digital_album_preorder_units',
  DigitalTrackAdjustedUnits: 'digital_track_album_adjusted_units',
  StreamAdjustedUnits: 'stream_album_adjusted_units',
  AudioStreamAdjustedUnits: 'audio_stream_album_adjusted_units',
  VideoStreamAdjustedUnits: 'video_stream_album_adjusted_units',
  AllEuro: 'euro',
  PhysicalAlbumEuro: 'physical_album_euro',
  DigitalAlbumEuro: 'digital_album_euro',
  DigitalTrackEuro: 'digital_track_euro',
  StreamEuro: 'stream_euro',
  AirplayEuro: 'airplay_euro',
  AudioStreamEuro: 'audio_stream_euro',
  VideoStreamEuro: 'video_stream_euro',

};

const TRACK_PROP_MAP = {
  AllUnits: 'units',
  DigitalTrackUnits: 'digital_track_units',
  StreamUnits: 'stream_units',
  AirplayUnits: 'airplay_units',
  AudioStreamUnits: 'audio_stream_units',
  VideoStreamUnits: 'video_stream_units',
  AllAdjustedUnits: 'track_adjusted_units',
  DigitalTrackAdjustedUnits: 'digital_track_track_adjusted_units',
  StreamAdjustedUnits: 'stream_track_adjusted_units',
  AudioStreamAdjustedUnits: 'audio_stream_track_adjusted_units',
  VideoStreamAdjustedUnits: 'video_stream_track_adjusted_units',
  AllEuro: 'euro',
  PhysicalAlbumEuro: 'physical_album_euro',
  DigitalAlbumEuro: 'digital_album_euro',
  DigitalTrackEuro: 'digital_track_euro',
  StreamEuro: 'stream_euro',
  AirplayEuro: 'airplay_euro',
  AudioStreamEuro: 'audio_stream_euro',
  VideoStreamEuro: 'video_stream_euro',

};


const ARTIST_PROJECT_SORT_MAP = {
  AllUnits: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_units)) {
      return (values.this_period_units || 0);
    }
    return (
      (values.physical_album_units || 0) +
      (values.digital_album_units || 0) +
      (values.digital_track_units || 0) +
      (values.stream_units || 0) +
      (values.audio_stream_units || 0) +
      (values.video_stream_units || 0) +
      (values.airplay_units || 0)
    );
  },
  PhysicalAlbumUnits: 'physical_album_units',
  DigitalAlbumUnits: 'digital_album_units',
  DigitalTrackUnits: 'digital_track_units',
  StreamUnits: 'stream_units',
  AirplayUnits: 'airplay_units',
  AudioStreamUnits: 'audio_stream_units',
  VideoStreamUnits: 'video_stream_units',
  AllAdjustedUnits: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_adjusted_units)) {
      return (values.this_period_adjusted_units || 0);
    }
    return (
      (values.digital_album_album_adjusted_units || 0) +
      (values.digital_track_album_adjusted_units || 0) +
      (values.stream_album_adjusted_units || 0) +
      (values.audio_stream_album_adjusted_units || 0) +
      (values.video_stream_album_adjusted_units || 0) +
      (values.airplay_album_adjusted_units || 0)
    );
  },
  DigitalAlbumAdjustedUnits: 'digital_album_album_adjusted_units',
  DigitalAlbumPreOrderUnits: 'digital_album_preorder_units',
  DigitalTrackAdjustedUnits: 'digital_track_album_adjusted_units',
  StreamAdjustedUnits: 'stream_album_adjusted_units',
  AudioStreamAdjustedUnits: 'audio_stream_album_adjusted_units',
  VideoStreamAdjustedUnits: 'video_stream_album_adjusted_units',
  AllEuro: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_euro)) {
      return (values.this_period_euro || 0);
    }
    return (
      (values.physical_album_euro || 0) +
      (values.digital_album_euro || 0) +
      (values.digital_track_euro || 0) +
      (values.stream_euro || 0) +
      (values.audio_stream_euro || 0) +
      (values.video_stream_euro || 0) +
      (values.airplay_euro || 0)
    );
  },
  PhysicalAlbumEuro: 'physical_album_euro',
  DigitalAlbumEuro: 'digital_album_euro',
  DigitalTrackEuro: 'digital_track_euro',
  StreamEuro: 'stream_euro',
  AirplayEuro: 'airplay_euro',
  AudioStreamEuro: 'audio_stream_euro',
  VideoStreamEuro: 'video_stream_euro',
};

const TRACK_SORT_MAP = {
  AllUnits: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_units)) {
      return (values.this_period_units || 0);
    }
    return (
      (values.digital_track_units || 0) +
      (values.stream_units || 0) +
      (values.audio_stream_units || 0) +
      (values.video_stream_units || 0) +
      (values.airplay_units || 0)
    );
  },
  

  DigitalTrackUnits: 'digital_track_units',
  StreamUnits: 'stream_units',
  AirplayUnits: 'airplay_units',
  AudioStreamUnits: 'audio_stream_units',
  VideoStreamUnits: 'video_stream_units',
  AllAdjustedUnits: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_adjusted_units)) {
      return (values.this_period_adjusted_units || 0);
    }
    return (
    
      (values.digital_track_track_adjusted_units || 0) +
      (values.stream_track_adjusted_units || 0) +
      (values.audio_stream_track_adjusted_units || 0) +
      (values.video_stream_track_adjusted_units || 0) +
      (values.airplay_track_adjusted_units || 0)
    );
  },
  DigitalTrackAdjustedUnits: 'digital_track_track_adjusted_units',
  StreamAdjustedUnits: 'stream_track_adjusted_units',
  AudioStreamAdjustedUnits: 'audio_stream_track_adjusted_units',
  VideoStreamAdjustedUnits: 'video_stream_track_adjusted_units',
  AllEuro: ({ values }) => {
    if (!values) {
      return 0;
    }
    if (!isNil(values.this_period_euro)) {
      return (values.this_period_euro || 0);
    }
    return (
      (values.physical_album_euro || 0) +
      (values.digital_album_euro || 0) +
      (values.digital_track_euro || 0) +
      (values.stream_euro || 0) +
      (values.audio_stream_euro || 0) +
      (values.video_stream_euro || 0) +
      (values.airplay_euro || 0)
    );
  },
  PhysicalAlbumEuro: 'physical_album_euro',
  DigitalAlbumEuro: 'digital_album_euro',
  DigitalTrackEuro: 'digital_track_euro',
  StreamEuro: 'stream_euro',
  AirplayEuro: 'airplay_euro',
  AudioStreamEuro: 'audio_stream_euro',
  VideoStreamEuro: 'video_stream_euro',
};

export {
  UNITS,
  ALBUM_ADJUSTED_UNITS,
  TRACK_ADJUSTED_UNITS,
  EURO,
  LEVEL_TO_METADATA_COLUMN_FAMILY_MAP,
  ARTIST_PROJECT_PROP_MAP,
  ARTIST_PROJECT_SORT_MAP,
  TRACK_PROP_MAP,
  TRACK_SORT_MAP,
  REVERSE_COUNT_TYPE_MAP
//   TOTAL_COUNTS,
//   COUNT_TYPE_MAP,
//   MEDIA_TYPE_MAP,
//   PERIOD_TYPE_MAP,
//   COUNT_TYPE_TO_COUNTER_MAP,
};


export function mapSortToProp(sort, queryType) {
  return queryType.toLowerCase().includes('artist') ||
        queryType.toLowerCase().includes('project') ? ARTIST_PROJECT_SORT_MAP[sort] : TRACK_SORT_MAP[sort] || sort;
}

export function isTotalCount(family) {
  return TOTAL_COUNTS.includes(family);
}

export function countTypeName(columnType) {
  return COUNT_TYPE_MAP[columnType] || columnType;
}

// export { countTypeName };

function totalCounterName(countType, unitName) {
  const counterMap = COUNT_TYPE_TO_COUNTER_MAP[countType];
  if (!counterMap) {
    return;
  }
  return COUNT_TYPE_TO_COUNTER_MAP[countType][unitName];
}

// export { totalCounterName };

export function parseColumn(family, columnName) {
  //console.log('Family: %s', inspect(family, false, null, false));
  //console.log('Column Name: %s', inspect(columnName, false, null, false));
  const [countType, unitName] = columnName.split(':');
  if (isTotalCount(family)) {
    return {
      name: parseTotalColumn(family, columnName),
    };
  }
  return {
    name: countTypeName(countType),
    id: unitName,
  };
}

export function parseTotalColumn(family, columnName) {
  const [countType, unitName] = columnName.split(':');
  const name = totalCounterName(countType, unitName);
  return `${!name ? columnName : name}_${family}`;
      
}
