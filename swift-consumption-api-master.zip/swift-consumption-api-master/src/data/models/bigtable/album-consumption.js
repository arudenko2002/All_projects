/*

Encapsulates consumption metrics at the master album level

*/

// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';

export class AlbumConsumption extends Consumption {
  
  constructor(connector) {
    super(connector, connector.tableNames.album);
    this.level = 'album';

    //11807803#R#7#ALL#S#US07EDUM#D#20160929#1016353435#
    this.periodPositionInKey = 6;

    this.families = ['units', 
      'euro',
      'album_adjusted_units',
      'preorder_units'
    ];

  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    return keyVals.projectId + '#' 
      + super.buildStartKey(filters, datePeriod);

  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {

    return keyVals.projectId + '#' 
      + super.buildEndKey(filters, datePeriod);

  }

  //override
  reverseKey(rowKey) {
    const [projectId, territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate, albumId] = rowKey.split('#');
    return {
      projectId,
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId,
      albumId
    };
  }

  
  async projectAlbums(context, projectId, dateRange, filters = {}, select = [],  sort = [], requestedPrecision) {

    const keyVals = {
      projectId
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    return await this.listData(context, btReadOptions, dateRange, requestedPrecision, this.periodPositionInKey);
    
  }


  
}

