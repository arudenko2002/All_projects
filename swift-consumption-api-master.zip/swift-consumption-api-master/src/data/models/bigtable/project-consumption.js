/*

Encapsulates consumption metrics at the project level

*/

// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import { Consumption } from './consumption';

export class ProjectConsumption extends Consumption {
  
  constructor(connector) {
    super(connector, connector.tableNames.project);
    this.level = 'project';
    this.families = ['units', 
      'euro',
      'album_adjusted_units',
      'stream_units',
      'stream_album_adjusted_units',
      'stream_euro',
      'physical_album_units',
      'digital_album_units',
      'digital_track_units',
      'digital_track_album_adjusted_units',
      'physical_album_euro',
      'digital_album_euro',
      'digital_track_euro',
      'digital_album_album_adjusted_units'
    ];


    //10001001#R#7#ALL#S#US09#M#201608#10240901#
    this.periodPositionInKey = 6;

  }

  //override
  buildStartKey(filters, datePeriod, keyVals) {

    return keyVals.artistId + '#' 
      + super.buildStartKey(filters, datePeriod);

  }

  //override
  buildEndKey(filters, datePeriod, keyVals) {

    return keyVals.artistId + '#' 
      + super.buildEndKey(filters, datePeriod);

  }

  //override
  reverseKey(rowKey) {
    const [artistId, territoryType, territoryCode, partnerId, labelType, labelId, intervalPeriod, intervalDate, projectId] = rowKey.split('#');
    return {
      artistId,
      territoryType,
      territoryCode,
      intervalPeriod,
      intervalDate,
      partnerId,
      labelType,
      labelId,
      projectId
    };
  }

  async executeDetailsQuery(context, project, dateRange, filters = {}, select = [], groups = [], outputPrecision) {

    const keyVals = {
      artistId: project.artist.id,
      projectId: project.id
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, groups, context);

    // add a row filter by key for ranges 
    // so we need to construct a filter that would wildcard the dates 
    // so it looks like 10143644#A#ALL#ALL#S#GER01#\C*#\C*#10143644#11817960#
    if (btReadOptions.ranges) {

      

      //construct RegEx for the row filter
      const rowFilter = new RegExp(
      '\\C*' + '#' + 
      keyVals.projectId + '#');

      btReadOptions.filter.push({row: rowFilter});

    } else if (btReadOptions.keys) {
      //if it's just one key, we need to add projectId and trackId at the end of it
      btReadOptions.keys[0] += keyVals.projectId + '#';

    }

    console.log(inspect(btReadOptions, false, null, false));


    return await this.detailsData(context, btReadOptions, dateRange, 
      groups, outputPrecision, this.periodPositionInKey);
    
  }

  async artistProjects(context, artistId, dateRange, filters = {}, select = [],  sort = [], requestedPrecision) {

    const keyVals = {
      artistId
    };

    const btReadOptions = await this.buildBtReadOptions(filters, dateRange, keyVals, select, null, context);

    return await this.listData(context, btReadOptions, dateRange, requestedPrecision, this.periodPositionInKey);
    
  }


  
}

