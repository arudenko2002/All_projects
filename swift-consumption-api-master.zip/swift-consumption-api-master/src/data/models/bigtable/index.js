import { AlbumConsumption } from './album-consumption';
import { ArtistConsumption } from './artist-consumption';
import { ProjectConsumption } from './project-consumption';
import { TrackConsumption } from './track-consumption';
import { IsrcConsumption} from './isrc-consumption';
import { TopArtists } from './top-artists';
import { TopProjects } from './top-projects';
import { TopTracks } from './top-tracks';

export class BigTableModels {
  constructor({ connector }) {
    this.albumConsumption = new AlbumConsumption(connector);
    this.artistConsumption = new ArtistConsumption(connector);
    this.projectConsumption = new ProjectConsumption(connector);
    this.trackConsumption = new TrackConsumption(connector);
    this.isrcConsumption = new IsrcConsumption(connector);
    this.topArtists = new TopArtists(connector);
    this.topProjects = new TopProjects(connector);
    this.topTracks = new TopTracks(connector);
   
  }
}