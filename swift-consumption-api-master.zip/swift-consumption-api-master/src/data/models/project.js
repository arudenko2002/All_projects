/**
 * Project Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var ProjectSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Project ID',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Project Title',
    trim: true
  },
  artist: {
    type: Schema.ObjectId,
    ref: 'Artist',
    required: 'Please specify the Artist for this Project'
  },
  products: [{
    type: Schema.ObjectId,
    ref: 'Product'
  }],
  releases: [{
    type: Schema.ObjectId,
    ref: 'Release'
  }],
  label: {
    type: Schema.ObjectId,
    ref: 'Label'
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Project', ProjectSchema);

ProjectSchema.pre('save', function(next) {
  var project = this;
  project.lastUpdated = Date.now();
  console.log(`Project ${project.title} updated on ${project.lastUpdated}`);
  next();
});

module.exports = ProjectSchema;