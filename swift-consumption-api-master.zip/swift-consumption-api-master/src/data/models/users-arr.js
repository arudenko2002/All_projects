import _ from 'lodash';

const users = [
// can see revenue and has a family label
//   {
//     'createdAt': new Date('2017-05-01T22:43:29.652Z').toISOString(),
//     'lastAccessed': new Date('2017-05-02T22:43:29.652Z').toISOString(),
//     'active': true,
//     'firstName': 'Elon',
//     'lastName': 'Musket',
//     'email': 'elon@musk.com',
//     'internal': false,
//     'defaultTerritory': {
//       'name': 'United States',
//       'id': 'US',
//       'type': 'Country'
//     },
//     'revenue': {
//       'canView': true,
//       'pending': false
//     },
//     'externalInfo': {
//       'termsChecked': false,
//       'company': 'Tesla',
//       'clientType': 'Manager',
//       'country': 'US',
//       'phoneNumber': '+12136890909',
//       'familyLabel': {
//         'id':1068, 'name':'Disney', 'type':'Family'
//       }, // family label Disney
//       'artists': [
//         '10020469', // demi lovato
//         '10036098', // sia
//         '10257332' // badflower
//       ]
//     },
//     'subscriptions': {
//       'newsletterMonthly': true,
//       'benchmarkAlerts': true,
//       'dataNotifications': true,
//     }
//   },
// // cannot see revenue, family label included
//   {
//     'createdAt': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'lastAccessed': new Date('2017-06-10T18:01:06.801Z').toISOString(),
//     'active': true,
//     'firstName': 'Frank',
//     'lastName': 'Ferguson',
//     'email': 'fergie@ferguson.com',
//     'internal': false,
//     'defaultTerritory': {
//       'id': '11',
//       'name': 'UMG Global ex US',
//       'type': 'Region'
//     },
//     'revenue': {
//       'canView': false,
//       'pending': false
//     },
//     'externalInfo': {
//       'country': 'GB',
//       'company': 'Black Eyed Peas',
//       'clientType': 'Artist',
//       'familyLabel': {
//         'id':  1055,
//         'name': 'Concord',
//         'type': 'Family'
//       },
//       'phoneNumber': '+8009999999',
//       'artists': [
//         '10221286', // Circa Waves
//         '10001242', // Rise Against
//         '10085215', // Bastille
//       ]
//     },
//     'subscriptions': {
//       'newsletterMonthly': false,
//       'benchmarkAlerts': false,
//       'dataNotifications': false,
//     }
//   },
// // cannot see revenue, does not have a family label
//   {
//     'createdAt': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'lastAccessed': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'active': true,
//     'firstName': 'Bobby',
//     'lastName': 'Brown',
//     'email': 'bbboy@brown.com',
//     'defaultTerritory': {
//       'id': '63',
//       'name': 'Europe',
//       'type': 'Region'
//     },
//     'internal': false,
//     'revenue': {
//       'canView': false,
//       'pending': false
//     },
//     'externalInfo': {
//       'country': 'US',
//       'company': 'Rap United',
//       'clientType': 'Manager',
//       'phoneNumber': '+12129992929',
//       'artists': [
//         '10253074', // halsey
//         '10041007' // Drake
//       ]
//     }
//   },
// // is not active
//   {
//     'createdAt': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'lastAccessed': new Date('2017-05-02T22:43:29.652Z').toISOString(),
//     'active': false,
//     'firstName': 'Liraz',
//     'lastName': 'Cohen',
//     'email': 'liraz@gmail.com',
//     'internal': false,
//     'revenue': {
//       'canView': true,
//       'pending': true
//     },
//     'defaultTerritory': {
//       'name': 'United States',
//       'id': 'US',
//       'type': 'Country'
//     },
//     'externalInfo': {
//       'country': 'GB',
//       'company': 'Liraz Is Awesome',
//       'clientType': 'Artist',
//       // 'familyLabel': 'Pantasounds',
//       'phoneNumber': '+8182345678',
//       'artists': [
//         '10075761' // the weeknd
//       ]
//     }
//   },
//   {
//     'createdAt': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'lastAccessed': null,
//     'active': true,
//     'firstName': 'Carsten',
//     'lastName': 'Von Heynitz',
//     'email': 'Carsten.VonHeynitz@umusic.com',
//     'internal': true,
//     'defaultTerritory': {
//       'name': 'GERMANY',
//       'id': 'DE',
//       'type': 'Country'
//     },
//     'revenue': {
//       'canView': true,
//       'pending': false
//     },
//     'internalInfo': {
//       'aliasID': 'HeynitC',
//       'title': 'Enterprise Content Management',
//       'department': 'IT/Application Development',
//       'company': 'Universal Music Group',
//       'country': 'GERMANY',
//       'countryId': 'DE',
//       'countryCode': '276',
//       'workAddress': 'Stralauer Allee 1',
//       'telephoneNumber': '+49 30 52007 2633',
//       'defaultLabel': {
//         'id':'GER01',
//         'name': 'Capitol',
//         'type': 'Segment'
//       } // segment ID for vertigo / capitol
//     }
//   },
//   {
//     'createdAt': new Date('2017-06-09T18:01:06.801Z').toISOString(),
//     'lastAccessed': null,
//     'active': true,
//     'firstName': 'Kristian',
//     'lastName': 'Fryer-Kelsey',
//     'email': 'swift@umusic.com',
//     'internal': true,
//     'revenue': {
//       'canView': true,
//       'pending': false
//     },
//     'internalInfo': {
//       'aliasID': 'Fryer-K',
//       'title': 'Director of BS :p',
//       'department': 'IT/Application Development',
//       'company': 'Universal Music Group',
//       'country': 'United States',
//       'countryId': 'US'
//     }
//   }

];

export function getUser(email){
  return _.find(users, function(o) {
    return o.email === email;
  });
}
