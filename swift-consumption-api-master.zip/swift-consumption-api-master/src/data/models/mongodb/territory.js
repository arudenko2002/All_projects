// eslint-disable-next-line no-unused-vars
import logger, { debugLog, dumpLog } from '../../../lib/logger';

const debug = debugLog('models', 'mongodb', 'territory');
const dump = dumpLog('models', 'mongodb', 'territory');

const MONGO_COLLECTION_COUNTRY = 'country';
const MONGO_COLLECTION_REGION = 'region';

const COUNTRY_COLLECTION = 'countryCollection';
const REGION_COLLECTION = 'regionCollection';

const TYPE_CODE_TO_ENUM_MAP = {
  A: 'All',
  C: 'Country',
  R: 'Region',
};

const TYPE_TO_COLLECTION_MAP = {
  'C': COUNTRY_COLLECTION,
  'Country': COUNTRY_COLLECTION,
  'R': REGION_COLLECTION,
  'Region': REGION_COLLECTION,
};

async function getFrom(collection, code) {
  //console.log('getFrom called with code=%s', code);
  try {
    const territoryObj = await collection.findOne({ _id: code });
    //console.log('getFrom found territoryObj as:', territoryObj);
    if (!territoryObj) {
      logger.info('getFrom found no territoryObj at code %s', code);
      //console.log('getFrom found no territoryObj at code %s', code);
      return null;
    }
    return territoryObj;
  }
  catch (err) {
    logger.error('getFrom error trying to find territoryObj by code "%s":', code, err);
    //console.log('getFrom error trying to find territoryObj by code "%s":', code, err);
    // NOTE: throw if desired to have error bubble to GQL response
    // throw (err);
  }
  return null;
}


export class Territory {
  constructor({ connector }) {
    debug('Territory:ctor called');
    dump('Territory:ctor args connector is:\n %O', connector);
    this.connector = connector;
    this[COUNTRY_COLLECTION] = connector.collection(connector.collectionNames.country || MONGO_COLLECTION_COUNTRY);
    this[REGION_COLLECTION] = connector.collection(connector.collectionNames.region || MONGO_COLLECTION_REGION);
  }

  async getAllCountries() {
    try {

      return await this[COUNTRY_COLLECTION].find({}, { '_id': 1 }).toArray();

    }
    catch (err) {
      logger.error('error trying to get countries from Mongo', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async getAll() {
    try {
      const regionList = await this[REGION_COLLECTION]
      .aggregate([
        {
          $lookup:
          {
            from: this.connector.collectionNames.partner,
            localField: 'partners',
            foreignField: '_id',
            as: 'partners'
          }
        },
        {   
          $project:{
            _id: 1,
            name: 1,
            partners: {
              _id: 1,
              name: 1,
              priorityPartner: 1
            },
            order: 1
          } 
        }
      ]) 
      .toArray() || [];
      const regions = regionList.map(region => {
        return region ? {
          type: 'Region',
          id: region._id,
          name: region.name,
          partners: region.partners.map(partner => {
            return partner ? {
              id: partner._id,
              name: partner.name,
              priorityPartner: partner.priorityPartner
            } : undefined;
          }),
          order: region.order
        } : undefined;
      }).sort((a, b) => {
        return a.name.toUpperCase() > b.name.toUpperCase()
          ? 1 : a.name.toUpperCase() < b.name.toUpperCase()
          ? -1 : 0;
      });
      const countryList = await this[COUNTRY_COLLECTION]
      .aggregate([
        {
          $lookup:
          {
            from: this.connector.collectionNames.sapSegment,
            localField: 'sap_segments',
            foreignField: '_id',
            as: 'segments'
          }
        },
        {
          $lookup:
          {
            from: this.connector.collectionNames.partner,
            localField: 'partners',
            foreignField: '_id',
            as: 'partners'
          }
        },
        {   
          $project:{
            _id: 1,
            name: 1,
            partners: {
              _id: 1,
              name: 1,
              priorityPartner: 1
            },
            segments: 1,
            order: 1
          } 
        }
      ])
      .toArray() || [];
      const countries = countryList.map(country => {
        return country ? {
          type: 'Country',
          id: country._id,
          name: country.name,
          segments: country.segments.map(segment => {
            return segment ? {
              type: 'Segment',
              id: segment._id,
              name: segment.name
            } : undefined;
          }),
          partners: country.partners.map(partner => {
            return partner ? {
              id: partner._id,
              name: partner.name,
              priorityPartner: partner.priorityPartner
            } : undefined;
          }),
          order: country.order
        } : undefined;
      }).sort((a, b) => {
        return a.id.toUpperCase() > b.id.toUpperCase()
          ? 1 : a.id.toUpperCase() < b.id.toUpperCase()
          ? -1 : 0;
      });
      return { regions, countries };
    }
    catch (err) {
      logger.error('error trying to find territories', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async get(type, code) {
    const typeCollection = TYPE_TO_COLLECTION_MAP[type];
    const typeEnum = TYPE_CODE_TO_ENUM_MAP[type] || type;
    debug('get called with (type=%s, code=%s) mapped to typeEnum=%s', type, code, typeEnum);
    debug('will use typeCollection %o', typeCollection);
    dump('typeCollection is:', this[typeCollection]);
    if (!typeCollection) {
      return null;
    }
    try {
      const territory = await getFrom(this[typeCollection], code);
      debug('get retrieved territory:', territory);
      return this.connector.remapAndAppend(territory, {
        type: typeEnum,
      }, 'id');
    }
    catch (err) {
      logger.error('error trying to find territory by code "%s":', code, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }

}

