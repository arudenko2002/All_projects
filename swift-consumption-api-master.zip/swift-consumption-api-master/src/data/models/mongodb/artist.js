import { inspect } from 'util';
import logger from '../../../lib/logger';
// eslint-disable-next-line no-unused-vars
import { checkForImage, getArtistImage } from '../../../lib/utils/image-utils';

const MONGO_COLLECTION_NAME = 'artist';
const MONGO_SPOTIFY_COLLECTION_NAME = 'spotify-artists';

export class Artist {
  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.artist || MONGO_COLLECTION_NAME);
    this.spotifyCollection = connector.collection(connector.collectionNames.spotifyArtist || MONGO_SPOTIFY_COLLECTION_NAME);
  }

  async getSpotifyMetadata(id) {

    const artist = await this.spotifyCollection.findOne({ _id: id});

    if (artist) 
      return this.connector.remapIdTo(artist, 'id');

    return null;
  }

  async saveSpotifyMetadata(id, metadata) {
    
    const doc = {
      _id: id,
      ...metadata
    };

    // eslint-disable-next-line no-unused-vars
    const writeResult = await this.spotifyCollection.save(doc);

  }

  async search(text, { skip, limit }) {
    let results = [];

    try {

      let artists = await this.collection
        .find({ name: { $regex: `${text}`, $options:'si' } })
        .skip(skip)
        .limit(limit)
        .toArray() || [];

      artists.forEach((artist) => {
        if (artist) {
          artist.type = 'Artist';
          results.push(artist);
        }
      });

      return results;
    }
    catch(err) {
      logger.info('Error while searching for tracks using text: %s, error: %s', text, inspect(err, false, null, false));      
      return results;
    }
  }
  
  async getArtistsByLabel(labelId) {
    try {
      const query = {'label_families': {'$all': [labelId.toString()]}};
      let artists = await this.collection.find(query).toArray();

      return artists;
    } catch(err) {
      return null;
    }
  }

  async get(id) {
    try {
      const artist = await this.collection.findOne({ _id: id });
      
      if (!artist) {
        logger.info('Get found no artist at id %s', id);
        return null;
      }
      
      return this.connector.remapIdTo(artist, 'id');
    }
    catch (err) {
      logger.error('error trying to find artist by id "%s":', id, err);
      // NOTE: throw if desired to have error bubble to GQL response
      //throw (err);
    }
    return null;
  }
}