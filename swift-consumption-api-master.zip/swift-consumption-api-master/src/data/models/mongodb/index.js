// eslint-disable-next-line no-unused-vars
import logger, { debugLog, dumpLog } from '../../../lib/logger';
import { Artist } from './artist';
import { Calendar } from './calendar';
import { Genre } from './genre';
import { Label } from './label';
import { Partner } from './partner';
import { PartnerStatus } from './partner-status';
import { Project } from './project';
import { Territory } from './territory';
import { Track } from './track';
import { Isrc } from './isrc';
import { Album } from './album';
import { Week } from './week';


// eslint-disable-next-line no-unused-vars
const debug = debugLog('models', 'mongodb');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('models', 'mongodb');

export class MongoDbModels {
  constructor({ connector }) {
    debug('MongoDbModels:ctor called');
    dump('MongoDbModels:ctor args connector is:\n %O', connector);
    this.artist = new Artist({ connector });
    this.calendar = new Calendar({ connector });
    this.genre = new Genre({ connector });
    this.label = new Label({ connector });
    this.partner = new Partner({ connector });
    this.partnerStatus = new PartnerStatus({ connector });
    this.project = new Project({ connector });
    this.territory = new Territory({ connector });
    this.track = new Track({ connector });
    this.isrc = new Isrc({ connector });
    this.album = new Album({ connector });
    this.week = new Week({ connector });
  }
}
