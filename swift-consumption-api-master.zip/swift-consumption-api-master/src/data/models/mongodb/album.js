import { inspect } from 'util';
import logger from '../../../lib/logger';

const MONGO_COLLECTION_NAME = 'album';

export class Album {

  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.album || MONGO_COLLECTION_NAME);
    
  }

  async get(id) {
    try {
      const album = await this.collection.findOne({ _id: id });
      
      if (!album) {
        logger.info('Get found no Album with id %s', id);
        return null;
      }
      
      return this.connector.remapIdTo(album, 'id');
    }
    catch (err) {

      logger.error('error trying to find Album with id "%s":', id, err);
      
    }
    
    return null;
  }

  async search(text, { skip, limit }) {
    let results = [];

    try {

      const searchRegex = new RegExp(text, 'i');

      let albums = await this.collection
        .find({ title: { $regex: searchRegex } })
        .skip(skip)
        .limit(limit)
        .toArray() || [];

      albums.forEach((album) => {
        if (album) {
          album.type = 'Album';
          album.id = album._id;
          album.name = album.title;
          album.project = {
            id: album.project_id,
            name: album.project_title,
          };
          album.artist = {
            id: album.artist_id,
            name: album.artist
          };
          results.push(album);
        }
      });

      return results;
    }
    catch(err) {
      logger.info('Error while searching for tracks using text: %s, error: %s', text, inspect(err, false, null, false));      
      return results;
    }
  }
}