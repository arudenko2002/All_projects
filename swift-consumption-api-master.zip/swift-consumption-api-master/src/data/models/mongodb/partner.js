// eslint-disable-next-line no-unused-vars
import logger, { debugLog, dumpLog } from '../../../lib/logger';

const debug = debugLog('models', 'mongodb', 'partner');
const dump = dumpLog('models', 'mongodb', 'partner');

const MONGO_COLLECTION_NAME = 'partner';
const MONGO_COUNTRY_COLLECTION_NAME = 'country';

export class Partner {
  constructor({ connector }) {
    debug('Partner:ctor called');
    dump('Partner:ctor args connector is:\n %O', connector);
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.partner || MONGO_COLLECTION_NAME);
    this.countries = connector.collection(connector.collectionNames.country || MONGO_COUNTRY_COLLECTION_NAME);
  }

  async getAll() {
    try {
      const partners = await this.collection.find({}).toArray();
      if (!partners) {
        logger.info('Get All found no partners');
        return [];
      }
      return partners.map(partner => {
        const territories = [];

        partner.regions.forEach(region => territories.push({
          type: 'Region',
          id: region
        }));

        partner.countries.forEach(country => territories.push({
          type: 'Country',
          id: country
        }));
        
        return {
          id: partner._id,
          name: partner.name,
          priorityPartner: partner.priorityPartner,
          territories: territories
        };
      }).sort((a, b) => {
        return a.id - b.id;
      });
    }
    catch (err) {
      logger.error('error trying to find partners', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async get(partnerId) {
    
    try {
      const partner = await this.collection.findOne({ _id: partnerId }) || await this.collection.findOne({ master_account_code: partnerId });
      if (!partner) {
        logger.info('Get found no partner at id %s', partnerId);
        return null;
      }
      
      const territories = [];

      partner.regions.forEach(region => territories.push({
        type: 'Region',
        id: region
      }));

      partner.countries.forEach(country => territories.push({
        type: 'Country',
        id: country
      }));

      return {
        id: partner._id,
        name: partner.name,
        priorityPartner: partner.priorityPartner,
        territories: territories

      };
    }
    catch (err) {
      logger.error('error trying to find partner by id "%s":', partnerId, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }

}

