import logger, { debugLog, dumpLog } from '../../../lib/logger';

const debug = debugLog('models', 'mongodb', 'label');
const dump = dumpLog('models', 'mongodb', 'label');

const MONGO_COLLECTION_SEGMENT = 'sap_segment';
const MONGO_COLLECTION_FAMILY = 'label_family';

const LABEL_TYPE_MAP = {
  A: 'All',
  F: 'Family',
  S: 'Segment',
};

function transformLabelFamilyDoc(familyDoc) {
  const {
    _id:id,
    name,
    labels
  } = familyDoc;
  return {
    id,
    name,
    type: 'Family',
    labels,
  };
}


function transformSegmentDoc(segmentDoc) {
  const {
    _id:id,
    name,
    countries
  } = segmentDoc;
  return {
    id,
    name,
    type: 'Segment',
    countries,
  };
}

export class Label {
  constructor({ connector }) {
    debug('Label:ctor called');
    dump('Label:ctor args connector is:\n %O', connector);
    this.connector = connector;
    this.segmentsCollection = connector.collection(connector.collectionNames.sapSegment || MONGO_COLLECTION_SEGMENT);
    this.familiesCollection = connector.collection(connector.collectionNames.labelFamily || MONGO_COLLECTION_FAMILY);

  }

  async get(id, type = 'A') {
    try {

      var label;

      if (type == 'S') {
        var segment = await this.segmentsCollection.findOne({ _id: id });
        label = transformSegmentDoc(segment, type);
      }

      else if (type == 'F') {
        var labelFamily = await this.familiesCollection.findOne({ _id: id });
        label = transformLabelFamilyDoc(labelFamily, type);

      }

      if (!label) {
        logger.info('Get found no label at id %s', id);
        return null;
      }
      return label;
    }
    catch (err) {
      logger.error('error trying to find label by id "%s":', id, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }

  async getAll() {
    try {
      const segmentList = await this.segmentsCollection.find({}).toArray() || [];
      const segments = segmentList.map(segment => {
        if (segment) {
          return {
            type: LABEL_TYPE_MAP.S,
            id: segment._id,
            name: segment.name,
          };
        }
      }).sort((a, b) => {
        return a.name.toUpperCase() > b.name.toUpperCase()
          ? 1 : a.name.toUpperCase() < b.name.toUpperCase()
          ? -1 : 0;
      });
      const familyList = await this.familiesCollection.find({}).toArray() || [];
      
      const families = familyList.map(family => {
        if (family) {
          return {
            type: LABEL_TYPE_MAP.F,
            id: family._id,
            name: family.name
          };
        }
      }).sort((a, b) => {
        return a.name.toUpperCase() > b.name.toUpperCase()
          ? 1 : a.name.toUpperCase() < b.name.toUpperCase()
          ? -1 : 0;
      });
      return { segments, families };
    }
    catch (err) {
      logger.error('error trying to find territories', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async getFamily(familyId) {
    if (!familyId) {
      return null;
    }
    try {
      const family = await this.familiesCollection.findOne({ _id: familyId });
      if (!family) {
        logger.info('Get found no label family at id %s', familyId);
        return null;
      }
      return transformLabelFamilyDoc(family);
    }
    catch (err) {
      logger.error('error trying to find label family by familyId "%s":', familyId, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }

}

