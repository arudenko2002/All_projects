import { inspect } from 'util';
import logger from '../../../lib/logger';

const MONGO_COLLECTION_NAME = 'isrc';

export class Isrc {

  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.isrc || MONGO_COLLECTION_NAME);
    
  }

  async get(id) {
    try {
      const isrc = await this.collection.findOne({ _id: id });
      
      if (!isrc) {
        logger.info('Get found no ISRC %s', id);
        return null;
      }
      
      return this.connector.remapIdTo(isrc, 'id');
    }
    catch (err) {

      logger.error('error trying to find ISRC "%s":', id, err);
      
    }
    
    return null;
  }

  async search(text, { skip, limit }) {
    let results = [];
    try {
      
      const searchRegex = new RegExp(text, 'i');

      let isrcs = await this.collection
        .find({ title: { $regex: searchRegex } })
        .skip(skip)
        .limit(limit)
        .toArray() || [];

      isrcs.forEach((isrc) => {
        if (isrc) {
          isrc.type = 'Isrc';
          isrc.id = isrc._id;
          isrc.name = isrc.title;
          isrc.artist = {
            id: isrc.artist_id,
            name: isrc.artist,
          };
          isrc.project = {
            id: isrc.project_id,
            name: isrc.project_title,
          };
          isrc.track = {
            id: isrc.track_id,
            name: isrc.track_title,
          };
          results.push(isrc);
        }
      });

      return results;
    }
    catch(err) {
      logger.info('Error while searching for tracks using text: %s, error: %s', text, inspect(err, false, null, false));      
      return results;
    }
  }
}