import { inspect } from 'util';
import logger from '../../../lib/logger';

const MONGO_COLLECTION_NAME = 'project';
const MONGO_SPOTIFY_COLLECTION_NAME = 'spotify-albums';

export class Project {

  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.project || MONGO_COLLECTION_NAME);
    this.spotifyCollection = connector.collection(connector.collectionNames.spotifyAlbum || MONGO_SPOTIFY_COLLECTION_NAME);
  }

  async get(id) {
    try {
      const project = await this.collection.findOne({ _id: id });
      
      if (!project) {
        logger.info('Get found no project at id %s', id);
        return null;
      }
      
      return this.connector.remapIdTo(project, 'id');
    }
    catch (err) {

      logger.error('error trying to find project by id "%s":', id, err);
      
    }
    
    return null;
  }

  async search(text, { skip, limit }) {
    let results = [];
    try {
      
      const searchRegex = new RegExp(text, 'i');

      let projects = await this.collection
        .find({ title: { $regex: searchRegex } })
        .skip(skip)
        .limit(limit)
        .toArray() || [];

      projects.forEach((project) => {
        if (project) {
          project.type = 'Project';
          project.name = project.title;
          project.artist = {
            id: project.artist_id,
            name: project.artist,
          };
          results.push(project);
        }
      });

      return results;
    }
    catch(err) {
      logger.info('Error while searching for tracks using text: %s, error: %s', text, inspect(err, false, null, false));      
      return results;
    }
  }

  async getSpotifyMetadata(id) {

    const project = await this.spotifyCollection.findOne({ _id: id});

    if (project) 
      return this.connector.remapIdTo(project, 'id');

    return null;
  }

  async saveSpotifyMetadata(id, metadata) {
    
    const doc = {
      _id: id,
      ...metadata
    };

    // eslint-disable-next-line no-unused-vars
    const writeResult = await this.spotifyCollection.save(doc);

  }
}