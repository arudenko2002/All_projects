import logger, { debugLog } from '../../../lib/logger';
//import { inspect } from 'util';

const debug = debugLog('models', 'mongodb', 'day');
const MONGO_COLLECTION_NAME = 'day';

export class Calendar {
  constructor({ connector }) {
    debug('Day:ctor called');

    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.day || MONGO_COLLECTION_NAME);
  }

  async getAll() {
    console.log('Getting Calendar metadata');
    try {
      const days = await this.collection.find({}).toArray();
      if (!days) {
        logger.info('Get All found no days');
        return [];
      }
      return days.map(day => {
        if (day) {
          return {
            day: day._id,
            week: day.global_week,
            month: day.month,
            quarter: day.quarter,
            year: day.year
          };
        }
      }).sort((a, b) => {
        return a.day > b.day
          ? 1 : a.day < b.day
          ? -1 : 0;
      });
    }
    catch (err) {
      logger.error('error trying to find days', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async getRange(startYear, endYear) {

    try {
      
      const intStartYear = parseInt(startYear);
      const intEndYear = parseInt(endYear);

      const years = [];
      for(var i = intStartYear; i <= intEndYear; i++) {
        years.push(i.toString());
      }
      
      const days = await this.collection.find({year: {$in: years}}).toArray();
  
      return days.map(day => {
        
        if (day) {
          return {
            day: day._id,
            week: day.global_week,
            month: day.month,
            quarter: day.quarter,
            year: day.year
          };
        }

      })
      .sort((a, b) => {
        return a.day > b.day
          ? 1 : a.day < b.day
          ? -1 : 0;
      });

      
    } 
    catch (err) {
      logger.error('error trying to get range of days: %s', err);
    }
  }

  async get(id) {
    try {
      const d = await this.collection.findOne({ _id: id });
      if (!d) {
        logger.info('Get found no day at id %s', id);
        return null;
      }
    
      return {
        day: d._id,
        week: d.global_week,
        month: d.month,
        quarter: d.quarter,
        year: d.year
      };
    }
    catch (err) {
      logger.error('error trying to find day by id "%s":', id, err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
    
  }

 /* async getWeeklyBoundary(startWeek, endWeek) {

  }*/
}
