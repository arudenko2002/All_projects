import { inspect } from 'util';
import logger from '../../../lib/logger';


const MONGO_COLLECTION_NAME = 'partner_status';

export class PartnerStatus {
  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.partnerStatus || MONGO_COLLECTION_NAME);
  }

  async getAll() {
    try {
      const partnerStatus = await this.collection.find({}).toArray();
      if (!partnerStatus) {
        logger.info('Get All found no list of partner statuses');
        return [];
      }
      return partnerStatus.map(ps => {
        if (ps) {
          return {
            id: ps._id,
            name: ps.name,
            priorityPartner: ps.priority,
            lastReportDateBigQuery: ps.last_report_date_bq,
            lastReportDateBigTable: ps.last_report_date_bt,
            loadDatetimeBigQuery: ps.load_datetime_bq,
            loadDatetimeBigTable: ps.load_datetime_bt
          };
        }
      }).sort((a, b) => {
        let byPriority =  b.priorityPartner - a.priorityPartner;

        if (byPriority != 0 ) {
          return byPriority;
        }

        return a.name.toUpperCase()  > b.name.toUpperCase() 
          ? 1 : a.name.toUpperCase() < b.name.toUpperCase()
          ? -1 : 0;
      });
    }
    catch (err) {
      logger.error('error trying to find list of partner statuses', inspect(err, false, null, false));
      throw (err);
    }
  }

  async get(id) {

    try {
      const partnerStatus = await this.collection.findOne({ _id: id });

      if (!partnerStatus) {
        logger.info('Get found no partner status at id %s', id);
        return null;
      }
      const { _id:id, name, priority, lastReportDate } = partnerStatus;
      return {
        id,
        name,
        priorityPartner: priority,
        lastReportDate
      };
    }
    catch (err) {
      logger.error('error trying to find partner status by id "%s":', id, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }
}