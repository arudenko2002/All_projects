import logger, { debugLog } from '../../../lib/logger';

const debug = debugLog('models', 'mongodb', 'week');
const MONGO_COLLECTION_NAME = 'week';

export class Week {
  constructor({ connector }) {
    debug('Week:ctor called');

    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.week || MONGO_COLLECTION_NAME);
  }

  async getAll() {
    
    try {
      const weeks = await this.collection.find({}).toArray();
      if (!weeks) {
        logger.info('Get All found no weeks');
        return [];
      }
      return weeks.map(week => {
        if (week) {
          return {
            week: week._id,
            startDate: week.startDate,
            endDate: week.endDate
          };
        }
      }).sort((a, b) => {
        return a.week > b.week
          ? 1 : a.week < b.week
          ? -1 : 0;
      });
    }
    catch (err) {
      logger.error('error trying to find weeks', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async get(week) {
    //console.log('Trying to get week from Mongo: %s', week);
    try {
      const wk = await this.collection.findOne({ _id: week });
      if (!wk) {
        logger.info('Get found no week  %s', week);
        return null;
      }
    
      return {
        week: wk._id,
        startDate: wk.startDate,
        endDate: wk.endDate
      };
    }
    catch (err) {
      logger.error('error trying to find week by id "%s":', week, err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
    
  }
}
