import { inspect } from 'util';
import logger from '../../../lib/logger';

const MONGO_COLLECTION_NAME = 'track';
const MONGO_SPOTIFY_COLLECTION_NAME = 'spotify-tracks';

export class Track {

  constructor({ connector }) {
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.track || MONGO_COLLECTION_NAME);
    this.spotifyCollection = connector.collection(connector.collectionNames.spotifyTrack || MONGO_SPOTIFY_COLLECTION_NAME);
  }

  async get(id) {
    try {
      const track = await this.collection.findOne({ _id: id });
      
      if (!track) {
        logger.info('Get found no track at id %s', id);
        return null;
      }
      
      return this.connector.remapIdTo(track, 'id');
    }
    catch (err) {

      logger.error('error trying to find track by id "%s":', id, err);
      
    }
    
    return null;
  }

  async search(text, { skip, limit }) {
    let results = [];

    try {
      
      const searchRegex = new RegExp(text, 'i');

      let tracks = await this.collection
        .find({ title: { $regex: searchRegex } })
        .skip(skip)
        .limit(limit)
        .toArray() || [];

      tracks.forEach((track) => {
        if (track) {
          track.type = 'Track';
          track.name = track.title;
          track.artist = {
            id: track.artist_id,
            name: track.artist,
          };
          track.project = {
            id: track.project_id,
            name: track.project_title,
          };
          results.push(track);
        }
      });

      return results;
    }
    catch(err) {
      logger.info('Error while searching for tracks using text: %s, error: %s', text, inspect(err, false, null, false));     
      return results;
    }
  }

  async getSpotifyMetadata(id) {

    const track = await this.spotifyCollection.findOne({ _id: id});

    if (track) 
      return this.connector.remapIdTo(track, 'id');

    return null;
  }

  async saveSpotifyMetadata(id, metadata) {
    
    const doc = {
      _id: id,
      ...metadata
    };

    // eslint-disable-next-line no-unused-vars
    const writeResult = await this.spotifyCollection.save(doc);

  }
}