// eslint-disable-next-line no-unused-vars
import logger, { debugLog, dumpLog } from '../../../lib/logger';

const debug = debugLog('models', 'mongodb', 'genre');
const dump = dumpLog('models', 'mongodb', 'genre');

const MONGO_COLLECTION_NAME = 'genre';

export class Genre {
  constructor({ connector }) {
    debug('Genre:ctor called');
    dump('Genre:ctor args connector is:\n %O', connector);
    this.connector = connector;
    this.collection = connector.collection(connector.collectionNames.genre || MONGO_COLLECTION_NAME);
  }

  async getAll() {
    try {
      const genres = await this.collection.find({}).toArray();
      if (!genres) {
        logger.info('Get All found no genres');
        return [];
      }
      return genres.map(genre => {
        if (genre) {
          return {
            id: genre._id,
            name: genre.name
          };
        }
      }).sort((a, b) => {
        return a.name.toUpperCase() > b.name.toUpperCase()
          ? 1 : a.name.toUpperCase() < b.name.toUpperCase()
          ? -1 : 0;
      });
    }
    catch (err) {
      logger.error('error trying to find genres', err);
      // NOTE: throw if desired to have error bubble to GQL response
      throw (err);
    }
  }

  async get(code) {
    try {
      const genre = await this.collection.findOne({ _id: code });
      if (!genre) {
        logger.info('Get found no genre at id %s', code);
        return null;
      }
      const { _id:id, name } = genre;
      return {
        id,
        name,
      };
    }
    catch (err) {
      logger.error('error trying to find genre by id "%s":', code, err);
      // NOTE: throw if desired to have error bubble to GQL response
      // throw (err);
    }
    return null;
  }

}

