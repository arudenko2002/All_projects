/**
 * Region Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var RegionSchema = new Schema({
  name: {
    type: String,
    required: 'Please enter a Region Name',
    trim: true
  },
  countries: [{
    type: String,
    ref: 'Country'
  }],
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Region', RegionSchema);

RegionSchema.pre('save', function(next) {
  var region = this;
  region.lastUpdated = Date.now();
  console.log(`Region ${region.name} updated on ${region.lastUpdated}`);
  next();
});

module.exports = RegionSchema;