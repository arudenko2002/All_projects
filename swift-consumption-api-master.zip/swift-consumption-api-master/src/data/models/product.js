/**
 * Product Schema
 */
var mongoose = require('mongoose'),
  Schema = mongoose.Schema;

var ProductSchema = new Schema({
  _id: {
    type: String,
    required: 'Please enter a Product ID',
    trim: true,
    unique: true
  },
  title: {
    type: String,
    required: 'Please enter a Product Title',
    trim: true
  },
  artist: {
    type: Schema.ObjectId,
    ref: 'Artist',
    required: 'Please specify the Artist for this Product'
  },
  project: {
    type: Schema.ObjectId,
    ref: 'Project',
    required: 'Please specify the Project for this Product'
  },
  productType: {
    type: String,
    required: 'Please enter a Product Type',
    enum: ['A', 'T', 'V']
  },
  genre: {
    type: Schema.ObjectId,
    ref: 'Genre',
    required: 'Please specify the Genre for this Product'
  },
  releases: [{
    type: Schema.ObjectId,
    ref: 'Release'
  }],
  label: {
    type: Schema.ObjectId,
    ref: 'Label'
  },
  created: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

mongoose.model('Product', ProductSchema);

ProductSchema.pre('save', function(next) {
  var product = this;
  product.lastUpdated = Date.now();
  console.log(`Product ${product.title} updated on ${product.lastUpdated}`);
  next();
});

module.exports = ProductSchema;