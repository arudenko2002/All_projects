
// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import moment from 'moment';

import { getQuarterStartMonth, getQuarterEndMonth } from '../scalars/date-scalars';
import settings from '../../config';

/*
Aggregator takes care of logic when keys in BigTable are not available
for the requested precision (granularity).
For example, if UI requests weekly granularity for Artist Details,
weekly keys are not available in BigTable, but daily keys are. 

To return what is required, we need to summate on the fly 7 daily keys
for each requested week. 

Aggregator doesn't do actual summation logic. It only redefines the requested key range, 
and actual summation is happening in Observable sequences of corresponding queries under 
model/bigtable

2017-08-04: Handling to-date calculations 
When current period is not complete, for example if we are in day 4 of the current week
The comparison with full period of last week, will always be incorrect, so it has to be
compared to the same number of days as the current period.

A new optional parameter `periodToDay` has been added to `IntervalInput` type in schema
and if it is set, we need to take care of returning partial week-to-date and month-to-date 
counts. 

Since weeks don't have aggregations in BigTable, we just restrict the number of days that
go into a week range. But for month-to-date, there are monthly aggregations that we can't use, 
so we should switch to daily aggregations instead and build month-to-date from daily data. 

*/
export class Aggregator {

  constructor(interval, range, context ) {
    this.interval = interval; //originally requested interval
    this.range = range; //originally requested range
    this.context = context;
    this.btRange = range; //range that will be submitted to BigTable
  }

  async getBtRange() {
    //console.log('Getting aggregation range for: %s', inspect(this.range, false, null, false));

    //console.log('Getting aggregation range for interval: %s', inspect(this.interval, false, null, false));

    //if interval is defined and range is not,
    //convert interval to range

    if (!this.range && this.interval) {

      this.range = {
        precision: this.interval.period,
        startDate: this.interval.period == 'All' ? {year: '1970'} : this.interval.date,
        endDate: this.interval.period == 'All' ? {year: '2099'} : this.interval.date
      };

      if (this.interval.periodToDay)
        this.periodToDay = this.interval.periodToDay;

      this.btRange = this.range;
    }

    //console.log('converted range: %s', inspect(this.range, false, null, false));


    //get available precision
    const availablePrecision = this.getAvailablePrecision(this.range);


    //if requested precision is not available, rebuild the range 
    if (availablePrecision !== this.range.precision || 
        this.periodToDay ) {

      //if Week is requested and Day is available
      if (this.range.precision == 'Week' &&
        availablePrecision == 'Day') {
        //get first day of the start week from metadata
        const startWeek = await this.context.mongodb.week.get(this.range.startDate.year + this.range.startDate.week);
        //console.log('Start week', inspect(startWeek, false, null, false));

        const endWeek = await this.context.mongodb.week.get(this.range.endDate.year + this.range.endDate.week);
        //console.log('End week', inspect(endWeek, false, null, false));

       

        // if periodToDay is specified, modify end date 
        var endDate = endWeek.endDate;

        if (this.periodToDay) {
          endDate = moment(endWeek.startDate, 'YYYYMMDD').add(this.periodToDay - 1, 'days').format('YYYYMMDD');
        }

        //console.log('Start Week: %s', JSON.stringify(startWeek.startDate));
        //console.log('End Week: %s', JSON.stringify(endDate));

        this.btRange = {
          precision: 'Day',
          startDate: {
            year: startWeek.startDate.substring(0, 4),
            month: startWeek.startDate.substring(4, 6),
            day: startWeek.startDate.substring(6, 8)

          },
          endDate: {
            year: endDate.substring(0, 4),
            month: endDate.substring(4, 6),
            day: endDate.substring(6, 8)
          }
        };

      }

      //if Month is requested and periodToDay is set
      //we need to return a partial Month built out of days
      if (this.range.precision == 'Month' &&
          this.periodToDay) {

        this.btRange = {
          precision: 'Day',
          startDate: {
            year: this.range.startDate.year,
            month: this.range.startDate.month,
            day: '01'

          },
          endDate: {
            year: this.range.endDate.year,
            month: this.range.endDate.month,
            day: this.periodToDay < 10 ? '0' + this.periodToDay : '' + this.periodToDay
          }
        };

        

      }

      //if Quarter is requested and Month is available
      if (this.range.precision == 'Quarter' &&
        availablePrecision == 'Month') {

        this.btRange = {
          precision: 'Month',
          startDate: {
            year: this.range.startDate.year,
            month: getQuarterStartMonth(this.range.startDate.quarter)

          },
          endDate: {
            year: this.range.endDate.year,
            month: getQuarterEndMonth(this.range.endDate.quarter)
           
          }
        };

      }

      //if Year is requested and Month is available
      if (this.range.precision == 'Year' &&
        availablePrecision == 'Month') {

        this.btRange = {
          precision: 'Month',
          startDate: {
            year: this.range.startDate.year,
            month: '01'

          },
          endDate: {
            year: this.range.startDate.year,
            month: '12'
           
          }
        };

      }
      
    }


    return this.btRange;
  }
  
  getAvailablePrecision(range) {
    //hardcoding for now
    //TODO: get this from MongoDB 
    var availablePrecision;

    switch (range.precision) {
      case 'Day':
        availablePrecision = 'Day';
        break;
      case 'Week':
        if (parseInt(range.startDate.year + range.startDate.week) > parseInt(settings.bigtable.dayWeekThreshold))
          availablePrecision = 'Day';
        else
          availablePrecision = 'Week';
        break;
      case 'Month':
        availablePrecision = 'Month';
        break;
      case 'Quarter':
        availablePrecision = 'Month';
        break;
      case 'Year': 
        availablePrecision = 'Month';
        break;
      case 'All':
        availablePrecision = 'All';
        break;
      default:
        availablePrecision = 'Day';
      
    }

    console.log('Available precision: %s', availablePrecision);
    return availablePrecision;

  }

}



