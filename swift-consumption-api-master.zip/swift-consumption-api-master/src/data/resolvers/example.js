import { find, filter } from 'lodash';

const authors = [
  {
    id: 2345,
    firstName: 'Dude',
    lastName: 'GuyBro',
  },
  {
    id: 6789,
    firstName: 'Guy',
    lastName: 'BroManDude',
  },
];

const posts = [
  {
    id: 1234,
    title: 'POST Number 1',
    author: authors[0]
  },
  {
    id: 5678,
    title: 'POST Number 2',
    author: authors[1]
  },
];

authors[0].posts = [posts[0]];
authors[1].posts = [posts[1]];

const resolverMap = {
  Query: {
    posts() {
      return posts;
    },
  },
  Mutation: {
    upvotePost(_, { postId }) {
      const post = find(posts, { id: postId });
      if (!post) {
        throw new Error(`Couldn't find post with id ${postId}`);
      }
      post.votes += 1;
      return post;
    },
  },
  Author: {
    posts(author) {
      return filter(posts, { authorId: author.id });
    },
  },
  Post: {
    author(post) {
      return find(authors, { id: post.authorId });
    },
  },
};

export default resolverMap;