import casual from 'casual';
// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
// import { MockList } from rs'graphql-tools';
import { debugLog, dumpLog } from '../../lib/logger';
import dateScalarMocks from '../scalars/date-scalars-mocked';

// eslint-disable-next-line no-unused-vars
const debug = debugLog('schema', 'mocks');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('schema', 'mocks');

const id = () => casual.integer(1000, 99999).toString();
casual.define('id', id);

const Periods = [
  'Year',
  'Quarter',
  'Month',
  'Week',
  'Day',
];

const partners = [
  {
    id: '10001',
    name: 'Spotify',
  },
  {
    id: '10002',
    name: 'Amazon',
  },
  {
    id: '10003',
    name: 'Apple',
  },
  {
    id: '10004',
    name: 'Other',
  },
];
const partner = () => {
  let pidx = casual.integer(0, partners.length - 1);
  return partners[pidx];
};
const interval = () => {
  let periodIdx = casual.integer(0, Periods.length);
  let period = Periods[periodIdx];
  const rv = {
    period,
    start: {
      year: dateScalarMocks.Year(),
    },
  };
  switch (period) {
    case 'Year':
      return rv;
    case 'Quarter':
      rv.start.quarter = dateScalarMocks.Quarter();
      return rv;
    case 'Month':
      rv.start.month = dateScalarMocks.Month();
      return rv;
    case 'Week':
      rv.start.week = dateScalarMocks.Week();
      return rv;
    case 'Day':
      rv.start.month = dateScalarMocks.Month();
      rv.start.day = dateScalarMocks.Day();
      return rv;
  }
  return rv;
};
casual.define('countInterval', interval);
casual.define('partner', partner);
casual.define('units', () => ({
  physicalAlbums: casual.integer(0, 10000000),
  digitalAlbums: casual.integer(0, 10000000),
  digitalTracks: casual.integer(0, 10000000),
  streams: casual.integer(0, 10000000),
  audioStreams: casual.integer(0, 10000000),
  videoStreams: casual.integer(0, 10000000),
  airplays: casual.integer(0, 10000000),
}));
// const partnerCount = (obj, { interval }) => new MockList(4, () => ({
//   partner: casual.partner,
//   counts: {
//     interval,
//     values: casual.units
//   }
// }));
const partnerCount = (interval) => ({
  partner: casual.partner,
  counts: {
    interval: interval.start,
    values: casual.units,
  }
});
casual.define('partnerCount', partnerCount);

let joke = casual.partnerCount({}, '2017-01');
dump('mocked PartnerCount:\n %O', joke);
const mocks = {
  // ...dateScalarMocks,
  ID: () => casual.id,
  RankedArtist: () => ({
    rank: casual.integer(1, 500),
    rtd: casual.integer(0, 10000000),
  }),
  Units: () => casual.units,
  Interval: () => casual.countInterval,
// eslint-disable-next-line no-unused-vars
  PartnerCount: (a, b, c, d) => {
    debug('a is:\n %O', a);
    debug('b is:\n %O', b);
    debug('c is:\n %O', c);
    // debug('d is:\n %s', inspect(d, false, null, true));
    let m = casual.integer(1, 12);
    return casual.partnerCount({
      start: {
        year: casual.integer(2015, 2017).toString(),
        month: (m < 10 ? `0${m}` : `${m}`),
      }
    });
  },
};

export default mocks;

export { casual };
