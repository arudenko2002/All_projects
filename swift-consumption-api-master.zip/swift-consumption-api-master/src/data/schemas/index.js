import { makeExecutableSchema } from 'graphql-tools';
import gqlSchema from './sst.gql';
import resolverMap from '../resolvers/sst';


const schema = makeExecutableSchema({
  typeDefs: gqlSchema,
  resolvers: resolverMap,
});

export default schema;
