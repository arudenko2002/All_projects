// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
import request from 'request-promise';
import settings from '../../config';


/*
  Encapsulates all the functionality related to Spotify API
*/
export class Spotify {

  constructor() {
    const { spotify } = settings;
    this.albumUrl = spotify.albumUrl;
    this.artistUrl = spotify.artistUrl;
    this.searchUrl = spotify.searchUrl;
    this.tokenUrl = spotify.tokenUrl;
    this.clientId = spotify.clientId;
    this.clientSecret = spotify.clientSecret;

  }

  /*
    Returns  OAuth token that should be used for further API requests
  */
  getToken() {

    const options = {
      method: 'POST',
      uri: this.tokenUrl,
      form: {
        'grant_type': 'client_credentials'
      },
      headers: {
        'Content-Type':'application/x-www-form-urlencoded',
        'Authorization': ('Basic ' + new Buffer(this.clientId + ':' + this.clientSecret).toString('base64'))
      },
      json: true
    };

    return request(options);
  
  }

  /*
    Searches for item by search string
  */
  searchItem(type, searchString, token) {

    if (!type || !searchString || !token) {
      return null;
    }

    const options = {
      uri: this.searchUrl,
      qs: {
        type: type,
        q: searchString
      },
      headers: {
        'Authorization': 'Bearer ' + token
      },
      json: true
    };

    try {

      return request(options);

    } catch (err) {
      
      return null;

    }

  }

  /*
    Search for track by ISRC
  */
  getTrack(isrc, token) {

    if (!isrc || !token) {
      return null;
    }

    const options = {
      uri: this.searchUrl,
      qs: {
        type: 'track',
        q: 'isrc:' + isrc
      },
      headers: {
        'Authorization': 'Bearer ' + token
      },
      json: true
    };

    return request(options);

  }

  /*
    Gets album by Spotify ID
  */
  getAlbum(spotifyId, token) {

    if (!spotifyId || !token) {
      return null;
    }

    const options = {
      uri: `${this.albumUrl}/${spotifyId}`,
      headers: {
        'Authorization': 'Bearer ' + token
      },
      json: true
    };

    return request(options);

  }

  /*
    Gets artist by Spotify ID
  */
  getArtist(spotifyId, token) {

    if (!spotifyId || !token) {
      return null;
    }

    const options = {
      uri: `${this.artistUrl}/${spotifyId}`,
      headers: {
        'Authorization': 'Bearer ' + token
      },
      json: true
    };

    return request(options);

  }

}
