import path from 'path';
import bigtable from '@google-cloud/bigtable';
// eslint-disable-next-line no-unused-vars
import logger, { debugLog, dumpLog } from '../../lib/logger';

const DEFAULT_INSTANCE = 'consumption-swift';
const DEFAULT_PROJECT_ID = 'umg-dev';
// const DEBUG_TO = ['connectors', 'bigtable'];

// eslint-disable-next-line no-unused-vars
const debug = debugLog('connectors', 'bigtable');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('connectors', 'bigtable');

export function prepareOptions(options) {
  const rv = {};
  rv.keyLocation = path.isAbsolute(options.keyFile) ? options.keyFile
    : path.join(__dirname, '..', '..', 'config', options.keyFile);
  const { project_id } = require(rv.keyLocation);
  debug('project_id from key file is %s', project_id);
  rv.projectId = project_id || options.projectId || DEFAULT_PROJECT_ID;
  debug('projectId using %s AND keyLocation is %s', rv.projectId, rv.keyLocation);
  
  rv.instanceName = options.instance || DEFAULT_INSTANCE;
  rv.tables = !options.tables ? {} : { ...options.tables };
  return rv;
}

export class BigTableConnector {
  constructor({ projectId, keyLocation, instanceName, tables }) {
    const bt = bigtable({
      projectId,
      keyFilename: keyLocation,
    });

    this.instance = bt.instance(instanceName);
    this._tables = tables;
  }

  get tableNames () {
    return this._tables;
  }

  table(name) {
    return this.instance.table(name);
  }
}