import logger, { debugLog, dumpLog } from '../../lib/logger';
import { MongoClient, Logger } from 'mongodb';
import url from 'url';

// eslint-disable-next-line no-unused-vars
const debug = debugLog('connectors', 'mongodb');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('connectors', 'mongodb');

let dbcon = null;

class MongoDbConnector {
  constructor({
    // defaulting the protocol which can be overridden by a setting
    protocol = 'mongodb',
    slashes = true,
    username,
    password,
    hosts,
    database,
    replicaSet,
    readPreference,
    // swallow these backward compatible settings
    // eslint-disable-next-line no-unused-vars
    host, port,
    collections,
    // all other configurations will end up in the URL query string
    ...options,
  }) {
    Object.assign(this, {
      protocol,
      slashes,
      username,
      password,
      host: hosts.map(({ hostname, port = 27017 }) => `${hostname}:${port}`).join(','),
      database,
      replicaSet,
      readPreference,
      collections,
      options,
    });
    this.pathname = database;
    this.auth = `${this.username}:${this.password}`;
    // this.query = this.options;

    debug('MongoConnector is:', this);
    this.mongoUri = url.format(this);

    this.mongoUri += this.replicaSet ? `?replicaSet=${this.replicaSet}&readPreference=${this.readPreference}` : `?readPreference=${this.readPreference}`;

    logger.info('Mongodb Connection: User [%s]@ DB [%s]', this.username, this.database);
  }

  async connect() {
    if (dbcon) {
      return dbcon;
    }
    debug('will connect to mongo uri: "%s"', this.mongoUri);

    try {
      dbcon = await MongoClient.connect(this.mongoUri, this.options);
      Logger.setCurrentLogger((msg, context) => {
        debug(msg);
        dump(context);
      });
      logger.info('successfully connected to mongodb for metadata');
    }
    catch (mdbErr) {
      logger.error('error trying to connect to mongodb for metadata', mdbErr);
    }
    return dbcon;
  }

  get collectionNames() {
    return this.collections;
  }

  collection(name) {
    if (!dbcon) {
      return null;
    }
    return dbcon.collection(name);
  }

  remapIdTo({ _id, ...rest }, prop = 'id') {
    return {
      [prop]: _id,
      ...rest,
    };
  }

  remapAndAppend({ _id, ...rest }, append = {}, _idTo = 'id') {
    return {
      [_idTo]: _id,
      ...rest,
      ...append,
    };
  }

  // eslint-disable-next-line no-unused-vars
  removeId({ _id, ...rest }) {
    return {
      ...rest,
    };
  }

  remapTo(doc, prop, to) {
    doc[to] = doc[prop];
    delete doc[prop];
    return doc;
  }

}

export { MongoDbConnector };
