import assertErr from 'assert-err';
import { GraphQLScalarType } from 'graphql';
import { GraphQLError } from 'graphql/error';
import { Kind } from 'graphql/language';
// eslint-disable-next-line no-unused-vars
import Immutable from 'immutable'; // TODO export constant arrays as Immutable
import { debugLog, dumpLog } from '../../lib/logger';
// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
/**
 * Important to import moment from utils/umg-moment which 
 * sets the week start to Friday in line with global album
 * releases - at UMG a Release Week = Friday - Thursday
 */
import moment from '../../lib/utils/umg-moment';

const debug = debugLog('schema', 'scalars', 'date');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('schema', 'scalars', 'date');

const yearTest = /\d{4}/;
const quarterTest = /0[1-4]/;
const monthTest = /(0\d|1[0-2])/;
const weekTest = /([0-4]\d|5[0-2])/;
const dayTest = /([0-2]\d|3[0-1])/;

// TODO: convert to Immutable
const Periods = {
  All: 10000, // 10,000 days - any Tool fans out there?
  Year: 365,
  Quarter: 90,
  Month: 30,
  Week: 7,
  Day: 1,
};
export { Periods };

function periodCompare(a, b) {
  return Periods[a] - Periods[b];
}
export { periodCompare };

const Year = new GraphQLScalarType({
  name: 'Year',
  description: 'representation of a 4 digit year',
  /**
   * Serialize Year value as String
   * @param {Year} value year value as a 4 character string
   * @returns {String} year as a string
   */
  serialize: function (value) {
    debug('Year:serialize - received value=%s', value);
    assertErr(typeof value === 'string', TypeError, 'Field error: value is not string type');
    assertErr(value.length === 4, TypeError, 'Field error: value is not a 4 digit year');
    dump('Year:serialize - value is: %o', value);
    return value;
  },
  /**
   * Parse value into Year
   * @param {*} value serialized year value
   * @returns {Year} year value
   */
  parseValue: function (value) {
    debug('Year:parseValue - received value=%s', value);
    const year = value.toString();
    assertErr(yearTest.test(year), TypeError, 'Field error: value is not a 4 digit year');
    dump('Year:parseValue - value is: %o\n\tyear is: %o', value, year);
    return year;
  },
  /**
   * Parse ast literal to Year
   * @param {Object} ast graphql ast
   * @returns {Year} year value
   */
  parseLiteral: function (ast) {
    debug('Year:parseLiteral - called');
    assertErr(
      ast.kind === Kind.STRING || ast.kind === Kind.INT,
      GraphQLError,
      `Query error: can only parse strings or ints to Year but received ${ast.kind} instead`,
      [ast]
    );
    const year = ast.value.toString();
    assertErr(yearTest.test(year), GraphQLError, 'Query error: Year not a 4 digit year');
    dump('Year:parseLiteral - ast.value is: %o\n\tyear is: %o', ast.value, year);
    return year;
  },
});

export { Year };

const Quarter = new GraphQLScalarType({
  name: 'Quarter',
  description: 'representation of a 2 digit quarter',
  /**
   * Serialize Quarter value as String
   * @param {Quarter} value quarter value as a 2 character string
   * @returns {String} quarter as a string
   */
  serialize: function (value) {
    assertErr(typeof value === 'string', TypeError, 'Field error: value is not string type');
    assertErr(value.length === 2, TypeError, 'Field error: value is not a 2 digit quarter from 01-04');
    return value;
  },
  /**
   * Parse value into Quarter
   * @param {*} value serialized quarter value
   * @returns {Quarter} quarter value
   */
  parseValue: function (value) {
    const quarter = value.toString();
    assertErr(quarterTest.test(quarter), TypeError, 'Field error: value is not a 2 digit quarter from 01-04');
    return quarter;
  },
  /**
   * Parse ast literal to Quarter
   * @param {Object} ast graphql ast
   * @returns {Quarter} quarter value
   */
  parseLiteral: function (ast) {
    assertErr(
      ast.kind === Kind.STRING || ast.kind === Kind.INT,
      GraphQLError,
      `Query error: can only parse strings or ints to Quarter but received ${ast.kind} instead`,
      [ast]
    );
    const quarter = ast.value.toString();
    assertErr(quarterTest.test(quarter), GraphQLError, 'Query error: Quarter not a 2 digit quarter from 01-04');
    return quarter;
  },
});

export { Quarter };

const Month = new GraphQLScalarType({
  name: 'Month',
  description: 'representation of a 2 digit month',
  /**
   * Serialize Month value as String
   * @param {Month} value month value as a 2 character string
   * @returns {String} month as a string
   */
  serialize: function (value) {
    assertErr(typeof value === 'string', TypeError, 'Field error: value is not string type');
    assertErr(value.length === 2, TypeError, `Field error on serialize: value "${value}" is not a 2 digit month from 01-12`);
    return value;
  },
  /**
   * Parse value into Month
   * @param {*} value serialized month value
   * @returns {Month} month value
   */
  parseValue: function (value) {
    const month = value.toString();
    assertErr(monthTest.test(month), TypeError, `Field error on parseValue: value "${month}" is not a 2 digit month from 01-12`);
    return month;
  },
  /**
   * Parse ast literal to Month
   * @param {Object} ast graphql ast
   * @returns {Month} month value
   */
  parseLiteral: function (ast) {
    assertErr(
      ast.kind === Kind.STRING || ast.kind === Kind.INT,
      GraphQLError,
      `Query error: can only parse strings or ints to Month but received ${ast.kind} instead`,
      [ast]
    );
    const month = ast.value.toString();
    debug('Month.parseLiteral month "%s" test is:', month, monthTest.test(month));
    assertErr(monthTest.test(month), GraphQLError, `Query error on parseLiteral: Month "${month}" not a 2 digit month from 01-12`);
    return month;
  },
});

export { Month };

const Week = new GraphQLScalarType({
  name: 'Week',
  description: 'representation of a 2 digit week in the year',
  /**
   * Serialize Week value as String
   * @param {Week} value week value as a 2 character string
   * @returns {String} week as a string
   */
  serialize: function (value) {
    assertErr(typeof value === 'string', TypeError, 'Field error: value is not string type');
    assertErr(value.length === 2, TypeError, 'Field error: value is not a 2 digit week from 01-52');
    return value;
  },
  /**
   * Parse value into Week
   * @param {*} value serialized week value
   * @returns {Week} week value
   */
  parseValue: function (value) {
    const week = value.toString();
    assertErr(weekTest.test(week), TypeError, 'Field error: value is not a 2 digit week from 01-52');
    return week;
  },
  /**
   * Parse ast literal to Week
   * @param {Object} ast graphql ast
   * @returns {Week} week value
   */
  parseLiteral: function (ast) {
    assertErr(
      ast.kind === Kind.STRING || ast.kind === Kind.INT,
      GraphQLError,
      `Query error: can only parse strings or ints to Week but received ${ast.kind} instead`,
      [ast]
    );
    const week = ast.value.toString();
    assertErr(weekTest.test(week), GraphQLError, 'Query error: Week not a 2 digit week of year from 01-52');
    return week;
  },
});

export { Week };

const Day = new GraphQLScalarType({
  name: 'Day',
  description: 'representation of a 2 digit day in a month',
  /**
   * Serialize Day value as String
   * @param {Day} value day value as a 2 character string
   * @returns {String} day as a string
   */
  serialize: function (value) {
    assertErr(typeof value === 'string', TypeError, 'Field error: value is not string type');
    assertErr(value.length === 2, TypeError, 'Field error: value is not a 2 digit day in a month from 01-31');
    return value;
  },
  /**
   * Parse value into Day
   * @param {*} value serialized day value
   * @returns {Day} day value
   */
  parseValue: function (value) {
    const day = value.toString();
    assertErr(dayTest.test(day), TypeError, 'Field error: value is not a 2 digit day in a month from 01-31');
    return day;
  },
  /**
   * Parse ast literal to Day
   * @param {Object} ast graphql ast
   * @returns {Day} day value
   */
  parseLiteral: function (ast) {
    assertErr(
      ast.kind === Kind.STRING || ast.kind === Kind.INT,
      GraphQLError,
      `Query error: can only parse strings or ints to Day but received ${ast.kind} instead`,
      [ast]
    );
    const day = ast.value.toString();
    assertErr(dayTest.test(day), GraphQLError, 'Query error: Day not a 2 digit day in month from 01-31');
    return day;
  },
});

export { Day };

function intervalToMoment({ period, date = { year: 1970 } }) {
  // const isAll = (period === 'All');
  const { year, quarter, month = 1, week, day = 1 } = date;
  const rv = moment({ year, M: +month - 1, day });
  switch (period) {
    case 'All':
    case 'Year':
      rv.dayOfYear(1);
      break;
    case 'Quarter':
      rv.dayOfYear(1);
      rv.quarter(quarter);
      break;
    case 'Month':
      rv.date(1);
      break;
    case 'Week':
      rv.weekday(0).week(week);
      break;
  }
  return rv;
}

function momentToInterval(period, dateMoment) {
  const interval = {
    period,
    date: {
      year: dateMoment.year(),
    }
  };
  switch (period) {
    case 'All': 
    case 'Year':
      return interval;
    case 'Quarter':
      interval.date.quarter = dateMoment.quarter();
      break;
    case 'Week':
      interval.date.week = dateMoment.week();
      break;
    case 'Day':
      interval.date.day = dateMoment.date();
    // es-lint-disable-next-line no-fallthrough
    case 'Month':
      interval.date.month = dateMoment.month() + 1;
      break;
  }
  return interval;
}

export { momentToInterval };

// eslint-disable-next-line no-unused-vars
function getDateRangeByPrecision({ precision, startDate = { year: 1970 }, endDate = { year: 1971 }}) {
  // if (periodCompare(precision, period) > -1) {
  //   return [{ period, date }];
  // }

  //console.log('Inside getDateRangeByPrecision()');
  //console.log('precision: %s', inspect(precision, false, null, false));
  //console.log('startDate: %s', inspect(startDate, false, null, false));
  //console.log('endDate: %s', inspect(endDate, false, null, false));

  const start = intervalToMoment({ period: precision, date: startDate });
  const end = intervalToMoment({ period: precision, date: endDate });
  const ranges = [];
  switch (precision) {
    case 'All':
      ranges.push({
        year: start.year(),
      });
      break;
    case 'Year':
      ranges.push({
        year: start.year(),
      }, {
        year: end.year(),
      });
      break;
    case 'Quarter':
      ranges.push({
        year: start.year(),
        quarter: start.quarter(),
      }, {
        year: end.year(),
        quarter: end.quarter(),
      });
      break;
    case 'Month':
      ranges.push({
        year: start.year(),
        month: start.month() + 1,
      }, {
        year: end.year(),
        month: end.month() + 1,
      });
      break;
    case 'Week':
      ranges.push({
        year: start.year(),
        week: start.week(),
      }, {
        year: end.year(),
        week: end.week(),
      });
      break;
    case 'Day':
      ranges.push({
        year: start.year(),
        month: start.month() + 1,
        day: start.date(),
      }, {
        year: end.year(),
        month: end.month() + 1,
        day: end.date(),
      });
      break;
  }
  return ranges.map((date) => ({ period: precision, date }));
}

export { getDateRangeByPrecision };

// TODO: refactor into import file
/**
 * if date is ommitted we expect period = 'All' so start from Unix Epoch
 * 
 * @param {any} { period, date, precision } 
 * @returns array for range which is either 1 or 2 elements
 */
function getPeriodRangeByPrecision({ period, date = { year: 1970 }, precision = period }) {
  if (periodCompare(precision, period) > -1) {
    return [{ period, date }];
  }
  const isAll = (period === 'All');
  const start = intervalToMoment({ period, date });
  // const { year, quarter, month = 1, week, day = 1 } = date;
  // const start = moment({ year, M: +month - 1, day });
  // switch (period) {
  //   case 'All':
  //   case 'Year':
  //     start.dayOfYear(1);
  //     break;
  //   case 'Quarter':
  //     start.dayOfYear(1);
  //     start.quarter(quarter);
  //     break;
  //   case 'Month':
  //     start.date(1);
  //     break;
  //   case 'Week':
  //     start.weekday(0).week(week);
  //     break;
  // }
  const end = isAll ? moment() : start.clone().add(1, period);
  const intervals = [];
  switch (precision) {
    case 'Year':
      intervals.push({
        year: start.year(),
      }, {
        year: end.year(),
      });
      break;
    case 'Quarter':
      intervals.push({
        year: start.year(),
        quarter: start.quarter(),
      }, {
        year: end.year(),
        quarter: end.quarter(),
      });
      break;
    case 'Month':
      intervals.push({
        year: start.year(),
        month: start.month() + 1,
      }, {
        year: end.year(),
        month: end.month() + 1,
      });
      break;
    case 'Week':
      intervals.push({
        year: start.year(),
        week: start.week(),
      }, {
        year: end.year(),
        week: end.week(),
      });
      break;
    case 'Day':
      intervals.push({
        year: start.year(),
        month: start.month() + 1,
        day: start.date(),
      }, {
        year: end.year(),
        month: end.month() + 1,
        day: end.date(),
      });
      break;
  }
  return intervals.map((date) => ({ period: precision, date }));
}

export { getPeriodRangeByPrecision };

function getAllIntervalsInRange([start, end = null]) {
  if (!end) {
    return [start];
  }
  const { period } = start;
  const isAll = (period === 'All');
  if (isAll) {
    return [start];
  }
  const startMoment = intervalToMoment(start);
  const endMoment = intervalToMoment(end);
  const intervals = [];
  // let intervalMoment;
  for (let intervalMoment = startMoment.clone(); endMoment.isAfter(intervalMoment); intervalMoment.add(1, period)) {
    intervals.push(momentToInterval(period, intervalMoment));
  }
  // intervals.push(end);
  return intervals;
}

export { getAllIntervalsInRange };

export function getQuarterStartMonth(quarter) {
  switch(quarter) {
    case '01':
      return '01';
    case '02':
      return '04';
    case '03':
      return '07';
    case '04':
      return '10';
    default:
      return '01';
  }
}

export function getQuarterEndMonth(quarter) {
  switch(quarter) {
    case '01':
      return '03';
    case '02':
      return '06';
    case '03':
      return '09';
    case '04':
      return '12';
    default:
      return '12';
  }
}

export function getMonthQuarter(month) {
  
  switch(month) {
    case '01':
    case '02':
    case '03':
      return '01';
    case '04':
    case '05':
    case '06':
      return '02';
    case '07':
    case '08':
    case '09':
      return '03';
    case '10':
    case '11':
    case '12':
      return '04';
    default:
      return '01';
  }
}
