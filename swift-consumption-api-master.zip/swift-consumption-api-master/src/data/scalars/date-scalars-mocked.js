import casual from 'casual';
// eslint-disable-next-line no-unused-vars
import { inspect } from 'util';
// import { MockList } from rs'graphql-tools';
import { debugLog, dumpLog } from '../../lib/logger';

// eslint-disable-next-line no-unused-vars
const debug = debugLog('schema', 'scalars', 'mocks');
// eslint-disable-next-line no-unused-vars
const dump = dumpLog('schema', 'scalars', 'mocks');

casual.define('recentYear', () => casual.integer(2010, 2017).toString());
casual.define('quarter', () => `0${casual.integer(1, 4)}`);
casual.define('twoDigitMonth', () => {
  let m = casual.month_number;
  return m < 10 ? `0${m}` : m.toString();
});
casual.define('weekInYear', () => {
  let w = casual.integer(1, 52);
  return w < 10 ? `0${w}` : w.toString();
});
casual.define('dayOfMonth', () => {
  let d = casual.day_of_month;
  return d < 10 ? `0${d}` : d.toString();
});

debug('casual.quarter = %s', casual.quarter);
const dateScalarMocks = {
  Year: () => casual.recentYear,
  Quarter: () => casual.quarter,
  Month: () => casual.twoDigitMonth,
  Week: () => casual.weekInYear,
  Day: () => casual.dayOfMonth,
};

export default dateScalarMocks;
