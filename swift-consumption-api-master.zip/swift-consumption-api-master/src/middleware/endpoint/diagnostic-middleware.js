import { ROUTES } from '../route/routes';
import koaRouter from 'koa-router';
import DiagnosticMiddlewareHandler from '../handler/diagnostic-middleware-handler';

export default class DiagnosticMiddleware {
  static configure() {
    const handler = new DiagnosticMiddlewareHandler();
    const router = new koaRouter({prefix: ROUTES.DIAGNOSTIC});

    router.get(ROUTES.INFO, async(ctx) => {
      await handler.infoHandler(ctx);
    });

    return router;
  }
}