import { ROUTES } from '../route/routes';
import koaRouter from 'koa-router';
import APIMiddlewareHandler from '../handler/api-middleware-handler';

export default class APIMiddleware {
  static configure(mongoDao, metadataCache) {
    const handler = new APIMiddlewareHandler(mongoDao, metadataCache);
    const router = new koaRouter({prefix: ROUTES.API});

    router.post(ROUTES.SEARCH, async(ctx) => {
      await handler.searchHandler(ctx);
    });

    return router;
  }
}