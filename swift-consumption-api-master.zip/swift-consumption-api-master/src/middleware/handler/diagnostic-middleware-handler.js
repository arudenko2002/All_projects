import { version } from '../../../package.json';

export default class DiagnosticMiddlewareHandler {

  async infoHandler(ctx) {
    const obj = { 'APP Version' : version || 'No Version', 'Node Env': process.env.NODE_ENV};  
    ctx.body = obj;
  }
}