import { inspect } from 'util';
import logger from '../../lib/logger';
import HttpConstants from '../../constants/http-constants';
import StatusConstants from '../../constants/status-constants';
import CookieHelper from '../../helper/cookie-helper';
import UserHelper from '../../helper/user-helper';
import TokenBusiness from '../../business/token-business';

export default class APIMiddlewareHandler {
  constructor(mongoDao, metadataCache) {
    this.mongoDao = mongoDao;
    this.metadataCache = metadataCache;
    this.cookieHelper = new CookieHelper();
    this.userHelper = new UserHelper();
    this.tokenBusiness = new TokenBusiness();
  }

  async searchHandler(ctx) {
    const result = {};

    try {

      const userInfo = (ctx.request && ctx.request.body) ? ctx.request.body.userInfo : null;
      const searchTerm = (ctx.request && ctx.request.body) ? ctx.request.body.searchTerm : null;
      const searchAreas = (ctx.request && ctx.request.body) ? ctx.request.body.searchAreas : null;
      const paging = (ctx.request && ctx.request.body && ctx.request.body.paging) ? ctx.request.body.paging : { skip: 0, limit: 20 };

      if(!searchTerm || !Array.isArray(searchAreas)) {
        ctx.status = HttpConstants.BADREQUEST;
        result.info = StatusConstants.MISSINGINPUTDATA;
        ctx.body = result;
        return;
      }

      if(!userInfo) {
        ctx.status = HttpConstants.BADREQUEST;
        result.info = StatusConstants.MISSINGUSERAPP;
        ctx.body = result;
        return;
      }

      let albums = [];
      let artists = [];
      let isrcs = [];
      let projects = [];
      let tracks = [];
      
      if (searchAreas.find(type => type === 'Album')) {       
        albums = await this.mongoDao.album.search(searchTerm, paging);
        logger.info(`Searching Albums for phrase: ${searchTerm} and found ${albums.length} items`);
      }
      if (searchAreas.find(type => type === 'Artist')) {               
        artists = await this.mongoDao.artist.search(searchTerm, paging);
        logger.info(`Searching Artists for phrase: ${searchTerm} and found ${artists.length} items`);        
      }
      if (searchAreas.find(type => type === 'Isrc')) {      
        isrcs = await this.mongoDao.isrc.search(searchTerm, paging);
        logger.info(`Searching ISRCs for phrase: ${searchTerm} and found ${isrcs.length} items`);        
      }
      if (searchAreas.find(type => type === 'Project')) {       
        projects = await this.mongoDao.project.search(searchTerm, paging);
        logger.info(`Searching Projects for phrase: ${searchTerm} and found ${projects.length} items`);        
      }
      if (searchAreas.find(type => type === 'Track')) {       
        tracks = await this.mongoDao.track.search(searchTerm, paging);
        logger.info(`Searching Tracks for phrase: ${searchTerm} and found ${tracks.length} items`);        
      }
      
      if(userInfo.userType && userInfo.userType === 'External Restricted') {
        const allowedArtists = await this.userHelper.getUserArtists(userInfo, this.mongoDao, this.metadataCache);

        const resultArtists = [];
        const resultProjects = [];
        const resultTracks = [];
        const resultIcrs = [];
        const resultAlbums = [];

        allowedArtists.forEach(id => {
          if(Array.isArray(albums)) {
            const al = albums.find(item => (item.artist && item.artist.id == id));
            if(al) {
              resultAlbums.push(al);
            }
          }

          if(Array.isArray(projects)) {
            const pr = projects.find(item => (item.artist && item.artist.id == id));
            if(pr) {
              resultProjects.push(pr);
            }
          }

          if(Array.isArray(artists)) {
            const ar = artists.find(item => item._id == id);
            if(ar) {
              resultArtists.push(ar);
            }
          }

          if(Array.isArray(tracks)) {
            const tr = tracks.find(item => (item.artist && item.artist.id == id));
            if(tr) {
              resultTracks.push(tr);
            }
          }

          if(Array.isArray(isrcs)) {
            const is = isrcs.find(item => (item.artist && item.artist.id == id));
            if(is) {
              resultIcrs.push(is);
            }
          }
        });
      
        artists = resultArtists;
        projects = resultProjects;
        tracks = resultTracks;
        isrcs = resultIcrs;
        albums = resultAlbums;
      }
      
      result.artists = artists;
      result.projects = projects;
      result.tracks = tracks;
      result.isrcs = isrcs;
      result.albums = albums;

      ctx.status = HttpConstants.OK;
      result.info = StatusConstants.SUCCESSFULLACTION;
      ctx.body = result;

      return;
    } catch(err) {
      logger.info('Error In Search Process %s', inspect(err, false, null, false));
      ctx.status = HttpConstants.SERVERERROR;
    }
  }
}