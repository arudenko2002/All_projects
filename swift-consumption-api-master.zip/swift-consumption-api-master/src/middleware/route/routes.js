export const ROUTES = {
  SEARCH: '/search',
  API: '/api',
  DIAGNOSTIC: '/diagnostic',
  INFO: '/api/info'
};