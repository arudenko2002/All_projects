import jwt from 'jsonwebtoken';
import settings from '../config';
const { auth } = settings;

export default class TokenBusiness {

  async verifyToken(token){
    return await( new Promise((resolve, reject) =>{
      jwt.verify(token, auth.secret, function(err, decoded) {
        if(err){
          reject(err);
        } else {
          resolve(decoded);
        }
      });
    }));
  }
}