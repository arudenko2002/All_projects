Utilities for use in tests.
