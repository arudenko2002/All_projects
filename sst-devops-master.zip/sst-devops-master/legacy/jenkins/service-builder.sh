#!/bin/bash
set -e

# Get current project
PROJECT_ID=$(curl -s 'http://metadata/computeMetadata/v1/project/project-id' -H 'Metadata-Flavor: Google')

# Packer
if [ -f "packer.json" ]; then

  # Install Packer
  curl -L https://releases.hashicorp.com/packer/1.0.0/packer_1.0.0_linux_amd64.zip -o /tmp/packer.zip; unzip /tmp/packer.zip -d /usr/local/bin

  # Run build
  packer build \
    -var "project_id=${PROJECT_ID}" \
    -var "git_commit=${GIT_COMMIT:0:7}" \
    -var "git_branch=${GIT_BRANCH#*/}" \
    packer.json
fi

# Docker
if [ -f "Dockerfile" ]; then

  # Create and push Docker version of the image
  IMAGE_TAG=us.gcr.io/${PROJECT_ID}/${GIT_BRANCH#*/}/${GIT_COMMIT:0:7}

  # Build image
  docker build -t $IMAGE_TAG .

  # Push image
  gcloud docker push $IMAGE_TAG

  # Remove local image
  docker rmi $IMAGE_TAG
fi