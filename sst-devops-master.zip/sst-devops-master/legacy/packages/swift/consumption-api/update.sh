#!/bin/bash

# Time the update
time(
    echo "Updating swift-consumption-api deployment..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl set image deployment/swift-consumption-api \
                swift-consumption-api=us.gcr.io/umg-dev/swift-consumption-api:latest \
                --namespace=swift-consumption

    echo "Updated swift-consumption-api deployment!"
)