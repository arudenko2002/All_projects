# UMG Swift Cloud Functions

A collection of serverless [Google Cloud Functions](https://cloud.google.com/functions/) designed to perform various tasks for UMG Swift apps and resources.