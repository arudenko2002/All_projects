# UMG Swift Kubernetes Script Generator

_Note: This utility is still highly experimental._

Automatically generates Kubernetes deployment scripts in response to new image pushes to the container registry.

1. Subscribes to container registry updates
2. Receives update notification
3. Gets updated image name
4. Generates Kubernetes deployment scripts
5. Saves scripts to storage bucket
6. Publishes a message indicating process completion