/**
 * Kubernetes Script Generator
 *
 * @param {!Object} event The Cloud Functions event.
 * @param {!Function} The callback function.
 */
exports.k8sScriptGenerator = function k8sScriptGenerator(event, callback) {
  const gcs = require('@google-cloud/storage')({
    projectId: 'umg-dev',
    keyFilename: './credentials/google-credentials.umg-dev.json'
  });

  // Use storage bucket
  const storage = gcs.bucket('swift-devops');
  
  // Get image name
  const image = event.data.data;

  // Set path
  const path = `kubernetes/swift-${image}/${image}`;

  // Write Namespace config
  console.log(`Writing Namespace config for ${image}...`);
  storage.file(`${path}-namespace.yml`).createWriteStream().pipe(`apiVersion: v1
    kind: Namespace  
    metadata:
      name: ${image}`);

  // Write Pod config
  console.log(`Writing Pod config for ${image}...`);
  storage.file(`${path}-pod.yml`).createWriteStream().pipe(`apiVersion: v1
    kind: Pod
    metadata:
      name: ${image}
      namespace: ${image}
      labels:
        umg-swift: ${image}
    spec:
      containers:
      - name: ${image}
        image: us.gcr.io/umg-dev/${image}`);

  // Create service
  console.log(`Writing Service config for ${image}...`);
  storage.file(`${path}-service.yml`).createWriteStream().pipe(`apiVersion: v1
    kind: Service
    metadata:
      name: ${image}
      namespace: ${image}
    spec:
      selector:
        umg-swift: ${image}
      type: LoadBalancer`);


  // Publish completion notification
  console.log('Kubernetes script generation complete!')

  // Call the callback
  callback();
};