#!/bin/bash

# Config
local_files=$(ls ~/work/aktarytech/umg/metadata/Metadata\ \(Latest\))
# files=$(gsutil ls gs://umg-dev/data/swift/consumption/metadata/**/*.json)
# name_regex="^gs.*(json)"
# date_regex="Update time:\s*([^(GM)]*)"

time(

    for file in $local_files
    do
        [[ $file =~ [^.]* ]] && collection="${BASH_REMATCH}-latest"
        echo "Ingesting ${file} to collection ${collection}..."
        mongoimport --host 104.196.226.6:27017 \
                    --username mongodb-admin \
                    --password eef9XeifIemiech8 \
                    --authenticationDatabase admin \
                    --db sst-metadata-dev \
                    --collection $collection \
                    --type json \
                    --file ~/work/aktarytech/umg/metadata/Metadata\ \(Latest\)/$file
    done

    # Keep a log file of the last time metadata was scanned for updates
    # if [ ! -e ./.ingest_history ]; then
    #     # # create log
    #     # touch ./.ingest_history

    #     # # populate log
    #     # for f in $files
    #     # do
    #     #     file=$(gsutil stat $f)
    #     #     [[ $file =~ $name_regex ]] && echo ${BASH_REMATCH} >> ./.ingest_history
    #     #     [[ $file =~ $date_regex ]] && echo $(date -j -f "%a, %d %b %Y %H:%M:%S" "${BASH_REMATCH[1]}" "+%s") >> ./.ingest_history
    #     # done
    # else
    #     # Scan the storage bucket for object dates
    #     for f in $files
    #     do
    #         file=$(gsutil stat $f)
    #         date=$BASH_REMATCH[1] | xargs
    #         [[ $file =~ $date_regex ]] && echo $(date -j -f "%a, %d %b %Y %H:%M:%S" "$(echo $BASH_REMATCH[1] | xargs)" "+%s")
    #         echo $date
    #     done

    #     # Check to see if dates are newer than log file

    #     # gsutil ls gs://umg-dev/data/swift/consumption/metadata/

    #     # Stream the metadata to a mongoimport command into a temp collection

    #     # Run tests on the ingested data
    #     # Alert with ingestion/testing status
    # fi        
)