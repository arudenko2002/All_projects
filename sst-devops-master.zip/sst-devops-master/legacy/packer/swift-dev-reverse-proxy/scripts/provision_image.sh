#!/bin/bash

time(
  echo "Provisioning Swift Development Reverse Proxy image..."

  # Create Traefik user
  groupadd -r traefik && useradd -r -g traefik traefik

  # Update system
  apt-get update && apt-get install -y --no-install-recommends \
    curl \
		wget \
	&& rm -rf /var/lib/apt/lists/*

  cd /home

  # Install kubectl
  curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.5.7/bin/linux/amd64/kubectl
  chmod +x ./kubectl
  mv ./kubectl /usr/local/bin/kubectl

  # Install Traefik
  wget https://github.com/containous/traefik/releases/download/v1.3.0/traefik_linux-amd64
  chmod u+x ./traefik_linux-amd64
  mv ./traefik_linux-amd64 /usr/local/bin/traefik

  # Get cluster credentials
  gcloud container clusters get-credentials umg-swift-dev \
    --zone us-west1-a --project umg-dev

  # Start kubectl proxy
  kubectl proxy --port=8080 &

  # Start Traefik
  traefik -c /home/traefik.toml

  echo "Finished!"
)

