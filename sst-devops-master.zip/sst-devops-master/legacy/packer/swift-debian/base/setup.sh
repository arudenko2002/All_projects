#!/bin/bash

# Git
sudo apt-get install -y --no-install-recommends \
     apt-transport-https \
     ca-certificates \
     curl \
     git \
     software-properties-common

# NVM
curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.1/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" # This loads nvm

# Node
if [ -f ./.nvmrc ]; then
    nvm use
else
    nvm install node
fi

# Vault
curl -o- https://releases.hashicorp.com/vault/0.7.0/vault_0.7.0_linux_amd64.zip | tar -xvf vault_0.7.0_linux_amd64.zip
cp vault_0.7.0_linux_amd64/vault /usr/bin/vault
rm -rf vault_0.7.0_linux_amd64*

# MongoDB
sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 0C49F3730359A14518585931BC711F9BA15703C6
echo "deb http://repo.mongodb.org/apt/debian jessie/mongodb-org/3.4 main" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.4.list
sudo apt-get update && apt-get install -y mongodb-org
sudo service mongod start

# Google Cloud CLI
export CLOUD_SDK_REPO="cloud-sdk-$(lsb_release -c -s)"
echo "deb https://packages.cloud.google.com/apt $CLOUD_SDK_REPO main" | sudo tee -a /etc/apt/sources.list.d/google-cloud-sdk.list
curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
sudo apt-get update && sudo apt-get install google-cloud-sdk

# Docker CLI
sudo apt-get remove docker docker-engine
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -
sudo add-apt-repository \
    "deb [arch=amd64] https://download.docker.com/linux/debian \
    $(lsb_release -cs) \
    stable"
sudo apt-get update && sudo apt-get install docker-ce
sudo groupadd docker
sudo usermod -aG docker swift
sudo systemctl enable docker

# Packer
curl -o- https://releases.hashicorp.com/packer/1.0.0/packer_1.0.0_linux_amd64.zip | tar -xvf packer_1.0.0_linux_amd64.zip
mv packer_1.0.0_linux_amd64/packer /usr/bin/packer
rm -rf packer_1.0.0_linux_amd64*

# Vagrant
curl -o- https://releases.hashicorp.com/vagrant/1.9.3/vagrant_1.9.3_x86_64.deb
mv vagrant_1.9.3_x86_64.deb /var/cache/apt/archives/vagrant.deb
sudo apt-get install vagrant