#!/bin/bash

time(
  echo "Provisioning Swift Vault image..."

  # Installing Vault
  sudo mkdir -p /opt/bin
  cd /tmp
  curl -s -L -O https://releases.hashicorp.com/vault/0.7.2/vault_0.7.2_linux_amd64.zip \
  && sudo unzip -o vault_0.7.2_linux_amd64.zip -d /opt/bin \
  && sudo chmod 755 /opt/bin/vault \
  && rm vault_0.7.2_linux_amd64.zip \
  && cd /var/lib/apps/vault/certs;
  ./gen.sh

  

  echo "Finished!"
)

