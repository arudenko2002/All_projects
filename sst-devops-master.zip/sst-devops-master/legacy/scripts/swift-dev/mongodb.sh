#!/bin/bash

gcloud compute --project "umg-dev" ssh --zone "us-west1-a" "umg-swift-dev-mongodb-server-1"
