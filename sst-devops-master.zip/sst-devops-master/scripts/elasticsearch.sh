#!/bin/bash

gcloud container clusters get-credentials umg-swift-elasticsearch \
    --zone us-central1-a --project umg-swift

kubectl proxy
