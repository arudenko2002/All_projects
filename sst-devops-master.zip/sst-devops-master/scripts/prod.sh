#!/bin/bash

echo "Switching kubectl context to the Swift Prod cluster..." 

gcloud container clusters get-credentials umg-swift-prod \
    --zone us-central1-a --project umg-swift

kubectl proxy
