#!/bin/bash

echo "Switching kubectl context to the Swift Dev cluster..." 

gcloud container clusters get-credentials umg-swift-dev \
    --zone us-west1-a --project umg-dev

kubectl proxy
