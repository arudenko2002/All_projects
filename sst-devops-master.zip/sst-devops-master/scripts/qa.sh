#!/bin/bash

echo "Switching kubectl context to the Swift QA cluster..." 

gcloud container clusters get-credentials umg-swift-qa \
    --zone us-central1-a --project umg-dev

kubectl proxy
