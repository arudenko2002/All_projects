# UMG Swift Development Environment

Contains [Terraform](https://www.terraform.io/) configuration files for automatically creating and deploying a development cluster for UMG Swift apps in the `umg-dev` GCP project. You will need Terraform installed locally to use this package.

## Package Contents

Folders
- `.terraform/` - Folder containing Terraform state files
- `artifacts/` - Folder containing misc config files
- `credentials/` - Folder containing auth credentials
- `modules/` - Folder containing Terraform modules for various GCP services
- `plans/` - Folder containing auto-generated deployment plans

Scripts
- `deploy.sh` - Deployment script
- `init.sh` - Initialization script
- `plan.sh` - Planning script (shows what will be changed on deployment)

Terraform Configs
- `backend.tf` - Terraform storage backend
- `dev-cluster.tf` - Swift Dev cluster configs
- `outputs.tf` - Displays the outputs of various deployment processes
- `provider.tf` - GCP credentials and auth config
- `qa-cluster.tf` - Swift QA cluster configs
- `storage.tf` - GCP persistent disk configs
- `vars.tf` - Terraform variable definitions

## Deployment

First, initialize the remote state:

    $ ./init.sh

To perform a "dry run" to see what will be changed:

    $ ./plan.sh

To apply the configurations, run the deployment script:

    $ ./deploy.sh

This will create, timestamp, store, and then apply a Terraform deployment plan.