#!/bin/bash

echo "Deploying UMG Swift Development Environment..."

# Prepare a timestamp
TIMESTAMP=$(date +"%Y-%m-%d")T$(date +"%T")

# Make sure the plans folder exists
if [ ! -d "plans" ]; then mkdir plans; fi

# Make sure we have all our modules
terraform get

# Create the plan
terraform plan --out plans/$TIMESTAMP-plan.tf

# Execute the plan
terraform apply plans/$TIMESTAMP-plan.tf