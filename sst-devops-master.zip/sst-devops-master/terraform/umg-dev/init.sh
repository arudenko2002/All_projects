#!/bin/bash

# Gets config vars from terraform.tfvars
function getConfig() 
{
    if [ ! -z "$1" ]; then
        if [ -f "terraform.tfvars" ]; then
            echo $(cat terraform.tfvars | grep $1 | grep -o '".*"' | sed 's/"//g')
            return 1
        else
            return 0
        fi
    else
        return 0
    fi
}

# Set remote state
terraform remote config \
    -backend=gcs \
    -backend-config="bucket=$(getConfig terraform_state_bucket)" \
    -backend-config="path=$(getConfig terraform_state_path)" \
    -backend-config="project=$(getConfig gcp_project_name)" \
    -backend-config="credentials=$(getConfig gcp_credentials_file_path)"