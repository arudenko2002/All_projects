# UMG Swift Travis Template

This template is for a Travis configuration file. A `.travis.yml` file is required to be in your project's root before Travis will run builds on it. You will be unable to create a pull request for a project branch until the file is present and the branch's Travis build is passing.

## Configuring

The `.travis.yml` file has been written with Node.js applications in mind. However, the fields may be modified to support other languages:

- `cache` - Dependency caching; defaults to "yarn".
- `language` - Project language; defaults to "node_js".
- `[language]` - Language version; defaults to `node_js` and looks for an `.nvmrc` file in the project root.

The only field that is required to be modified to suit your particular use case is `script`:

- `script` - The script used to start the app (e.g. `ENV=production npm start`, `forever app`).

_If your builds are failing and you do not have any linting errors or failing tests, make sure the script used in the `script` field is accurate. It should be the same command you type in at the command line to start your app._