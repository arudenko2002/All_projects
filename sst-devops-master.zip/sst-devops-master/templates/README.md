# UMG Swift Templates

Blank and pre-filled templates for creating and configuring various UMG Swift resources.

## Cloud Functions

Template for creating [Google Cloud Functions](https://cloud.google.com/functions/).

## Docker

Template for creating [Docker](https://www.docker.com/) images.

## Travis

Templates for creating [Travis](https://travis-ci.com/) configuration files.