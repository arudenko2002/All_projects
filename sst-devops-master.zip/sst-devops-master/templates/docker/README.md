# UMG Swift Docker Template

**A custom template for building UMG Swift Docker images.**

Use this package to create new Docker images for Swift resources. Fill in the Dockerfile and entrypoint script, add your image name to the build and push scripts (or set the `DOCKER_IMAGE_NAME` env var), and you're ready to go.

## Package Contents

This package contains:

- `build.sh` - Container build script
- `docker-entrypoint.sh` - Container entrypoint script (if applicable)
- `Dockerfile` - The Dockerfile
- `push.sh` - Container upload script

## Building

Add the image name to `build.sh` (or set the `DOCKER_IMAGE_NAME` env var), then run the build script:

    $ ./build.sh

## Updating

To push the build to the Container Registry, add the image name to `push.sh` (or set the `DOCKER_IMAGE_NAME` env var) and use the push script:

    $ ./push.sh

## Deploying

Images are deployed using [Kubernetes scripts](https://github.com/umg/sst-devops/tree/master/kubernetes/).