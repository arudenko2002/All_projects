#!/bin/bash

docker build -t us.gcr.io/umg-dev/$DOCKER_IMAGE_NAME .