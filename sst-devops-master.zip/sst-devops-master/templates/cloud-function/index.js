/**
 * Template for Google Cloud Functions (functions triggered by some external event)
 *
 * @param {!Object} event The Cloud Functions event.
 * @param {!Function} The callback function.
 */
exports.func = function func(event, callback) {
  // event.data         the triggering message object
  // event.data.data    the triggering message data

  // Business logic goes here

  // Call the callback
  callback();
};