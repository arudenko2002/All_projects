#!/bin/bash

# Prepare a timestamp
TIMESTAMP=$(date +"%Y-%m-%d")T$(date +"%T")

echo "${TIMESTAMP} Preparing to load test the Consumption Client... @ $1 connections for $2 seconds"
echo "${TIMESTAMP} "
echo "${TIMESTAMP} Running load tests..."
echo ""

## Autocannon tests
autocannon -c $1 -d $2 -l -j "http://localhost:3000/" > results/client_$TIMESTAMP.json