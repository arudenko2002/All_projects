#!/bin/bash

echo "Firing autocannons!"

./albums.sh;
./artists.sh;
./isrcs.sh;
./metadata.sh;
./projects.sh;
./search.sh;
./top-artists.sh;
./top-projects.sh;
./top-tracks.sh;
./tracks.sh;