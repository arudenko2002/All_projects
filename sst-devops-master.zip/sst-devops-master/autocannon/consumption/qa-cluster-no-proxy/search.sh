#!/bin/bash

# Prepare a timestamp
TIMESTAMP=$(date +"%Y-%m-%d")T$(date +"%T")

echo "${TIMESTAMP} Preparing to load test the Consumption API @ 300 connections/30 seconds"
echo "${TIMESTAMP} "
echo "${TIMESTAMP} Running Search query tests..."
echo ""

## Autocannon load tests
autocannon -c 300 -d 30 -l -j "http://swift-qa.umusic.com:32765/graphql?operationName=MetadataSearch&query=query%20MetadataSearch(%24searchText%3A%20String!%2C%20%24paging%3A%20Paging)%20%7B%0A%20%20search%20(searchText%3A%20%24searchText%2C%20paging%3A%20%24paging)%20%7B%0A%20%20%20%20__typename%0A%20%20%20%20...%20on%20Album%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%20%20project%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%20%20...%20on%20Artist%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%7D%0A%20%20%20%20...%20on%20Isrc%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%20%20track%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%20%20...%20on%20Project%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%20%20artist%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%20%20...%20on%20Track%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%20%20artist%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20project%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D&variables=%7B%0A%20%20%22searchText%22%3A%20%22drake%22%2C%0A%20%20%22paging%22%3A%20%7B%0A%20%20%20%20%22skip%22%3A%200%2C%0A%20%20%20%20%22limit%22%3A%2010%0A%20%20%7D%0A%7D" > results/search_$TIMESTAMP.json