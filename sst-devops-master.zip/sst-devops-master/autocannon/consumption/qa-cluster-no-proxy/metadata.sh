#!/bin/bash

# Prepare a timestamp
TIMESTAMP=$(date +"%Y-%m-%d")T$(date +"%T")

echo "${TIMESTAMP} Preparing to load test the Consumption API @ 300 connections/30 seconds"
echo "${TIMESTAMP} "
echo "${TIMESTAMP} Running Metadata query tests..."
echo ""

## Autocannon load tests
autocannon -c 300 -d 30 -l -j "http://swift-qa.umusic.com:32765/graphql?operationName=undefined&query=query%20%7B%0A%20%20metadata%20%7B%0A%20%20%20%20partners%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%7D%0A%20%20%20%20territories%20%7B%0A%20%20%20%20%20%20regions%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20countries%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%20%20genres%20%7B%0A%20%20%20%20%20%20id%0A%20%20%20%20%20%20name%0A%20%20%20%20%7D%0A%20%20%20%20labels%20%7B%0A%20%20%20%20%20%20segments%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%20%20families%20%7B%0A%20%20%20%20%20%20%20%20id%0A%20%20%20%20%20%20%20%20name%0A%20%20%20%20%20%20%7D%0A%20%20%20%20%7D%0A%20%20%20%20weekBoundaries%20%7B%0A%20%20%20%20%20%20startDate%2C%0A%20%20%20%20%20%20endDate%0A%20%20%20%20%7D%0A%20%20%7D%0A%7D&variables=" > results/metadata_$TIMESTAMP.json