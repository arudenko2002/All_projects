K8S_NODES=$(kubectl get nodes | grep "Ready" | cut -d" " -f1 | tr '\n' '\t')

for node in $K8S_NODES; do
  NODE_IP=$(kubectl describe node $node \
            | egrep -w "Addresses"      \
            | tr '\n' '\t'              \
            | cut -d"," -f1             \
            | rev                       \
            | cut -d$'\t' -f1           \
            | rev)
  kubectl describe node ${node}  \
            | egrep -w "Name:|PodCIDR"  \
            | tr '\n' '\t'              \
            | awk -v IP=$NODE_IP '{ print "sudo route add -net " , $4 , " gw " , IP }'
done
