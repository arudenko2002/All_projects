#!/bin/bash

if [ "$1" = 'dizzee-client' ]; then
    time(
        echo "Deploying Dizzee Client..."

        kubectl apply -f dizzee-client/namespaces --record
        kubectl create secret generic umusic-com-ssl --namespace=dizzee --from-file=./dizzee-client/certificates/tls.crt --from-file=./dizzee-client/certificates/tls.key
        kubectl create configmap nginx-config --from-file=./dizzee-client/config-maps/default.conf --namespace=dizzee
        kubectl apply -f dizzee-client/deployments --record
        kubectl apply -f dizzee-client/services --record
        kubectl apply -f dizzee-client/ingresses --record

        echo "Deployed Dizzee Client!"
    )
elif [ "$1" = 'dizzee' ]; then
    time(
        echo "Deploying Dizzee..."

        kubectl apply -f dizzee/namespaces --record
        kubectl create secret generic umusic-com-ssl --namespace=dizzee --from-file=./dizzee/certificates/tls.crt --from-file=./dizzee/certificates/tls.key
        kubectl apply -f dizzee/deployments --record
        kubectl apply -f dizzee/services --record
        kubectl apply -f dizzee/ingresses --record

        echo "Deployed Dizzee!"
    )
elif [ "$1" = 'consumption-api' ]; then
    time(
        echo "Deploying Swift Consumption API..."

        kubectl apply -f consumption-api/namespaces --record
        kubectl apply -f consumption-api/deployments --record
        kubectl apply -f consumption-api/services --record

        echo "Deployed Swift Consumption API!"
    )
elif [ "$1" = 'dizzee-api' ]; then
    time(
        echo "Deploying Dizzee API..."

        kubectl apply -f dizzee-api/deployments --record
        kubectl apply -f dizzee-api/services --record

        echo "Deployed Dizzee API!"
    )
else
    echo "Usage: deploy.sh [dizzee-client|consumption-api]"
fi