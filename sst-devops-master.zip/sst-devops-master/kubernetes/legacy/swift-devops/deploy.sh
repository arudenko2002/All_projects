#!/bin/bash

# Time the deployment
time(
    echo "Deploying swift-devops..."

    kubectl create -f namespaces --record

    echo "Deployed swift-devops!"
)