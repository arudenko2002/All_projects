#!/bin/bash

# Time the deployment
time(
    echo "Deploying swift-devops-collins..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl create -f deployments --record \
                   -f services --record

    echo "Deployed swift-devops-collins!"
)