#!/bin/bash

# Time the update
time(
    echo "Updating swift-vault deployment..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl set image deployment/swift-vault \
                vault=us.gcr.io/umg-dev/swift-vault:latest \
                --namespace=vault

    echo "Updated swift-vault deployment!"
)