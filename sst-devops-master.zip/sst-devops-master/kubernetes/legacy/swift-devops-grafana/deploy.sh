#!/bin/bash

# Time the deployment
time(
    echo "Deploying swift-devops-grafana..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl create -f volumes --record \
                   -f deployments --record \
                   -f services --record

    echo "Deployed swift-devops-grafana!"
)