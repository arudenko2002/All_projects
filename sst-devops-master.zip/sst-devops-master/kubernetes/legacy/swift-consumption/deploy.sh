#!/bin/bash

# Time the deployment
time(
    echo "Deploying swift-consumption-api..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl create -f namespaces --record \
                   -f deployments --record \
                   -f services --record

    echo "Deployed swift-consumption-api!"
)