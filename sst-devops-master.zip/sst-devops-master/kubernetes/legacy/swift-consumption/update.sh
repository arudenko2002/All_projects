#!/bin/bash

# Time the update
time(
    echo "Updating swift-consumption-api deployment..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl apply -f deployments --record

    echo "Updated swift-consumption-api deployment!"
)