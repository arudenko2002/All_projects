#!/bin/bash

# Time the deployment
time(
    echo "Removing swift-devops-git..."

    RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
    kubectl delete persistentVolumeClaim devops-git-claim --namespace=devops &&
    kubectl delete persistentVolumeClaim devops-postgres-claim --namespace=devops &&
    kubectl delete persistentVolume devops-git-volume &&
    kubectl delete persistentVolume devops-postgres-volume &&
    kubectl delete deployment devops-git --namespace=devops &&
    kubectl delete service devops-git --namespace=devops

    echo "Removed swift-devops-git!"
)