#!/bin/bash

if [ "$1" = 'git' ]; then
    time(
        echo "Deploying Git..."

        kubectl apply -f git/volumes --record
        kubectl apply -f git/claims --record
        kubectl apply -f git/deployments --record
        kubectl apply -f git/services --record

        echo "Deployed Git!"
    )
elif [ "$1" = 'filebeat' ]; then
    time(
        echo "Deploying Filebeat..."

        kubectl apply -f filebeat/daemon-sets --record

        echo "Deployed Filebeat!"
    )
elif [ "$1" = 'traefik' ]; then
    time(
        echo "Deploying Traefik..."

        kubectl apply -f traefik/namespaces --record
        kubectl create secret generic umusic-com-ssl --namespace=edge-router --from-file=./traefik/certificates/tls.crt --from-file=./traefik/certificates/tls.key
        kubectl create configmap traefik-config --from-file=./traefik/config-maps/traefik.config.toml --namespace=edge-router
        kubectl apply -f traefik/daemon-sets --record
        kubectl apply -f traefik/services --record

        echo "Deployed Traefik!"
    )
elif [ "$1" = 'elk' ]; then
    time(
        echo "Deploying ELK Stack (ElasticSearch/Logstash/Kibana)..."

        kubectl apply -f elk/namespaces --record
        kubectl create secret generic umusic-com-ssl --namespace=elk --from-file=./traefik/certificates/tls.crt --from-file=./traefik/certificates/tls.key
        kubectl apply -f elk/config-maps --record
        kubectl apply -f elk/volumes --record
        kubectl apply -f elk/claims --record
        kubectl apply -f elk/deployments --record
        kubectl apply -f elk/services --record
        # kubectl apply -f elk/ingresses --record

        echo "Deployed ELK Stack!"
    )
elif [ "$1" = 'bosun' ]; then
    time(
        echo "Deploying Bosun..."

        kubectl apply -f bosun/deployments --record
        kubectl apply -f bosun/services --record

        echo "Deployed Bosun!"
    )
elif [ "$1" = 'jenkins' ]; then
    time(
        echo "Deploying Jenkins..."

        kubectl apply -f jenkins/namespaces --record
        kubectl create secret generic umusic-com-ssl --namespace=jenkins --from-file=./jenkins/certificates/tls.crt --from-file=./jenkins/certificates/tls.key
        kubectl create secret generic jenkins-ssl --namespace=jenkins --from-file=./jenkins/certificates/tls.jks
        kubectl apply -f jenkins/volumes --record
        kubectl apply -f jenkins/claims --record
        kubectl apply -f jenkins/deployments --record
        kubectl apply -f jenkins/services --record
        kubectl apply -f jenkins/ingresses --record

        echo "Deployed Jenkins!"
    )
elif [ "$1" = 'puppet' ]; then
    time(
        echo "Deploying Puppet..."

        kubectl apply -f puppet/namespaces --record
        kubectl apply -f puppet/volumes --record
        kubectl apply -f puppet/deployments --record
        kubectl apply -f puppet/services --record

        echo "Deployed Puppet!"
    )
elif [ "$1" = 'vault' ]; then
    time(
        echo "Deploying Vault..."

        kubectl apply -f vault/namespaces --record
        kubectl apply -f vault/deployments --record
        kubectl apply -f vault/services --record

        echo "Deployed Vault!"
    )
elif [ "$1" = 'cadvisor' ]; then
    time(
        echo "Deploying cAdvisor..."

        kubectl apply -f cadvisor/daemon-sets --record

        echo "Deployed cAdvisor!"
    )
elif [ "$1" = 'devops' ]; then
    time(
        echo "Deploying Swift DevOps..."

        kubectl apply -f devops/namespaces --record

        echo "Deployed Swift DevOps!"
    )
else
    echo "Usage: deploy.sh [devops|git|jenkins|puppet|vault|elk]"
fi