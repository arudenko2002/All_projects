#!/bin/bash

time(
  echo "Deploying Jenkins..."

  # Generate Jenkins password
  PASSWORD=`openssl rand -base64 15`; echo "Your password is $PASSWORD"; sed -i.bak s#CHANGE_ME#$PASSWORD# ./options

  kubectl create -f namespaces --record
  kubectl create -f volumes --record
  kubectl create -f claims --record
  kubectl create secret generic jenkins --from-file=./options --namespace=jenkins
  kubectl create -f deployments --record
  kubectl create -f services --record
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /tmp/tls.key -out /tmp/tls.crt -subj "/CN=jenkins/O=jenkins"
  kubectl create secret generic tls --from-file=/tmp/tls.crt --from-file=/tmp/tls.key --namespace jenkins
  kubectl create -f ingresses --record

  echo "All resources deployed."
  echo
  echo "In a few minutes the load balancer will finish provisioning and Jenkins will be accessible. You can run the following to get its IP address:"
  echo
  echo "   kubectl get ingress jenkins --namespace jenkins -o \"jsonpath={.status.loadBalancer.ingress[0].ip}\";echo"
  echo
  echo "Login with user: jenkins and password ${PASSWORD}"
)