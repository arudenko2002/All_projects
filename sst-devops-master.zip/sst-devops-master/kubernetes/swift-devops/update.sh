#!/bin/bash

if [ "$1" = 'git' ]; then
    time(
        echo "Updating Git..."

        RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
        kubectl apply -f git/deployments --record
        kubectl apply -f git/services --record
        kubectl apply -f git/ingresses --record

        echo "Updated Git!"
    )
elif [ "$1" = 'jenkins' ]; then
    time(
        echo "Updating Jenkins..."

        RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
        kubectl apply -f jenkins/deployments --record

        echo "Updated Jenkins!"
    )
elif [ "$1" = 'puppet' ]; then
    time(
        echo "Updating Puppet..."

        RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
        kubectl apply -f puppet/deployments --record

        echo "Updated Puppet!"
    )
elif [ "$1" = 'vault' ]; then
    time(
        echo "Updating Vault..."

        RUNTIME_CONFIG=extensions/v1beta1/deployments=true \
        kubectl apply -f vault/deployments --record
        kubectl apply -f vault/services --record

        echo "Updated Vault!"
    )
else
    echo "Usage: update.sh [git|jenkins|puppet|vault]"
fi