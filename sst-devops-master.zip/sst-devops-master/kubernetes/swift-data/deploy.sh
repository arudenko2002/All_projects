#!/bin/bash

if [ "$1" = 'mongodb' ]; then
    time(
        echo "Deploying MongoDB..."

        kubectl apply -f mongodb/namespaces --record
        kubectl apply -f mongodb/volumes --record
        kubectl apply -f mongodb/claims --record
        kubectl apply -f mongodb/deployments --record
        kubectl apply -f mongodb/services --record

        echo "Deployed MongoDB!"
    )
else
    echo "Usage: deploy.sh [mongodb]"
fi