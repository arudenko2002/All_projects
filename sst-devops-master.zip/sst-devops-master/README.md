# UMG Swift DevOps

Contains resources to build, provision, and deploy Swift infrastructure and applications.

_The term "SST" is being deprecated in favor of "Swift" as the umbrella term for all data analytics projects._

## Infrastructure

[Terraform](https://www.terraform.io) is used to automatically configure and create the Swift infrastructure. Refer to their [downloads](https://www.terraform.io/downloads.html) page to install it locally. Each subfolder in the `terraform` folder includes a README detailing the specifics of that Terraform deployment.

### Creating

Before actually spinning up any infrastructure, Terraform shows a plan detailing exactly what it will do when it begins the creation process, allowing you to verify that everything is correct:

    $ terraform plan

If everything looks good, go ahead and finish the process:

    $ terraform apply

## Provisioning

_Coming soon..._

## Applications

Swift applications are automatically built into [Docker](https://docs.docker.com/) containers on [release](https://help.github.com/articles/about-releases/), stored in Google's [Container Registry](https://cloud.google.com/container-registry/), then deployed and managed using [Kubernetes](https://kubernetes.io/).

Each subfolder in the `kubernetes` folder in this repo contains:

- `deploy.sh` - Automatic deployment script
- `...-namespace.yml` - Namespace configuration (required)

Additionally, each subfolder may also contain one or more of the following configuration files:

- `...-claims.yml` - Persistent volume claims
- `...-namespace-policy.yml` - Namespace security policies
- `...-namespace-resources.yml` - Namespace resource quotas
- `...-pod.yml` - Pod configuration
- `...-pod-policy.yml` - Pod security policies
- `...-service.yml` - Service configuration
- `...-volumes.yml` - Persistent volumes

### CI/CD Pipeline

The `templates` folder in this repo contains sample `.travis.yml` Travis config files. One of these files must be placed in your project root for Travis to begin the build process.

### Deployment

_Coming soon..._

### Management

_Coming soon..._

### Security

Kubernetes uses [network policies](https://kubernetes.io/docs/user-guide/networkpolicies/) to restrict traffic to and from pods and namespaces on the cluster.