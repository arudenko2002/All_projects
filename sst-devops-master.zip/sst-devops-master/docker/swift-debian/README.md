# UMG Swift Debian Base Image

**A custom Docker base image for use with UMG Swift applications.**

The most up-to-date version of this image can be found at `us.gcr.io/umg-dev/swift-debian`. This image is based Debian 8 (Jessie).

## Package Contents

This package contains:

- `build.sh` - Container build script
- `Dockerfile` - The Dockerfile
- `push.sh` - Container upload script

## Building

Just run the build script:

    $ ./build.sh

## Updating

Use the push script:

    $ ./push.sh

## Deploying

Images are deployed using [Kubernetes scripts](https://github.com/umg/sst-devops/tree/master/kubernetes/).