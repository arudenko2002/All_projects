#!/bin/bash

echo "Adding Snap Telemetry to image..."

time(
  echo "Installing dependencies..."
  pip install psutil
  curl -s https://storage.googleapis.com/golang/go1.8.1.linux-amd64.tar.gz
  tar -C /usr/local -xzf go1.8.1.linux-amd64.tar.gz
  export PATH=$PATH:/usr/local/go/bin

  echo "Installing Snap..."
  curl -s https://packagecloud.io/install/repositories/intelsdi-x/snap/script.deb.sh | os=ubuntu dist=trusty bash
  apt-get install -y --no-install-recommends snap-telemetry

  echo "Starting Snap daemon..."
  systemctl start snap-telemetry

  echo "Downloading Snap plugins..."
  # go get github.com/opsvision/snap-plugin-collector-syslog
  # go get github.com/raintank/snap-plugin-collector-kubestate
  # go get github.com/raintank/snap-plugin-collector-ping
  # go get github.com/raintank/snap-plugin-collector-snapstats
  # go get github.com/Staples-Inc/snap-plugin-collector-netstat
  # go get github.com/Staples-Inc/snap-plugin-collector-procstat
  go get github.com/intelsdi-x/snap-plugin-collector-cpu
  # go get github.com/intelsdi-x/snap-plugin-collector-df
  # go get github.com/intelsdi-x/snap-plugin-collector-disk
  # go get github.com/intelsdi-x/snap-plugin-collector-docker
  # go get github.com/intelsdi-x/snap-plugin-collector-ethtool
  # go get github.com/intelsdi-x/snap-plugin-collector-interface
  # go get github.com/intelsdi-x/snap-plugin-collector-iostat
  # go get github.com/intelsdi-x/snap-plugin-collector-load
  # go get github.com/intelsdi-x/snap-plugin-collector-logs
  # go get github.com/intelsdi-x/snap-plugin-collector-meminfo
  # go get github.com/intelsdi-x/snap-plugin-collector-processes
  # go get github.com/intelsdi-x/snap-plugin-collector-psutil
  # go get github.com/intelsdi-x/snap-plugin-collector-schedstat
  # go get github.com/intelsdi-x/snap-plugin-collector-swap
  # go get github.com/intelsdi-x/snap-plugin-collector-use
  # go get github.com/intelsdi-x/snap-plugin-collector-users
  # go get github.com/intelsdi-x/snap-plugin-publisher-graphite
  
  echo "Loading Snap plugins..."
  # Collectors
  # snaptel plugin load snap-plugin-collector-syslog
  # snaptel plugin load snap-plugin-collector-kubestate
  # snaptel plugin load snap-plugin-collector-ping
  # snaptel plugin load snap-plugin-collector-netstat
  # snaptel plugin load snap-plugin-collector-procstat
  snaptel plugin load snap-plugin-collector-cpu
  # snaptel plugin load snap-plugin-collector-df
  # snaptel plugin load snap-plugin-collector-disk
  # snaptel plugin load snap-plugin-collector-docker
  # snaptel plugin load snap-plugin-collector-ethtool
  # snaptel plugin load snap-plugin-collector-interface
  # snaptel plugin load snap-plugin-collector-iostat
  # snaptel plugin load snap-plugin-collector-load
  # snaptel plugin load snap-plugin-collector-logs
  # snaptel plugin load snap-plugin-collector-meminfo
  # snaptel plugin load snap-plugin-collector-processes
  # snaptel plugin load snap-plugin-collector-schedstat
  # snaptel plugin load snap-plugin-collector-snapstats
  # snaptel plugin load snap-plugin-collector-swap
  # snaptel plugin load snap-plugin-collector-use
  # snaptel plugin load snap-plugin-collector-users

  # Processors
  #snaptel plugin load snap-plugin-processor-anomalydetection
  #snaptel plugin load snap-plugin-processor-statistics
  #snaptel plugin load snap-plugin-processor-tag

  # Publishers
  snaptel plugin load snap-plugin-publisher-graphite
  #snaptel plugin load snap-plugin-publisher-elasticsearch
  #snaptel plugin load snap-plugin-publisher-file
  #snaptel plugin load snap-plugin-publisher-cassandra
)