#!/bin/bash

echo "Adding NetData to image..."

time(
  echo "Downloading NetData..."
  git clone https://github.com/firehol/netdata.git --depth=1
  cd netdata
  
  echo "Installing and starting NetData..."
  ./netdata-installer.sh
)