#!/bin/bash

gcloud docker -- push us.gcr.io/umg-dev/swift-debian