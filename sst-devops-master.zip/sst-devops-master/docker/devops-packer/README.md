# UMG Swift DevOps - Packer

**A custom [Packer](https://tumblr.github.io/collins/) Docker image for use with UMG Swift applications.**

The most up-to-date version of this image can be found at `us.gcr.io/umg-dev/swift-devops-packer`. This image is based on the [Swift Debian base image](https://github.com/umg/sst-devops/tree/master/docker/swift-debian/).

## Use Cases

- Standalone build server
- Local builds using [Vagrant](https://www.vagrantup.com/)

## Package Contents

This package contains:

- `build.sh` - Container build script
- `docker-entrypoint.sh` - Container entrypoint script (if applicable)
- `Dockerfile` - The Dockerfile
- `push.sh` - Container upload script

## Building

Just run the build script:

    $ ./build.sh

## Updating

Use the push script:

    $ ./push.sh

## Deploying

Images are deployed using [Kubernetes scripts](https://github.com/umg/sst-devops/tree/master/kubernetes/).