#!/bin/bash

echo "Configuring build server..."

time(
  echo "Installing dependencies..."
  apt-get update && apt-get install -y --no-install-recommends \
    npm \
  && npm update \
  && npm install -g n

  echo "Installing Node.js..."
  n $(cat /home/build-server/.nvmrc)
)