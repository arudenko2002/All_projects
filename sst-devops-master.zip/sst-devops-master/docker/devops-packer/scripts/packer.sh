#!/bin/bash

echo "Adding Packer to image..."

time(
  echo "Downloading Packer..."
  cd /home
  curl -s https://releases.hashicorp.com/packer/1.0.0/packer_1.0.0_linux_amd64.zip

  echo "Installing Packer..."
  unzip packer_1.0.0_linux_amd64.zip -d /usr/local/bin/

  echo "Cleaning up..."
  rm packer_1.0.0_linux_amd64.zip
)