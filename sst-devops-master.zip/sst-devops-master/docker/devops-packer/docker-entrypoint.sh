#!/bin/bash

# Your Docker entrypoint script goes here (if applicable). If not, feel free to remove this file

# All entrypoint sripts must end with this command
exec "$@"