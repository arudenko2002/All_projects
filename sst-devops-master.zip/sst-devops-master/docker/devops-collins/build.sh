#!/bin/bash

docker build -t us.gcr.io/umg-dev/swift-devops-collins .