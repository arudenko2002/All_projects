# UMG Swift DevOps - Collins

**A custom [Collins](https://tumblr.github.io/collins/) Docker image for use with UMG Swift applications.**

The most up-to-date version of this image can be found at `us.gcr.io/umg-dev/swift-devops-collins`. This image is based on the [official Collins image](https://hub.docker.com/r/tumblr/collins/).

## Package Contents

This package contains:

- `conf/` - Collins configurations
- `build.sh` - Container build script
- `Dockerfile` - The Dockerfile
- `push.sh` - Container upload script

## Building

Just run the build script:

    $ ./build.sh

## Updating

Use the push script:

    $ ./push.sh

## Deploying

Images are deployed using [Kubernetes scripts](https://github.com/umg/sst-devops/tree/master/kubernetes/).