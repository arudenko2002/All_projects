# UMG Swift Docker Images

Contains resources to build [Docker](https://www.docker.com/) images for various UMG Swift resources. The most recent images can be found at `us.gcr.io/umg-dev`. You must [install Docker](https://www.docker.com/community-edition#/download) on your local machine to run these scripts.

## Building

Run the build script for the image you'd like to build:

    $ cd image-name
    $ ./build.sh

## Deploying

Use the [Kubernetes](https://kubernetes.io/docs/concepts/overview/what-is-kubernetes/) scripts found at [https://github.com/umg/sst-devops/tree/master/kubernetes](https://github.com/umg/sst-devops/tree/master/kubernetes) to deploy Docker images.