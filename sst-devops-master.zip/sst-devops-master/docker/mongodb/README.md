# UMG Swift MongoDB

**A custom [MongoDB](https://www.mongodb.com/) Docker image for use with UMG Swift applications.**

- Creates default admin user based on configuration files
- Automatically starts MongoDB with authentication enabled

The most up-to-date version of this image can be found at `us.gcr.io/umg-dev/swift-mongodb`. This image is based on the [official MongoDB image](https://hub.docker.com/_/mongo/).

## Package Contents

This package contains:

- `build.sh` - Container build script
- `docker-entrypoint.sh` - Container entrypoint script
- `Dockerfile` - The Dockerfile
- `MONGO_INITDB_ROOT_USERNAME_FILE` - Contains the default admin username
- `MONGO_INITDB_ROOT_PASSWORD_FILE` - Contains the default admin password
- `push.sh` - Container upload script

## Building

Just run the build script:

    $ ./build.sh

## Updating

To push a new build to the Container Registry, use the push script:

    $ ./push.sh

## Deploying

Use the Kubernetes scripts found [here](https://github.com/umg/sst-devops/tree/master/kubernetes/mongodb) to deploy the MongoDB image.