"""Join(denormalize) 3 tables. By Alexey Rudenko"""

from __future__ import absolute_import

#import logging

import apache_beam as beam
from apache_beam.io import ReadFromText
from apache_beam.io import WriteToText

import json

class KeyTrackID(beam.DoFn):
    def __init__(self):
        super(KeyTrackID, self).__init__()
    def process(self, element):
        text_line = element.strip()
        mapp = json.loads(text_line)
        return [(mapp["track_id"],text_line)]

class KeyUserID(beam.DoFn):
    def __init__(self):
        super(KeyUserID, self).__init__()
    def process(self, element):
        text_line = element.strip()
        mapp = json.loads(text_line)
        return [(mapp["user_id"],text_line)]

def run(argv=None):
    """Main entry point; defines and runs the wordcount pipeline."""
    p = beam.Pipeline()
    
    streams = p | 'readstreams' >> ReadFromText("gs://source-directory/streams.gz")
    streams2 = (streams | 'streamskeyby' >> (beam.ParDo(KeyTrackID()).with_output_types(unicode)))
    tracks =  p | 'readtracks' >> ReadFromText("gs://source-directory/tracks.gz") 
    tracks2 = (tracks | 'trackskeyby' >> (beam.ParDo(KeyTrackID()).with_output_types(unicode)))
    users =   p | 'readusers' >> ReadFromText("gs://source-directory/users.gz") 
    users2 = (users | 'userskeyby' >> (beam.ParDo(KeyUserID()).with_output_types(unicode)))
      
    set12 = (
        {'streams': streams2, 'tracks': tracks2}
        | 'CoGroupByTrackID' >> beam.CoGroupByKey())
  
    def compute_set12((key, sets)):
        streams = sets['streams']
        # We have an iterable for one element that we want extracted.
        [tracks] = sets['tracks']
        tracks_jsn = json.loads(tracks)
        isrc = tracks_jsn["isrc"]
        album_code = tracks_jsn["album_code"]
        for line in streams:
            streams_jsn = json.loads(line)
            key=streams_jsn["user_id"]
            streams_jsn["isrc"]=isrc
            streams_jsn["album_code"]=album_code
            yield key, str(streams_jsn)

    set_key_12 = (
        set12
        | 'get_set_12' >> beam.FlatMap(compute_set12))
  
    set123 = (
        {'streamstracks': set_key_12, 'users': users2}
        | 'CoGroupByUserID' >> beam.CoGroupByKey())
  
    def compute_set123((key, sets)):
        streamstracks = sets['streamstracks']
        # We have an iterable for one element that we want extracted.
        [user] = sets['users']
        users_jsn = json.loads(user)
    
        for line in streamstracks:
            new_line = line.replace("u'","'").replace("'",'"').replace("\\","")
            streamstracks_jsn = json.loads(new_line)
            key2="product"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="country"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="region"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="zip_code"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="access"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="gender"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="partner"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="referral"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="type"
            streamstracks_jsn[key2]=users_jsn[key2]
            key2="birth_year"
        streamstracks_jsn[key2]=users_jsn[key2]
        yield str(streamstracks_jsn).replace("u'","'").replace("'",'"')

    set_key_123 = (
        set123
        | 'get_set_123' >> beam.FlatMap(compute_set123))
    #line2 | 'write' >> WriteToText("gs://source-directory/proba.txt")
    set_key_123 | 'writestreams' >> WriteToText("gs://source-directory/streams_denorm_python.json")
    result = p.run()
    result.wait_until_finish()
  
if __name__ == '__main__':
    #logging.getLogger().setLevel(logging.INFO)
    run()
