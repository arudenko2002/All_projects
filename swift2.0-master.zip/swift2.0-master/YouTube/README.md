**YouTube Channel Benchmarks** project’s main goal is tracking promising and trendsetting 
YouTube channels and surfacing over-performing videos. Outperforming videos are those that 
have 2.x times more views than the baseline for the channel. 


**Proposed tables structure**

youtube_daily_history table
|--------------------------|
channel_id                   
channel_title                	
video_id                     
video_published_at           	
video_title                  
view_count                   	
comment_count                	
dislike_count                	
like_count                   	
duration                     	
licensed_content             	
video_tags                   	
video_img                    
category_id                  
channel_video_count          	
channel_view_count           	
channel_comment_count        	
channel_subscriber_count     	
channel_hidden_subscriber_count	
channel_image                
channel_creation_date        	
load_datetime                


youtube_baseline table
|--------------------------|
channel_id
channel_title
days_out
baseline_views
load_datetime


youtube_overperforming_videos table
|--------------------------|
channel_id
channel_title
video_id
video_title
days_out
actual_views
baseline_views
times_over_baseline
load_datetime
