from apiclient.discovery import build
import datetime
import csv
# from utils import get_channel_names
from utils import get_forUsernames_from_bq
from utils import channels_list_for_username
from utils import get_channel_info_values
from utils import get_video_id_list
from utils import chunk_string
from utils import videos_list_by_id
from utils import get_video_values

# Constants
STORAGE_PATH = '/Users/kovaleo/Documents/DS/YouTube_Channels/'
YOUTUBE_API_KEY = 'AIzaSyBjjyNm-6vzRCDxLZAasYWy4K4-05ykdK4'
MAX_RESULT = 50

service_youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)
load_datetime = datetime.datetime.utcnow()
load_date = datetime.datetime.now().date()


# get list of YouTube usernames for which we'd like to collect data from BQ table
for_username_list = get_forUsernames_from_bq()

# get channel usernames we want to get data for from Google Spreadsheet
# for_username_list = get_channel_names()


# open a file where we want to store the data
file_name = STORAGE_PATH + str(load_date) + '.txt'
with open(file_name, 'wb') as csvfile:
    spamwriter = csv.writer(csvfile, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
    spamwriter.writerow(['channel_id', 'channel_title', 'video_id', 'video_published_at', 'video_title',
                         'view_count', 'comment_count', 'dislike_count', 'like_count', 'duration', 'licensed_content',
                         'video_tags', 'video_img', 'category_id', 'channel_video_count', 'channel_view_count',
                         'channel_comment_count', 'channel_subscriber_count', 'channel_hidden_subscriber_count',
                         'channel_image', 'channel_creation_date', 'load_datetime'
                         ])

    # collect data for each channel
    for for_username in for_username_list:

        # get channel info (id, stats, etc.)
        channel_info = channels_list_for_username(service_youtube,
                                                  part='snippet,contentDetails,statistics',
                                                  forUsername=for_username)

        channel_info_items = channel_info['items'][0]

        # get tuple with channel values
        channel_id, channel_uploads, channel_view_count, channel_comment_count, channel_video_count, \
        channel_subscriber_count, channel_hidden_subscriber_count, channel_image, channel_desc, \
        channel_creation_date = get_channel_info_values(channel_info_items)

        # get uploads (video ids)
        video_id_list = get_video_id_list(service_youtube, channel_uploads, maxResults=MAX_RESULT)

        # split list of all video ids into comma-separated list of length 50
        video_id_list_chunks = list(chunk_string(video_id_list, MAX_RESULT))
        for video_id_list_chunk in video_id_list_chunks:
            video_id_string = ",".join(video_id_list_chunk)

            # get video statistics
            video_info_by_id = videos_list_by_id(service_youtube,
                                                 part='snippet,contentDetails,statistics',
                                                 id=video_id_string)

            video_info_items = video_info_by_id['items']
            for i in range(0, len(video_info_items)):

                # Get tuple with video values
                video_id, video_title, view_count, comment_count, dislike_count, like_count, duration, \
                licensed_content, video_published_at, tag_list, video_img, category_id, channel_id, \
                channel_title, video_desc = get_video_values(video_info_items[i])

                # write the results into the file
                spamwriter = csv.writer(csvfile, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
                spamwriter.writerow([channel_id, channel_title, video_id, video_published_at, video_title,
                                     view_count, comment_count, dislike_count, like_count, duration, licensed_content,
                                     tag_list, video_img, category_id, channel_video_count, channel_view_count,
                                     channel_comment_count, channel_subscriber_count, channel_hidden_subscriber_count,
                                     channel_image, channel_creation_date, load_datetime])