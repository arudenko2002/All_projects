from utils_overperforming import read_file
from utils_overperforming import reject_outliers
from utils_overperforming import get_baseline_views
from utils_overperforming import get_median_views
from utils_overperforming import get_overperforming_videos
from utils_overperforming import impute_missing_baseline_values
from utils_overperforming import get_first_180_days_and_latest
import pprint

# Constants
FILE_PATH = '/Users/kovaleo/Documents/DS/YouTube_Channels/test_a_few_days.txt'

# Read file that contains data from all channels, ~ 30 days of history
data, max_load_datetime = read_file(FILE_PATH)

# for each channel, do the following
for channel_id in data:

    # keep days and views that were published no longer than 180 days ago; create a structure with latest day data
    views_under_180_days, days_under_180_days, latest_day_data, channel_title = get_first_180_days_and_latest(data,
                                                                                                   channel_id,
                                                                                                   max_load_datetime)

    # reject outliers that are over 3 standard deviation above or below average views for a channel
    days_out, views = reject_outliers(views_under_180_days, days_under_180_days)

    # calculate median views for each day a video was out
    days_out_med_views = get_median_views(days_out, views)

    # run lowess regression and find baseline views for each day out
    baseline_dict = get_baseline_views(days_out_med_views)

    # impute missing days and views, if day is missing, then baseline views are equal to previous available day views
    baseline_dict_no_na = impute_missing_baseline_values(baseline_dict)

    # get over-performing videos if their views m times over the baseline for the # of days a video is out
    overperforming = get_overperforming_videos(latest_day_data, baseline_dict_no_na)

    # print results (video got N of views which is n times over baseline after t days)
    if overperforming:
        pprint.pprint(overperforming)
