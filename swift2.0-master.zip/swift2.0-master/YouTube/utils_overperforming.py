import csv
import numpy as np
import datetime
import math
import statsmodels.api as sm
from collections import defaultdict


# Read file that contains data from all channels, ~ 30 days of history
def read_file(file_path):
    data = {}
    load_datetime_list = []
    with open(file_path, 'r') as f:

        for row in csv.reader(f.read().splitlines(), delimiter='\t'):
            row = list(row)
            if row[0] == 'channel_id':
                continue

            # key - channel_id, values - all data for that channel_id
            if row[0] in data:
                data[row[0]].append(row)
            else:
                data[row[0]] = [row]

            load_datetime = row[21]
            load_datetime_list.append(load_datetime)

        # find max load date to only keep latest day data later on
        max_load_datetime = max(load_datetime_list)

    return data, max_load_datetime


# keep days and views that were published no longer than 180 days ago; create a structure with latest day data
def get_first_180_days_and_latest(data, channel_id, max_load_datetime):

    view_count_list = []
    days_out_list = []
    latest_day_data = {}

    for video in data[channel_id]:

        load_datetime = video[21]
        video_published_at = video[3]
        channel_title = video[1]
        video_id = video[2]
        video_title = video[4]

        # number of days video was out
        days_out = (datetime.datetime.strptime(load_datetime, "%Y-%m-%d %H:%M:%S.%f") - \
                    datetime.datetime.strptime(video_published_at, "%Y-%m-%d %H:%M:%S")).days

        # skip data older than 180 days
        if days_out > 180:
            continue

        days_out = days_out
        view_count = int(video[5])

        view_count_list.append(view_count)
        days_out_list.append(days_out)

        # skip data to keep only latest date data
        if load_datetime != max_load_datetime:
            continue

        # latest day data: key - video_id, values - days_out, views, and video title
        if video_id in latest_day_data:
            latest_day_data[video_id].append([days_out, view_count, video_title])
        else:
            latest_day_data[video_id] = [[days_out, view_count, video_title]]

    return view_count_list, days_out_list, latest_day_data, channel_title


# reject outliers that are over 3 standard deviation above or below average views for a channel
def reject_outliers(views_list, days_list,  m = 3):

    views = np.asarray(views_list)
    days = np.asanyarray(days_list)
    indices = np.where(views[abs(views - np.mean(views)) < m * np.std(views)])
    days = list(days[indices])
    views = list(views[indices])

    return days, views


# calculate median views for each day a video was out
def get_median_views(days, views):
    days_out_views = defaultdict(list)

    zipped_days_views = zip(days, views)
    for tuple in zipped_days_views:
        day = tuple[0]
        views = tuple[1]
        days_out_views[day].append(views)

    days_out_med_views = {}
    for key, value in days_out_views.items():
        if key == 0:
            continue
        median_views = np.median(value)
        days_out_med_views[key] = median_views

    return days_out_med_views


# run lowess regression and find baseline views for each day out
def get_baseline_views(days_out_med_views):

    keys = np.fromiter(iter(days_out_med_views.keys()), dtype=int)
    vals = np.fromiter(iter(days_out_med_views.values()), dtype=float)

    # x - ln(days out), y - median views
    x = map(math.log, keys)
    y = vals

    model = sm.nonparametric.lowess
    w = model(y, x, frac=0.5)
    ys = w[:, 1]

    exp_x_ys = zip(keys, ys)
    baseline_dict = defaultdict(list)
    for tuple in exp_x_ys:
        day = tuple[0]
        baseline_views = tuple[1]
        baseline_dict[day].append(baseline_views)

    return baseline_dict


# impute missing days and views, if day is missing, then baseline views are equal to previous available day views
def impute_missing_baseline_values(baseline_dict):
    for x in range(1, 181):
        if x not in baseline_dict:
            baseline_dict[x] = baseline_dict[min(baseline_dict.keys(), key=lambda k: abs(k-x))]
    baseline_dict_no_na = baseline_dict

    return baseline_dict_no_na


# get over-performing videos if their views m times over the baseline for the # of days a video is out
def get_overperforming_videos(latest_day_data, baseline_dict, m=2):

    result = []
    for video_id in latest_day_data:
        for video_info in latest_day_data[video_id]:
            days_out = video_info[0]
            actual_views = video_info[1]
            video_title = video_info[2]

            if days_out == 0:
                continue

            baseline_views = baseline_dict[days_out][0]

            if actual_views >= m * baseline_views:
                times_over_baseline = round(actual_views / baseline_views, 2)
                result.append('%s got %s views which is %s times over baseline after %s days'
                              % (video_title, actual_views, times_over_baseline, days_out))

    return result
