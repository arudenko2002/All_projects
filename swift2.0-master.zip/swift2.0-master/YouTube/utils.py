# import gspread
# from oauth2client.service_account import ServiceAccountCredentials
from google.cloud import bigquery as bq
import datetime
import os


# from BQ, get list of YouTube usernames for which we'd like to collect data
def get_forUsernames_from_bq():

    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.path.join(os.path.dirname(__file__),
                                                                'umg_tools_service_account_key.json')

    query = 'SELECT forUsername ' \
            'FROM `umg-tools.discovar.youtube_channels` ' \
            'GROUP BY forUsername'

    channels = list(bq.Client().query_rows(query, timeout=30))

    for_username_list = [channel['forUsername'] for channel in channels]
    for_username_list = list(set(for_username_list))

    return for_username_list


# get channel info by channel name (channel title, channel statis, channel creation date, channel_id, uploads_id, etc.)
def channels_list_for_username(service, **kwargs):
    results = service.channels().list(**kwargs).execute()

    return results


# parse out values in channel info result (channel title, channel statistics, creation date, etc.)
def get_channel_info_values(channel_info_item):

    channel_id = channel_info_item['id']
    channel_uploads = channel_info_item['contentDetails']['relatedPlaylists']['uploads']
    channel_view_count = channel_info_item['statistics']['viewCount']
    channel_comment_count = channel_info_item['statistics']['commentCount']
    channel_video_count = channel_info_item['statistics']['videoCount']
    channel_subscriber_count = channel_info_item['statistics']['subscriberCount']
    channel_hidden_subscriber_count = channel_info_item['statistics']['hiddenSubscriberCount']
    channel_image = channel_info_item['snippet']['thumbnails']['default']['url']
    channel_desc = channel_info_item['snippet']['description'].encode('utf-8')
    channel_creation_date = datetime.datetime.strptime(channel_info_item['snippet']['publishedAt'][:-5], '%Y-%m-%dT%H:%M:%S')

    return channel_id, channel_uploads, channel_view_count, channel_comment_count, channel_video_count, \
           channel_subscriber_count, channel_hidden_subscriber_count, channel_image, channel_desc, \
           channel_creation_date


# get all uploaded videos (video id, title, published date, etc.)
def playlist_items_list_by_playlist_id(service, **kwargs):
    results = service.playlistItems().list(**kwargs).execute()

    return results


# create a list that contains all channel's video ids and print out video id and data published to the command line
def process_upload_resuslt(iter, video_id_list, uploads_result):
    video_id_items = uploads_result['items']
    for i in range(0, len(video_id_items)):
        iter += 1
        video_id = video_id_items[i]['contentDetails']['videoId']
        video_published_at = video_id_items[i]['contentDetails']['videoPublishedAt']
        video_id_list.append(video_id)
        print iter, ' videoId: ', video_id, ' video_published_at: ', video_published_at
    return iter, video_id_list


# make a call to get all video id's uploaded to the channel
def get_video_id_list(service_youtube, channel_uploads, maxResults):
    iter = 0
    video_id_list = []
    uploads_result = playlist_items_list_by_playlist_id(service_youtube,
                                                        part='contentDetails',
                                                        maxResults=maxResults,
                                                        playlistId=channel_uploads)

    iter, video_id_list = process_upload_resuslt(iter, video_id_list, uploads_result)

    while 'nextPageToken' in uploads_result:
        next_page_token = uploads_result['nextPageToken']

        uploads_result = playlist_items_list_by_playlist_id(service_youtube,
                                                            part='contentDetails',
                                                            maxResults=maxResults,
                                                            playlistId=channel_uploads,
                                                            pageToken=next_page_token)

        iter, video_id_list = process_upload_resuslt(iter, video_id_list, uploads_result)

    return video_id_list


# split list into chunks with max predetermined length
def chunk_string(string, length):
    return (string[0+i:length+i] for i in range(0, len(string), length))


# get video statistics by video id
def videos_list_by_id(service, **kwargs):
    results = service.videos().list(**kwargs).execute()

    return results


# parse out video info result (video statistics, duration, tags, etc.)
def get_video_values(video_info_item):
    video_id = video_info_item['id']
    video_title = video_info_item['snippet']['title'].encode('utf-8')
    view_count = video_info_item['statistics']['viewCount']
    comment_count = None
    if 'commentCount' in video_info_item['statistics']:
        comment_count = video_info_item['statistics']['commentCount']
    dislike_count = None
    if 'dislikeCount' in video_info_item['statistics']:
        dislike_count = video_info_item['statistics']['dislikeCount']
    like_count = None
    if 'likeCount' in video_info_item['statistics']:
        like_count = video_info_item['statistics']['likeCount']
    duration = None
    if 'duration' in video_info_item['contentDetails']:
        duration = video_info_item['contentDetails']['duration']
    licensed_content = ''
    if 'licensedContent' in video_info_item['contentDetails']:
        licensed_content = video_info_item['contentDetails']['licensedContent']
    video_published_at = datetime.datetime.strptime(video_info_item['snippet']['publishedAt'][:-5], '%Y-%m-%dT%H:%M:%S')
    # tags = ''
    tag_list = ''
    if 'tags' in video_info_item['snippet']:
        video_tags = video_info_item['snippet']['tags']
        if len(video_tags) > 0:
            # for tag in video_tags:
            tag_list = ",".join(video_tags).encode('utf-8').replace('\\n', 'n')

    video_img = video_info_item['snippet']['thumbnails']['default']['url']
    category_id = video_info_item['snippet']['categoryId']
    channel_id = video_info_item['snippet']['channelId']
    channel_title = video_info_item['snippet']['channelTitle'].encode('utf-8')
    video_desc = video_info_item['snippet']['description'].encode('utf-8')

    return video_id, video_title, view_count, comment_count, dislike_count, like_count, duration, \
           licensed_content, video_published_at, tag_list, video_img, category_id, channel_id, \
           channel_title, video_desc


# # from Google Sheets, get list of YouTube usernames for which we'd like to collect data
# def get_channel_names():
#     scope = ['https://spreadsheets.google.com/feeds']
#     credentials = ServiceAccountCredentials.from_json_keyfile_name(os.path.join(os.path.dirname(__file__),
#                                                                                 'umg_tools_service_account_key.json'), scope)
#     client = gspread.authorize(credentials)
#
#     sheet = client.open('YouTube_Channels').sheet1
#
#     channels = sheet.get_all_records()
#     for_username_list = [channel['forUsername'] for channel in channels]
#     channel_id_list = [channel['channelId'] for channel in channels]
#
#     # remove duplicates in the list of channel names if any
#     for_username_list = list(set(for_username_list))
#     channel_id_list = list(set(channel_id_list))
#
#     return channels, for_username_list, channel_id_list
