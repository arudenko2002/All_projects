--streams_total_rank and users_total_rank are commented out - FIGURE OUT HOW TO MAKE IT WORK

--$START_DATE = $REPORTDATE - 6 days
--$END_DATE = $REPORTDATE

select
  playlist_id
  , playlist_uri
  , report_date
  , territory
  , frame_start_timestamp
  , frame_end_timestamp
  , playlist_track_position
  , playlist_track_added_timestamp
  , playlist_track_ownership
  , canopus_id
  , canopus_artist_name
  , resource_id
  , resource_rollup_id
  , isrc
  , playlist_track_isrc
  , resource_title
  , resource_display_title
  , track_uri
  , playlist_artist_name
  , playlist_track_name
  , playlist_track_uri
  , streams_total
  , streams_free
  , streams_paid
  , streams_total_rank
  , users_total
  , users_free
  , users_paid
  , users_total_rank
  , skips_total
  , streams_position_predicted
from
(
  select
    reverse(substr(reverse(coalesce(pt.playlist_uri,a.source_uri)) , 0 , strpos(reverse(coalesce(pt.playlist_uri,a.source_uri)),':'))) as playlist_id
    , coalesce(pt.playlist_uri,a.source_uri) as playlist_uri
    , coalesce(pt.report_date,a.stream_date) as report_date
    , coalesce(a.user_country_name,'XX') as territory
    , date_add(@datePartition, interval -6 day) as frame_start_timestamp
    , @datePartition as frame_end_timestamp
    , pt.position as playlist_track_position
    , pt.added_at as playlist_track_added_timestamp
    , case when rollupp.resource_id is null then 'UNKNOWN' else 'UMG_SOURCE_TRACK' end as playlist_track_ownership
    , playlist_canopus.canopus_id
    , playlist_canopus.artist_name as canopus_artist_name
    , playlist_canopus.resource_id
    , playlist_canopus.resource_rollup_id
    , a.isrc
    , pt.isrc as playlist_track_isrc
    , playlist_canopus.title as resource_title
    , playlist_canopus.formatted_title as resource_display_title
    , a.partner_track_uri as track_uri
    , pt.artist_name as playlist_artist_name
    , pt.track_name as playlist_track_name
    , pt.track_uri as playlist_track_uri
    , max(pt.streams_position_actual) over (partition by pt.playlist_uri, pt.report_date, pt.position) as streams_total
    , sum(a.streams_free) over (partition by pt.playlist_uri, pt.report_date, pt.position) as streams_free
    , sum(a.streams_paid) over (partition by pt.playlist_uri, pt.report_date, pt.position) as streams_paid
    , min(a.streams_total_rank) over (partition by pt.playlist_uri, pt.report_date, pt.position) as streams_total_rank
    , sum(a.users_total) over (partition by pt.playlist_uri, pt.report_date, pt.position) as users_total
    , sum(a.users_free) over (partition by pt.playlist_uri, pt.report_date, pt.position) as users_free
    , sum(a.users_paid) over (partition by pt.playlist_uri, pt.report_date, pt.position) as users_paid
    , min(a.users_total_rank) over (partition by pt.playlist_uri, pt.report_date, pt.position) as users_total_rank
    , sum(a.skips_total) over (partition by pt.playlist_uri, pt.report_date, pt.position) as skips_total
    , pt.streams_position_predicted
    , coalesce(row_number() over (partition by pt.playlist_uri, pt.report_date, pt.position order by a.streams_total desc),1) as rn
    from
    (
      select
        pt.playlist_uri
        ,pt.report_date
        ,pt.isrc
        ,pt.position
        ,pt.added_at
        ,pt.artist_name
        ,pt.track_name
        ,pt.track_uri
        ,pp.streams_position_predicted
        ,pp.streams_position_actual
      from
        `umg-tools.metadata.spotify_playlist_tracks` pt
        left join `umg-user.Olga.aggregate_playlist_projection` pp
          on pp.playlist_uri = pt.playlist_uri
          and pp.report_date = pt.report_date
          and pp.position = pt.position
      where pt.report_date between date_add(@datePartition, interval -6 day) and date(@datePartition)
      and pt.playlist_uri <> ''
      and pt.playlist_uri in
      (
        select
          source_uri
        from
          `umg-user.Olga.aggregate_playlist_demographic`
        where

--        CHANGE TO _PARTITIONTIME
          stream_date between date_add(@datePartition, interval -6 day) and date(@datePartition)
          and user_country_name = 'XX'
        group by
          source_uri
        having
          sum(streams_total) >= 100
      )
    )
    pt


    left join `umg-data-science.canopus.resource_artist` playlist_canopus
      on playlist_canopus.isrc = pt.isrc
    left join `umg-data-science.canopus.resource_artist` rollupp
      on rollupp.resource_rollup_id = playlist_canopus.resource_rollup_id


    left join
    (
      (
      select *
--       GETTING RESOURSES EXCEEDED ERROR, NEEDS INVESTIGATION IF IT'S USED AND HOW TO REPLACE IT
      , rank() over (partition by user_country_name, stream_date order by streams_total desc) as streams_total_rank
      , rank() over (partition by user_country_name, stream_date order by users_total desc) as users_total_rank
      from
      (
      select
      source_uri
      , isrc
      , stream_date
      , user_country_name
      , partner_track_uri
      , concat(source_uri, partner_track_uri) as source_track_uri
      , streams_total as streams_total
      , streams_free as streams_free
      , streams_paid as streams_paid
      , users_total as users_total
      , users_free as users_free
      , users_paid as users_paid
      , skips_total as skips_total

      from `umg-user.Olga.aggregate_playlist_track_demographic` s
      where stream_date between date_add(@datePartition, interval -6 day) and date(@datePartition)
      and user_country_name = 'XX'
      and source_uri <> ''
      and source_uri in
      (
        select source_uri
        from `umg-user.Olga.aggregate_playlist_demographic`
        where stream_date between date_add(@datePartition, interval -6 day) and date(@datePartition)
        and user_country_name = 'XX'
        group by source_uri
        having sum(streams_total) >= 100
      )
      )
      where source_track_uri not in
      (
      (select source_track_uri
       from
        (
        select concat(source_uri, partner_track_uri) as source_track_uri, sum(streams_total) as streams
        from `umg-user.Olga.aggregate_playlist_track_demographic`
        where stream_date between date_add(@datePartition, interval -6 day) and date(@datePartition)
        and user_country_name = 'XX'
        group by source_track_uri)
        where streams = 1
      )
      )
      )
      ) a
      on pt.playlist_uri = a.source_uri
      and pt.report_date = a.stream_date
      and rollupp.isrc = a.isrc
  where
    (
      a.isrc is not null
      or playlist_canopus.isrc is null
      or (a.isrc is null and playlist_canopus.isrc = rollupp.isrc)
    )
) setup
where rn = 1