select
  s.source_uri
, s.partner_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name
, count(1) as streams_total
, sum(case when s.partner_access_type in ('premium', 'basic-desktop') then 1 else 0 end) as streams_paid
, sum(case when s.partner_access_type in ('deleted', 'free', 'basic') then 1 else 0 end) as streams_free
, count(distinct s.user_id) as users_total
, count(distinct case when s.partner_access_type in ('premium', 'basic-desktop') then s.user_id end) as users_paid
, count(distinct case when s.partner_access_type in ('deleted', 'free', 'basic') then s.user_id end) as users_free
, sum(case when u.cluster = 1 then 1 else 0 end) as cluster_01_streams
, sum(case when u.cluster = 2 then 1 else 0 end) as cluster_02_streams
, sum(case when u.cluster = 3 then 1 else 0 end) as cluster_03_streams
, sum(case when u.cluster = 4 then 1 else 0 end) as cluster_04_streams
, sum(case when u.cluster = 5 then 1 else 0 end) as cluster_05_streams
, sum(case when u.cluster = 6 then 1 else 0 end) as cluster_06_streams
, sum(case when u.cluster = 7 then 1 else 0 end) as cluster_07_streams
, sum(case when u.cluster = 8 then 1 else 0 end) as cluster_08_streams
, sum(case when u.cluster = 9 then 1 else 0 end) as cluster_09_streams
, sum(case when u.cluster = 10 then 1 else 0 end) as cluster_10_streams
, sum(case when u.cluster = 11 then 1 else 0 end) as cluster_11_streams
, sum(case when u.cluster = 12 then 1 else 0 end) as cluster_12_streams
, sum(case when u.cluster = 13 then 1 else 0 end) as cluster_13_streams
, sum(case when u.cluster is null then 1 else 0 end) as cluster_unknown_streams
, sum(case when s.user_gender = 'male' then 1 else 0 end) as gender_male_streams
, sum(case when s.user_gender = 'female' then 1 else 0 end) as gender_female_streams
, sum(case when s.user_gender = '' then 1 else 0 end) as gender_unknown_streams
, sum(case when s.user_age_group = '0-12' then 1 else 0 end) as age_group_0_to_12_streams
, sum(case when s.user_age_group = '13-17' then 1 else 0 end) as  age_group_13_to_17_streams
, sum(case when s.user_age_group = '18-24' then 1 else 0 end) as  age_group_18_to_24_streams
, sum(case when s.user_age_group = '25-34' then 1 else 0 end) as  age_group_25_to_34_streams
, sum(case when s.user_age_group = '35-44' then 1 else 0 end) as  age_group_35_to_44_streams
, sum(case when s.user_age_group = '45-54' then 1 else 0 end) as  age_group_45_to_54_streams
, sum(case when s.user_age_group = '55-64' then 1 else 0 end) as  age_group_55_to_64_streams
, sum(case when s.user_age_group = '65+' then 1 else 0 end) as  age_group_65_plus_streams
, sum(case when s.user_age_group = 'Unknown' then 1 else 0 end) as  age_group_unknown_streams
, sum(case when s.device_type = 'desktop' then 1 else 0 end) as device_type_desktop_streams
, sum(case when s.device_type = 'mobile' then 1 else 0 end) as device_type_mobile_streams
, sum(case when s.device_type = 'tablet' then 1 else 0 end) as device_type_tablet_streams
, sum(case when s.device_type not in ('desktop','mobile','tablet') then 1 else 0 end) as device_type_other_streams
, sum(case when s.stream_duration/i.modal_stream_length < 0.95 then 1 else 0 end) as skips_total
, avg(case when s.stream_duration/i.modal_stream_length < 0.95 then s.stream_duration end) as avg_skip_stream_length
, avg(s.stream_duration) as avg_all_stream_length
, max(i.modal_stream_length) as track_length
from

        (select *
        from
        (select
          source_uri
        , partner_track_uri
        , upc
        , isrc
        , stream_date
        , user_country_name
        , concat(source_uri, partner_track_uri) as source_track_uri
        , stream_duration
        , partner_access_type
        , user_id
        , user_gender
        , user_age_group
        , device_type
        from `umg-partner.spotify.streams`
        where _partitiontime = timestamp(@datePartition)
        and stream_source = 'others_playlist'
        and source_uri <> ''
        and source_uri in
            (
                select source_uri
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_uri
                having count(*) >= 100
            )
        )
        where source_track_uri not in
        (       select source_track_uri
                from
                (select concat(source_uri, partner_track_uri) as source_track_uri, count(1) as count
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_track_uri)
                where count = 1
        )) as s
left join `umg-user.Olga.clusters13_spotify` u
        on s.user_id = u.user_id
left join `umg-user.Olga.isrc_upc_length` i
        on i.isrc = s.isrc
        and i.upc = s.upc

group by
  s.source_uri
, s.partner_track_uri
, s.source_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name

union all

select
  s.source_uri
, s.partner_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name
, count(1) as streams_total
, sum(case when s.partner_access_type in ('premium', 'basic-desktop') then 1 else 0 end) as streams_paid
, sum(case when s.partner_access_type in ('deleted', 'free', 'basic') then 1 else 0 end) as streams_free
, count(distinct s.user_id) as users_total
, count(distinct case when s.partner_access_type in ('premium', 'basic-desktop') then s.user_id end) as users_paid
, count(distinct case when s.partner_access_type in ('deleted', 'free', 'basic') then s.user_id end) as users_free
, sum(case when u.cluster = 1 then 1 else 0 end) as cluster_01_streams
, sum(case when u.cluster = 2 then 1 else 0 end) as cluster_02_streams
, sum(case when u.cluster = 3 then 1 else 0 end) as cluster_03_streams
, sum(case when u.cluster = 4 then 1 else 0 end) as cluster_04_streams
, sum(case when u.cluster = 5 then 1 else 0 end) as cluster_05_streams
, sum(case when u.cluster = 6 then 1 else 0 end) as cluster_06_streams
, sum(case when u.cluster = 7 then 1 else 0 end) as cluster_07_streams
, sum(case when u.cluster = 8 then 1 else 0 end) as cluster_08_streams
, sum(case when u.cluster = 9 then 1 else 0 end) as cluster_09_streams
, sum(case when u.cluster = 10 then 1 else 0 end) as cluster_10_streams
, sum(case when u.cluster = 11 then 1 else 0 end) as cluster_11_streams
, sum(case when u.cluster = 12 then 1 else 0 end) as cluster_12_streams
, sum(case when u.cluster = 13 then 1 else 0 end) as cluster_13_streams
, sum(case when u.cluster is null then 1 else 0 end) as cluster_unknown_streams
, sum(case when s.user_gender = 'male' then 1 else 0 end) as gender_male_streams
, sum(case when s.user_gender = 'female' then 1 else 0 end) as gender_female_streams
, sum(case when s.user_gender = '' then 1 else 0 end) as gender_unknown_streams
, sum(case when s.user_age_group = '0-12' then 1 else 0 end) as age_group_0_to_12_streams
, sum(case when s.user_age_group = '13-17' then 1 else 0 end) as  age_group_13_to_17_streams
, sum(case when s.user_age_group = '18-24' then 1 else 0 end) as  age_group_18_to_24_streams
, sum(case when s.user_age_group = '25-34' then 1 else 0 end) as  age_group_25_to_34_streams
, sum(case when s.user_age_group = '35-44' then 1 else 0 end) as  age_group_35_to_44_streams
, sum(case when s.user_age_group = '45-54' then 1 else 0 end) as  age_group_45_to_54_streams
, sum(case when s.user_age_group = '55-64' then 1 else 0 end) as  age_group_55_to_64_streams
, sum(case when s.user_age_group = '65+' then 1 else 0 end) as  age_group_65_plus_streams
, sum(case when s.user_age_group = 'Unknown' then 1 else 0 end) as  age_group_unknown_streams
, sum(case when s.device_type = 'desktop' then 1 else 0 end) as device_type_desktop_streams
, sum(case when s.device_type = 'mobile' then 1 else 0 end) as device_type_mobile_streams
, sum(case when s.device_type = 'tablet' then 1 else 0 end) as device_type_tablet_streams
, sum(case when s.device_type not in ('desktop','mobile','tablet') then 1 else 0 end) as device_type_other_streams
, sum(case when s.stream_duration/i.modal_stream_length < 0.95 then 1 else 0 end) as skips_total
, avg(case when s.stream_duration/i.modal_stream_length < 0.95 then s.stream_duration end) as avg_skip_stream_length
, avg(s.stream_duration) as avg_all_stream_length
, max(i.modal_stream_length) as track_length
from

        (select *
        from
        (select
          source_uri
        , partner_track_uri
        , upc
        , isrc
        , stream_date
        , 'XX' as user_country_name
        , concat(source_uri, partner_track_uri) as source_track_uri
        , stream_duration
        , partner_access_type
        , user_id
        , user_gender
        , user_age_group
        , device_type
        from `umg-partner.spotify.streams`
        where _partitiontime = timestamp(@datePartition)
        and stream_source = 'others_playlist'
        and source_uri <> ''
        and source_uri in
            (
                select source_uri
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_uri
                having count(*) >= 100
            )
        )
        where source_track_uri not in
        (       select source_track_uri
                from
                (select concat(source_uri, partner_track_uri) as source_track_uri, count(1) as count
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_track_uri)
                where count = 1
                group by source_track_uri
        )) as s
left join `umg-user.Olga.clusters13_spotify` u
        on s.user_id = u.user_id
left join `umg-user.Olga.isrc_upc_length` i
        on i.isrc = s.isrc
        and i.upc = s.upc

group by
  s.source_uri
, s.partner_track_uri
, s.source_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name

union all

select
  s.source_uri
, s.partner_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name
, count(1) as streams_total
, sum(case when s.partner_access_type in ('premium', 'basic-desktop') then 1 else 0 end) as streams_paid
, sum(case when s.partner_access_type in ('deleted', 'free', 'basic') then 1 else 0 end) as streams_free
, count(distinct s.user_id) as users_total
, count(distinct case when s.partner_access_type in ('premium', 'basic-desktop') then s.user_id end) as users_paid
, count(distinct case when s.partner_access_type in ('deleted', 'free', 'basic') then s.user_id end) as users_free
, sum(case when u.cluster = 1 then 1 else 0 end) as cluster_01_streams
, sum(case when u.cluster = 2 then 1 else 0 end) as cluster_02_streams
, sum(case when u.cluster = 3 then 1 else 0 end) as cluster_03_streams
, sum(case when u.cluster = 4 then 1 else 0 end) as cluster_04_streams
, sum(case when u.cluster = 5 then 1 else 0 end) as cluster_05_streams
, sum(case when u.cluster = 6 then 1 else 0 end) as cluster_06_streams
, sum(case when u.cluster = 7 then 1 else 0 end) as cluster_07_streams
, sum(case when u.cluster = 8 then 1 else 0 end) as cluster_08_streams
, sum(case when u.cluster = 9 then 1 else 0 end) as cluster_09_streams
, sum(case when u.cluster = 10 then 1 else 0 end) as cluster_10_streams
, sum(case when u.cluster = 11 then 1 else 0 end) as cluster_11_streams
, sum(case when u.cluster = 12 then 1 else 0 end) as cluster_12_streams
, sum(case when u.cluster = 13 then 1 else 0 end) as cluster_13_streams
, sum(case when u.cluster is null then 1 else 0 end) as cluster_unknown_streams
, sum(case when s.user_gender = 'male' then 1 else 0 end) as gender_male_streams
, sum(case when s.user_gender = 'female' then 1 else 0 end) as gender_female_streams
, sum(case when s.user_gender = '' then 1 else 0 end) as gender_unknown_streams
, sum(case when s.user_age_group = '0-12' then 1 else 0 end) as age_group_0_to_12_streams
, sum(case when s.user_age_group = '13-17' then 1 else 0 end) as  age_group_13_to_17_streams
, sum(case when s.user_age_group = '18-24' then 1 else 0 end) as  age_group_18_to_24_streams
, sum(case when s.user_age_group = '25-34' then 1 else 0 end) as  age_group_25_to_34_streams
, sum(case when s.user_age_group = '35-44' then 1 else 0 end) as  age_group_35_to_44_streams
, sum(case when s.user_age_group = '45-54' then 1 else 0 end) as  age_group_45_to_54_streams
, sum(case when s.user_age_group = '55-64' then 1 else 0 end) as  age_group_55_to_64_streams
, sum(case when s.user_age_group = '65+' then 1 else 0 end) as  age_group_65_plus_streams
, sum(case when s.user_age_group = 'Unknown' then 1 else 0 end) as  age_group_unknown_streams
, sum(case when s.device_type = 'desktop' then 1 else 0 end) as device_type_desktop_streams
, sum(case when s.device_type = 'mobile' then 1 else 0 end) as device_type_mobile_streams
, sum(case when s.device_type = 'tablet' then 1 else 0 end) as device_type_tablet_streams
, sum(case when s.device_type not in ('desktop','mobile','tablet') then 1 else 0 end) as device_type_other_streams
, sum(case when s.stream_duration/i.modal_stream_length < 0.95 then 1 else 0 end) as skips_total
, avg(case when s.stream_duration/i.modal_stream_length < 0.95 then s.stream_duration end) as avg_skip_stream_length
, avg(s.stream_duration) as avg_all_stream_length
, max(i.modal_stream_length) as track_length
from

        (select *
        from
        (select
          source_uri
        , partner_track_uri
        , upc
        , isrc
        , stream_date
        , 'Ex-U.S.' as user_country_name
        , concat(source_uri, partner_track_uri) as source_track_uri
        , stream_duration
        , partner_access_type
        , user_id
        , user_gender
        , user_age_group
        , device_type
        from `umg-partner.spotify.streams`
        where _partitiontime = timestamp(@datePartition)
        and stream_source = 'others_playlist'
        and source_uri <> ''
        and user_country_name != 'United States'
        and source_uri in
            (
                select source_uri
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_uri
                having count(*) >= 100
            )
        )
        where source_track_uri not in
        (       select source_track_uri
                from
                (select concat(source_uri, partner_track_uri) as source_track_uri, count(1) as count
                from `umg-partner.spotify.streams`
                where _partitiontime = timestamp(@datePartition)
                group by source_track_uri)
                where count = 1
                group by source_track_uri
        )
) as s
left join `umg-user.Olga.clusters13_spotify` u
        on s.user_id = u.user_id
left join `umg-user.Olga.isrc_upc_length` i
        on i.isrc = s.isrc
        and i.upc = s.upc

group by
  s.source_uri
, s.partner_track_uri
, s.upc
, s.isrc
, s.stream_date
, s.user_country_name