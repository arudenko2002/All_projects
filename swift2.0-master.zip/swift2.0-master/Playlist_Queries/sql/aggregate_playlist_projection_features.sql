with predicted_midpoint as
(
	select
		playlist_uri
		,report_date
		,min(position) as position
	from
		`umg-user.Olga.aggregate_playlist_projection`
	where
		percent_predicted >= 0.5

--		CHANGE TO _PARTITIONTIME
		and report_date = timestamp(@datePartition)
	group by
		playlist_uri
		,report_date
)
, actual_midpoint as
(
	select
		playlist_uri
		,report_date
		,min(position) as position
	from
		`umg-user.Olga.aggregate_playlist_projection`
	where
		percent_actual >= 0.5

--		CHANGE TO PARTITIONTIME
		and report_date = timestamp(@datePartition)
	group by
		playlist_uri
		,report_date

)
, nearest_actual_position as
(
	select
		x.playlist_uri
		,x.report_date
		,max(x.position) as position
	from
		`umg-user.Olga.aggregate_playlist_projection` x
		join predicted_midpoint y
			on x.playlist_uri = y.playlist_uri
			and x.report_date = y.report_date
	where
		x.streams_position_actual is not null
		and x.position < y.position

--		CHANGE TO PARTITIONTIME
		and x.report_date = timestamp(@datePartition)
	group by
		x.playlist_uri
		,x.report_date
)
,nearest_actuals as
(
	select
		s.playlist_uri
		,s.report_date
		,s.position
		,s.streams_position_actual
		,s.streams_total_actual
		,s.streams_cumulative_actual
		,s.percent_actual
	from
		`umg-user.Olga.aggregate_playlist_projection` s
		join nearest_actual_position p
			on p.playlist_uri = s.playlist_uri
			and p.report_date = s.report_date
			and p.position = s.position

--  CHANGE TO PARTITIONTIME
	where s.report_date = timestamp(@datePartition)
)
,predicted_stats as
(
	select
		s.playlist_uri
		,s.report_date
		,s.slope
		,s.intercept
		,p.position as midpoint_predicted
		,case when s.streams_position_actual is null then pa.position else s.position end as nearest_umg_position
		,s.streams_position_predicted
		,coalesce(s.streams_position_actual,pa.streams_position_actual) as streams_position_actual
		,s.streams_total_predicted
		,coalesce(s.streams_total_actual,pa.streams_total_actual) as streams_total_actual
		,s.streams_cumulative_predicted
		,coalesce(s.streams_cumulative_actual,pa.streams_cumulative_actual) as streams_cumulative_actual
		,s.percent_predicted
		,coalesce(s.percent_actual,pa.percent_actual) as percent_actual
	from
		`umg-user.Olga.aggregate_playlist_projection` s
		join predicted_midpoint p
			on s.playlist_uri = p.playlist_uri
			and s.report_date = p.report_date
			and s.position = p.position
		left join nearest_actuals pa
			on pa.playlist_uri = s.playlist_uri
			and pa.report_date = s.report_date

--	CHANGE TO PARTITIONTIME
	where s.report_date = timestamp(@datePartition)
)
,actual_stats as
(
	select
		s.playlist_uri
		,s.report_date
		,p.position as midpoint_actual
		,s.streams_position_predicted
		,s.streams_position_actual
		,s.streams_total_predicted
		,s.streams_total_actual
		,s.streams_cumulative_predicted
		,s.streams_cumulative_actual
		,s.percent_predicted
		,s.percent_actual
	from
		`umg-user.Olga.aggregate_playlist_projection` s
		join actual_midpoint p
			on s.playlist_uri = p.playlist_uri
			and s.report_date = p.report_date
			and s.position = p.position

--	CHANGE TO PARTITIONTIME
	where s.report_date = timestamp(@datePartition)
)
select
	p.playlist_uri
	,reverse(substr(reverse(p.playlist_uri) , 0 , strpos(reverse(p.playlist_uri),':')))  as playlist_id
	,p.report_date
	,p.slope
	,p.intercept
	,p.streams_total_predicted as streams_total_predicted
	,a.streams_total_actual as streams_total_actual

	,p.midpoint_predicted as pred_midpoint
	,p.nearest_umg_position as pred_midpoint_nearest_umg_position
	,p.streams_position_predicted as pred_midpoint_streams_predicted
	,p.streams_position_actual as pred_midpoint_streams_actual
	,p.streams_cumulative_predicted as pred_midpoint_streams_cumulative_predicted
	,p.streams_cumulative_actual as pred_midpoint_streams_cumulative_actual
	,p.percent_predicted as pred_midpoint_percent_predicted
	,p.percent_actual as pred_midpoint_percent_actual

	,a.midpoint_actual as act_midpoint
	,a.streams_position_predicted as act_midpoint_streams_predicted
	,a.streams_position_actual as act_midpoint_streams_actual
	,a.streams_cumulative_predicted as act_midpoint_streams_cumulative_predicted
	,a.streams_cumulative_actual as act_midpoint_streams_cumulative_actual
	,a.percent_predicted as act_midpoint_percent_predicted
	,a.percent_actual as act_midpoint_percent_actual
from
	predicted_stats p
	join actual_stats a
		on p.playlist_uri = a.playlist_uri
		and p.report_date = a.report_date

--	PROBABLY IS NOT NEEDED ANYMORE
where
	p.report_date = timestamp(@datePartition)
	and a.report_date = timestamp(@datePartition)