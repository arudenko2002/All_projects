/* Curve fitting steps
Create array of Known Streams (Y0)
Calculate Mean of Known Streams (Ybar0)
Drop cases where Streams < 10% of Ybar0  from Y0 - Creating Array Y
Recalc Mean of Streams (Ybar)
Create Array of LN(Positions) of Known Streams (X)
Calc Mean of LN(Positions) (Xbar)
For each array member calculate the following values and store in arrays
XY=(Y-Ybar)*(X-Xbar)
XX=(X-Xbar)*(X-Xbar)
Calculate Sum(XY) & Sum(XX)
Slope = Sum(XY)/Sum(XX)
Intercept = Ybar - (Slope * Xbar)
For array member calculate the following values
Pred = (X * Slope) + Intercept
*/

with playlist_streams_setup as
(
-- 	Create array of Known Streams (Y0)
  select
    t.playlist_uri
    ,t.isrc
    ,t.report_date
    ,min(t.position) as position
    ,min(t.added_at) as added
    ,sum(s.streams_total) as streams_total
    ,rank() over (partition by t.playlist_uri,t.report_date order by sum(s.streams_total) desc) as streams_total_rank
    ,row_number() over (partition by t.playlist_uri,t.report_date,t.isrc order by t.position) as isrc_row_number
    ,count(1) over (partition by t.playlist_uri,t.report_date,t.isrc) as isrc_count
  from
    `umg-tools.metadata.spotify_playlist_tracks` t
    join `umg-data-science.canopus.resource_artist` rat
    	on rat.isrc = t.isrc
    join `umg-data-science.canopus.resource_artist` ras
    	on ras.resource_rollup_id = rat.resource_rollup_id
    join `umg-user.Olga.aggregate_playlist_track_demographic` s
    	on t.playlist_uri = s.source_uri
    	and t.report_date = s.stream_date
    	and ras.isrc = s.isrc --Match to all other versions of the track
    left join `umg-tools.metadata.spotify_playlist_tracks` tt
      on tt.playlist_uri = t.playlist_uri
      and tt.report_date = t.report_date
      and tt.position <> t.position
      and tt.isrc = s.isrc --Make sure the "other" isrc isn't in another position
  where
    t.report_date = timestamp(@datePartition)
    and coalesce(t.position,0) > 0

--    CHANGE TO _PARTITONTIME ONCE aggregate_playlist_track_demographic IS PARTITIONED
    and s.stream_date = timestamp(@datePartition)
    and s.user_country_name = 'XX'
    and (tt.position is null or tt.isrc = t.isrc)
  group by
    t.playlist_uri
    ,t.isrc
    ,t.report_date
    ,t.position
)
, playlist_streams as
(
  select
    playlist_uri
    ,isrc
    ,report_date
    ,position
    ,added
    --,streams_total
    ,((streams_total*1.0) / (isrc_count*1.0)) as streams_total --Split the streams across all instances of duplicates to smooth the shape
    ,streams_total_rank
  from playlist_streams_setup
  --where isrc_row_number = 1 --only keep the first instance of a duplicate (alternative to splitting the streams)
)
,playlist_best_position as --Get the head of the playlist (might not be the highest placed track)
(
    select
        playlist_uri
        ,report_date
        ,position
        ,rank() over (partition by playlist_uri,report_date order by position*streams_total_rank) as pos_rank
    from
        playlist_streams
)
,playlist_mean as
(
    --Calculate Mean of Known Streams (Ybar0)
   select
        ps.playlist_uri
        ,ps.report_date
        ,avg(ps.streams_total) as avg_streams
        ,stddev(ps.streams_total) as stddev_streams
        ,count(*) as sample_size
        ,(stddev(ps.streams_total) / (sqrt(count(*)))) as standard_error
        ,coalesce(min(case when bp.pos_rank = 1 then bp.position end),1) as highest_streaming_position
    from
        playlist_streams ps
        left join playlist_best_position bp
            on bp.playlist_uri = ps.playlist_uri
            and bp.report_date = ps.report_date
    group by
        ps.playlist_uri
        ,ps.report_date
    having count(1) > 0
)
,playlist_streams_filtered as
(
	--Drop cases where Streams < 10% of Ybar0  from Y0 - Creating Array Y
	--Create Array of LN(Positions) of Known Streams (X)
	select
		pt.playlist_uri
    ,pt.isrc
    ,pt.report_date
    ,pt.position
    ,ln(pt.position) as X
    ,pt.streams_total as Y
	from
		playlist_streams pt
		join playlist_mean pm
			on pt.playlist_uri = pm.playlist_uri
			and pt.report_date = pm.report_date
	where
		--pt.streams_total > pm.avg_streams * 0.1
		--Use the standard error instead to exclude low outliers
		pt.streams_total > (pm.avg_streams - (pm.standard_error*3))
		--Rebase to start with the highest streaming position
		and pt.position >= pm.highest_streaming_position
)
,cumulative_streams as
(
	select
		s.playlist_uri
		,s.report_date
		,s.position
    ,s.isrc
		,s.streams_total as Y --,s.Y
		,sum(s.streams_total) over (partition by s.playlist_uri,s.report_date order by s.position rows unbounded preceding) as streams_cumulative
		,sum(s.streams_total) over (partition by s.playlist_uri,s.report_date order by s.position rows between unbounded preceding and unbounded following) as streams_total
	from
		playlist_streams s
)
,playlist_stats as
(
	--Recalc Mean of Streams (Ybar)
	--Calc Mean of LN(Positions) (Xbar)
	select
		playlist_uri
		,report_date
		,avg(Y) as Ybar
		,avg(X) as Xbar
		,count(1) as sample_size
		,stddev(Y) as sttdev_Y
	from
		playlist_streams_filtered
	group by
		playlist_uri
		,report_date
)
,streaming_stats as
(
	-- For each array member calculate the following values and store in arrays
	-- XY=(Y-Ybar)*(X-Xbar)
	-- XX=(X-Xbar)*(X-Xbar)
	-- Calculate Sum(XY) & Sum(XX)
	select
		s.playlist_uri
		,s.report_date
		,sum((Y-Ybar)*(X-Xbar)) as SumXY
		,sum((X-Xbar)*(X-Xbar)) as SumXX
	from
		playlist_streams_filtered s
		join playlist_stats p
			on s.playlist_uri = p.playlist_uri
			and s.report_date = p.report_date
	group by
		s.playlist_uri
		,s.report_date
)
,playlist_line_function as
(
	-- Slope = Sum(XY)/Sum(XX)
	-- Intercept = Ybar - (Slope * Xbar)
	select
		p.playlist_uri
		,p.report_date
		,case when s.SumXX = 0 then 0 else s.SumXY / s.SumXX end as slope
		,case when s.SumXX = 0 then 0 else (p.Ybar - ((s.SumXY / s.SumXX) * Xbar)) end as intercept
	from
		playlist_stats p
		join streaming_stats s
			on p.playlist_uri = s.playlist_uri
			and p.report_date = s.report_date
)
,playlist_predictions as
(
	-- For array member calculate the following values
	-- Pred = (X * Slope) + Intercept
	select
		pt.playlist_uri
		,pt.report_date
		,pt.position
    ,pt.isrc
		,f.slope
		,f.intercept
		,((ln(pt.position) * f.slope) + f.intercept) as streams_daily_estimate
	from
		`umg-tools.metadata.spotify_playlist_tracks` pt
		join playlist_line_function f
			on pt.playlist_uri = f.playlist_uri
			and pt.report_date = f.report_date
)
,cumulative_predictions as
(
	select
		s.playlist_uri
		,s.report_date
		,s.position
    ,s.isrc
		,s.slope
		,s.intercept
		,s.streams_daily_estimate as Y
		,sum(s.streams_daily_estimate) over (partition by s.playlist_uri,s.report_date order by s.position rows unbounded preceding) as streams_cumulative
		,sum(s.streams_daily_estimate) over (partition by s.playlist_uri,s.report_date order by s.position rows between unbounded preceding and unbounded following) as streams_total
	from
		playlist_predictions s
)

select
	p.playlist_uri
	,p.report_date
	,p.position
	,p.slope
	,p.intercept
	,p.Y as streams_position_predicted
  --,sum(p.Y) over (partition by p.playlist_uri,p.report_date,p.isrc) as isrc_predicted
	,p.streams_cumulative as streams_cumulative_predicted
	,p.streams_total as streams_total_predicted
	,case when p.streams_total = 0 then 0.0 else ((p.streams_cumulative*1.0) / (p.streams_total*1.0)) end as percent_predicted
	--,s.Y as streams_position_actual
  --Try to apportion streams across duplicate ISRCs based on predicted streams in that position
  ,round(case when sum(p.Y) over (partition by p.playlist_uri,p.report_date,p.isrc) = 0 then 0.0 else ((p.Y*1.0) / (sum(p.Y) over (partition by p.playlist_uri,p.report_date,p.isrc)*1.0) * (sum(s.Y) over (partition by p.playlist_uri,p.report_date,p.isrc)*1.0)) end) as streams_position_actual
  --,sum(s.Y) over (partition by p.playlist_uri,p.report_date,p.isrc) as isrc_actual
	,round(s.streams_cumulative) as streams_cumulative_actual
	,round(s.streams_total) as streams_total_actual
	,case when s.streams_total = 0 then 0.0 else ((s.streams_cumulative*1.0) / (s.streams_total*1.0)) end as percent_actual
from
	cumulative_predictions p
	left join cumulative_streams s
		on s.playlist_uri = p.playlist_uri
		and s.report_date = p.report_date
		and s.position = p.position