select
	playlist_id
	,'XX' as territory
	,@datePartition as report_date
	,date_add(@datePartition, interval -27 day) as frame_start_timestamp
	,date_add(@datePartition, interval 1 day) as frame_end_timestamp

	---------------------------------------
	--Most recent week
	---------------------------------------
	,avg(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end) as inflection_position_week
	,sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_week
	,sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_week
	,sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_week

	---------------------------------------
	--Avg weekly for last 4 weeks
	---------------------------------------
	--Inflection
	,round((
		avg(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end) --as inflection_position_week_4
		+
		avg(case when report_date between date_add(@datePartition, interval -13 day) and date_add(@datePartition, interval -7 day) then pred_midpoint end) --as inflection_position_week_3
		+
		avg(case when report_date between date_add(@datePartition, interval -20 day) and date_add(@datePartition, interval -14 day) then pred_midpoint end) --as inflection_position_week_2
		+
		avg(case when report_date between date_add(@datePartition, interval -27 day) and date_add(@datePartition, interval -21 day) then pred_midpoint end) --as inflection_position_week_1
	) / 4.0) as inflection_position_week_avg
	--Slope
	,(
		sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) --as slope_week_4
		+
		sum(case when report_date between date_add(@datePartition, interval -13 day) and date_add(@datePartition, interval -7 day) then slope end) --as slope_week_3
		+
		sum(case when report_date between date_add(@datePartition, interval -20 day) and date_add(@datePartition, interval -14 day) then slope end) --as slope_week_2
		+
		sum(case when report_date between date_add(@datePartition, interval -27 day) and date_add(@datePartition, interval -21 day) then slope end) --as slope_week_1
	) / 4.0 as slope_week_avg
	--Intercept
	,(
		sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) --as intercept_week_4
		+
		sum(case when report_date between date_add(@datePartition, interval -13 day) and date_add(@datePartition, interval -7 day) then intercept end) --as intercept_week_3
		+
		sum(case when report_date between date_add(@datePartition, interval -20 day) and date_add(@datePartition, interval -14 day) then intercept end) --as intercept_week_2
		+
		sum(case when report_date between date_add(@datePartition, interval -27 day) and date_add(@datePartition, interval -21 day) then intercept end) --as intercept_week_1
	) / 4 as intercept_week_avg
	--Streams Total
	,(
		sum(case when report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end)
		+
		sum(case when report_date between date_add(@datePartition, interval -13 day) and date_add(@datePartition, interval -7 day) then streams_total_predicted end)
		+
		sum(case when report_date between date_add(@datePartition, interval -20 day) and date_add(@datePartition, interval -14 day) then streams_total_predicted end)
		+
		sum(case when report_date between date_add(@datePartition, interval -27 day) and date_add(@datePartition, interval -21 day) then streams_total_predicted end)
	) / 4 as streams_total_estimate_week_avg

	---------------------------------------
	--Daily values for the most recent week
	---------------------------------------
	--Fri (global release date week start)
	,round(avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_fri
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_fri
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_fri
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_fri
	--Sat
	,round(avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_sat
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_sat
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_sat
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_sat
	--Sun
	,round(avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_sun
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_sun
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_sun
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_sun
	--Mon
	,round(avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_mon
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_mon
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_mon
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_mon
	--Tue
	,round(avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_tue
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_tue
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_tue
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_tue
	--Wed
	,round(avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_wed
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_wed
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) asintercept_wed
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_wed
	--Thu
	,round(avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then pred_midpoint end)) as inflection_position_thu
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then slope end) as slope_thu
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then intercept end) as intercept_thu
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -6 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_thu

	------------------------------------------------------------------------------
	--Average daily figures for each day of the week, across the last 4 weeks
	------------------------------------------------------------------------------
	--Fri (global release date week start)
	,round(avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_fri_avg
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_fri_avg
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_fri_avg
	,avg(case when extract(dayofweek from report_date) = 6 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_fri_avg
	--Sat
	,round(avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_sat_avg
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_sat_avg
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_sat_avg
	,avg(case when extract(dayofweek from report_date) = 7 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_sat_avg
	--Sun
	,round(avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_sun_avg
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_sun_avg
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_sun_avg
	,avg(case when extract(dayofweek from report_date) = 1 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_sun_avg
	--Mon
	,round(avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_mon_avg
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_mon_avg
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_mon_avg
	,avg(case when extract(dayofweek from report_date) = 2 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_mon_avg
	--Tue
	,round(avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_tue_avg
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_tue_avg
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_tue_avg
	,avg(case when extract(dayofweek from report_date) = 3 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_tue_avg
	--Wed
	,round(avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_wed_avg
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_wed_avg
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) asintercept_wed_avg
	,avg(case when extract(dayofweek from report_date) = 4 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_wed_avg
	--Thu
	,round(avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then pred_midpoint end)) as inflection_position_thu_avg
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then slope end) as slope_thu_avg
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then intercept end) as intercept_thu_avg
	,avg(case when extract(dayofweek from report_date) = 5 and report_date between date_add(@datePartition, interval -27 day) and @datePartition then streams_total_predicted end) as streams_total_estimate_thu_avg
	from
		`umg-user.Olga.aggregate_playlist_projection_features` f
	where

--	CHANGE TO _PARTITIONTIME
		report_date between date_add(@datePartition, interval -27 day) and @datePartition
	group by
		playlist_id