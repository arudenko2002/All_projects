select
  isrc
  ,upc
  ,stream_count
  ,stream_duration as modal_stream_length
from
  (
  select *
    ,row_number() over (partition by isrc,upc order by stream_count desc, isrc) as rn
  from
  (
    select
      isrc
      ,upc
      ,count(1) as stream_count
      ,stream_duration
    from
      `umg-partner.spotify.streams`
    where _partitiontime >= timestamp(date_add('2017-05-06', interval -31 day))
    group by
      isrc
      ,upc
      ,stream_duration
  ))
  histogram
where
  rn = 1