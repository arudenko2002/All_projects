import json
from utils import get_output
import time
import os.path
import re

# create a folder with today's date if it doesn't exist
pull_date = time.strftime("playlist_tracks/%Y-%m-%d/")
if not os.path.exists(pull_date):
    os.makedirs(pull_date)

# read file into memory, get playlist id, get tracks and their position
filepath = '/Users/kovaleo/Documents/Swift/Apple_Music/playlist_uri_id.txt'
fileContent = open(filepath).read()
for lines in fileContent.splitlines():
    lines = re.split(r'\t', lines)
    playlist_id = lines[2]

    file_name = os.path.join(pull_date, playlist_id + '.txt')
    if os.path.isfile(file_name):
        file = open(file_name, "r")
        file.read()

    output = get_output(playlist_id)
    # convert output to json (dictionary)
    dict_output = json.loads(output)

    file = open(file_name, 'w')

    # loop through the dictionary to get tracks and artists on the playlist
    dataArray = dict_output['data'][0]['relationships']['tracks']['data']
    playlist_url = dict_output['data'][0]['attributes']['url']
    for i in range(0, len(dataArray)):
        track_id = dataArray[i]['id']
        playlist_tracks = u'\t'.join((' Playlist_url:', playlist_url, 'Track_id:', track_id, 'Position:', str(i+1), 'TrackName:', dataArray[i]['attributes']['name'], 'Artist Name:', dataArray[i]['attributes']['artistName'])).encode('utf-8').strip()

        file.write(playlist_tracks+"\n")
    file.close()