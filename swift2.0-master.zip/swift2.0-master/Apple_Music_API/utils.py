# util function to get developer token and json response for each playlist id

# requires pyjwt (https://pyjwt.readthedocs.io/en/latest/)
# pip install pyjwt

import datetime
import jwt
import subprocess
import os.path
import os
import time

# current date in dd/mm/yyyy format
pull_date = time.strftime("%d-%m-%Y")

cache_token = ''

def get_token():
    global cache_token
    if cache_token != '':
        return cache_token

    secret = ("-----BEGIN PRIVATE KEY-----" "\n"
              "insert your secret here"  "\n"
              "-----END PRIVATE KEY-----")

    keyId = "insert your keyId here"
    teamId = "insert your teamId here"
    alg = 'ES256'

    time_now = datetime.datetime.now()
    time_expired = datetime.datetime.now() + datetime.timedelta(hours=12)

    headers = {
        "alg": alg,
        "kid": keyId
    }

    payload = {
        "iss": teamId,
        "exp": int(time_expired.strftime("%s")),
        "iat": int(time_now.strftime("%s"))
    }

    # if __name__ == "__main__":
    """Create an auth token"""
    token = jwt.encode(payload, secret, algorithm=alg, headers=headers)
    cache_token = token
    return token

# create a folder with today's date if it doesn't exist
pull_date = time.strftime("cache/%Y-%m-%d/")
if not os.path.exists(pull_date):
    os.makedirs(pull_date)


# function to get response by playlist_id
def get_output(id):

    file_name = os.path.join(pull_date, id + '.txt')
    if os.path.isfile(file_name):
        file = open(file_name, "r")
        return file.read()

    file = open(file_name, 'w')
    # construct a bash command - authenticated request
    token = get_token()
    bash_com = "curl -v -H 'Authorization: Bearer %s' \"https://api.music.apple.com/v1/catalog/us/playlists/%s\" " % (token, id)
    # save output to a variable output
    output = subprocess.check_output(['bash', '-c', bash_com])

    file.write(output)
    file.close()
    return output