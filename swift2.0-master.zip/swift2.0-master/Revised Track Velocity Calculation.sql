/* The new velocity calculation will enable us to measure relative velocity between tracks at a global level or within country as well as to measure relative velocity of a track across markets (e.g. trending tracks as well as trending countries/regions for a track).
Track rank within a territory is the major metric we start with - it is easy to compare across different territories. The rank within market is essentially a crude way to normalize for different market sizes.
 
- Each track is restricted to have the highest possible rank equal to 5,000; 
- Start with difference in rank within market as our starting point (rank last week - rank this week)
- Normalize this across all tracks in the market
- Positive figure means track/artist is trending above the average for all tracks in the market
- However a movement of 10 places from say 20th to 10th rank will have the same value within the same market as a track moving from 1020th to 1010th
- So we need to weight this score by the actual rank position they end up at (smaller rank the better) – so it sounds like our weighting should be some transformation of (1/current rank) – we use current rank because every track will have a value here, unlike last week’s rank
- Use  1/Current as the weight
- Since positive velocity just means it’s trending above the average for all tracks/artists, and there are some cases where streams are falling, but we still say it has small but positive velocity if the whole market went down:
    - If the final Rank Adjusted Score is POSITIVE and either (TW Streams < LW Streams )  OR (TW Rank > LW Rank)   [i.e. the track is either falling in rank or overall streams] then we should set Rank Adjusted Score to Zero  
    - All other cases are left untouched */
    
    
--Step 1: create a base table
--The query takes around 3 minutes to run and returns ~160 millions of records
--This is the base table to be used in further analysis - trending tracks, artists, countries, regions, etc.
--Add label data later
SELECT *
FROM
(SELECT cn.default_name AS track_artist,
       cr.title AS track_title,
       t.user_country_code AS country_code,
       t.user_country_name AS country_name,
       t.region_dma_code AS region_dma_code,
       t.dma_name AS dma_name,
       t.isrc AS isrc,
       t.weekNum AS weekNum,
       t.streams AS streams,
       t.streamsCollection AS streamsCollection,
       t.streamsPlaylists AS streamsPlaylists,
       t.streamsOther AS streamsOther
FROM
(
SELECT *
FROM
    (SELECT
    user_country_code,
    user_country_name,
    CONCAT(user_dma_number, user_region_code) AS region_dma_code,
    user_dma_name AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    --change dates
    CASE WHEN _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-06') THEN 'LW'
         WHEN _partitiontime between timestamp('2017-03-07') and timestamp('2017-03-13') THEN 'TW'
         END AS weekNum
    --change dates
    FROM [umg-partner:spotify.streams]
    --change dates
    WHERE _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-13')
    --change dates
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    ),
    (SELECT
    'XX' AS user_country_code,
    'Global' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    --change dates
    CASE WHEN _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-06') THEN 'LW'
         WHEN _partitiontime between timestamp('2017-03-07') and timestamp('2017-03-13') THEN 'TW'
         END AS weekNum
    --change dates
    FROM [umg-partner:spotify.streams]
    --change dates
    WHERE _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-13')
    --change dates
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    ),
    (SELECT
    'EX-US' AS user_country_code,
    'Global Ex-U.S.' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    --change dates
    CASE WHEN _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-06') THEN 'LW'
         WHEN _partitiontime between timestamp('2017-03-07') and timestamp('2017-03-13') THEN 'TW'
         END AS weekNum
    --change dates
    FROM [umg-partner:spotify.streams]
    --change dates
    WHERE _partitiontime between timestamp('2017-02-28') and timestamp('2017-03-13') and user_country_code != 'US'
    --change dates
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    )
)AS t
LEFT JOIN
	(SELECT isrc, resource_rollup_id, canopus_id
	FROM [umg-tools:metadata.canopus_resource]
	GROUP BY isrc, resource_rollup_id, canopus_id)  AS c
	ON c.isrc = t.isrc
LEFT JOIN
	(SELECT canopus_id, default_name
	FROM [umg-tools:metadata.canopus_name]
	GROUP BY  canopus_id, default_name) AS cn
	ON cn.canopus_id = c.canopus_id
LEFT JOIN
	(SELECT canopus_id, resource_rollup_id, title
	FROM [umg-tools:metadata.canopus_resource_rollup]
	GROUP BY  canopus_id, resource_rollup_id, title) AS cr
	ON c.canopus_id = cr.canopus_id AND c.resource_rollup_id = cr.resource_rollup_id)
WHERE track_artist is not null AND track_title is not null



--Step 2: trending tracks, trending countries for a track
SELECT track_artist, track_title, country_code, country_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw)
     THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_name) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_name) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained
FROM
(SELECT *,
rank() over (partition by country_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc
FROM
(SELECT track_artist, track_title, country_code, country_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM [umg-user:Olga.tt_0329_v2_extra_stats]
GROUP BY track_artist, track_title, country_code, country_name)))))
WHERE rankTw <= 2000)


--Step 3: trending artists, trending countries for an artist
SELECT track_artist, country_code, country_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained
FROM
(SELECT *,
rank() over (partition by country_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc
FROM
(SELECT track_artist, country_code, country_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM [umg-user:Olga.tt_0329_v2_extra_stats]
WHERE track_artist != ''
GROUP BY track_artist, country_code, country_name)))))
WHERE rankTw <= 500)


--Step 4: trending regions/DMA's for a track, trending tracks for each region/DMA
SELECT track_artist, track_title, country_code, country_name, region_dma_code, dma_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code, region_dma_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code, region_dma_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained
FROM
(SELECT *,
rank() over (partition by country_code, region_dma_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code, region_dma_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc
FROM
(SELECT track_artist, track_title, country_code, country_name,
        region_dma_code, dma_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM [umg-user:Olga.tt_0329_v2_extra_stats]
WHERE region_dma_code != ''
GROUP BY track_artist, track_title,
         country_code, country_name,
         region_dma_code, dma_name)))))
WHERE rankTw <= 2000)



--Step 5: trending regions/DMA's for an artist, trending artists for each region/DMA
SELECT track_artist, country_code, country_name, region_dma_code, dma_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code, region_dma_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code, region_dma_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc
FROM
(SELECT *,
rank() over (partition by country_code, region_dma_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code, region_dma_code order by streamsTw desc) AS rankTw
FROM
(SELECT track_artist, country_code, country_name,
        region_dma_code, dma_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM [umg-user:Olga.tt_0329_v2_extra_stats]
WHERE track_artist != '' OR region_dma_code != ''
GROUP BY track_artist,
         country_code, country_name,
         region_dma_code, dma_name)))))
WHERE rankTw <= 500)
