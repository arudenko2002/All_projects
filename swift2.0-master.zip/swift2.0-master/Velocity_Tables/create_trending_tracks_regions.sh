#!/usr/bin/env bash

bq mk --time_partitioning_type=DAY umg-tools:test.trending_tracks_regions