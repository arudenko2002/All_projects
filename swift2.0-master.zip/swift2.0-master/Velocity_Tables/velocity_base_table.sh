#!/usr/bin/env bash

partitionDate=$1
bq --nosync query --batch --allow_large_results --replace --nouse_legacy_sql --parameter datePartition:STRING:$partitionDate --destination_table umg-tools:test.velocity_base_table\$$2 "$(cat sql/velocity_base_table.sql)"
