#!/usr/bin/env bash

bq mk --time_partitioning_type=DAY umg-tools:test.velocity_base_table