#!/usr/bin/env bash

partitionDate=$1
bq --nosync query --batch --allow_large_results --replace --nouse_legacy_sql --parameter datePartition:STRING:$partitionDate --destination_table umg-tools:test.trending_artists_regions\$$2 "$(cat sql/trending_artists_regions.sql)"
