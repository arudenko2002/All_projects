#Step 4: trending regions/DMAs for a track, trending tracks for each region/DMA
SELECT report_date, isrc, 
       canopus_id,
       track_artist, track_title,
       country_code, country_name, region_dma_code, dma_name,
       streamsLw, streamsTw,
       streamsCollectionTw, streamsCollectionLw,
       collectionPerc, playlistsPerc, otherPerc,
       streamsAllGrowth, streamsCollectionGrowth, effectiveGrowthFlag,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
CASE WHEN stdTransformedDiff != 0 AND zScoreTransformedDiffDivider != 0
     THEN((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider END AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code, region_dma_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code, region_dma_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained,
CASE WHEN streamsCollectionGrowth >= streamsAllGrowth THEN 1 ELSE 0 END AS effectiveGrowthFlag
FROM
(SELECT *,
rank() over (partition by country_code, region_dma_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code, region_dma_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc,
CASE WHEN streamsLw is null  THEN (streamsTw/1 - 1) * 100
     ELSE (streamsTw/streamsLw - 1) * 100 END AS streamsAllGrowth,
CASE WHEN streamsCollectionLw = 0 or streamsCollectionLw is null THEN (streamsCollectionTw/1 - 1) * 100
     ELSE (streamsCollectionTw/streamsCollectionLw - 1) * 100 END AS streamsCollectionGrowth
FROM
(SELECT report_date, isrc, canopus_id, resource_rollup_id, track_artist, track_title, country_code, country_name,
        region_dma_code, dma_name,
SUM(CASE WHEN week = 'LW' THEN streams END) AS streams_lw,
SUM(CASE WHEN week = 'TW' THEN streams END) AS streams_tw,
SUM(CASE WHEN week = 'TW' THEN streams_collection END) AS streams_collection_tw,
SUM(CASE WHEN week = 'LW' THEN streams_collection END) AS streams_collection_lw,
SUM(CASE WHEN week = 'TW' THEN streams_other END) AS streams_other_tw,
SUM(CASE WHEN week = 'LW' THEN streams_other END) AS streams_other_lw,
SUM(CASE WHEN week = 'TW' THEN streams_artist END) AS streams_artist_tw,
SUM(CASE WHEN week = 'LW' THEN streams_artist END) AS streams_artist_lw,
SUM(CASE WHEN week = 'TW' THEN streams_album END) AS streams_album_tw,
SUM(CASE WHEN week = 'LW' THEN streams_album END) AS streams_album_lw,
SUM(CASE WHEN week = 'TW' THEN streams_search END) AS streams_search_tw,
SUM(CASE WHEN week = 'LW' THEN streams_search END) AS streams_search_lw,
SUM(CASE WHEN week = 'TW' THEN streams_undeveloped_playlist END) AS streams_undeveloped_playlist_tw,
SUM(CASE WHEN week = 'LW' THEN streams_undeveloped_playlist END) AS streams_undeveloped_playlist_lw,
SUM(CASE WHEN week = 'TW' THEN streams_playlist END) AS streams_playlist_tw,
SUM(CASE WHEN week = 'LW' THEN streams_playlist END) AS streams_playlist_lw
FROM `umg-tools.test.velocity_base_table` --the table from the step 1_velocity_base_table
WHERE region_dma_code != '' and _partitiontime = timestamp(@datePartition)
        and ((country_code = 'SE' and SUBSTR(region_dma_code , 1, 2)='SE' )
        or (country_code = 'AR' and SUBSTR(region_dma_code , 1, 2)='AR' )
        or (country_code = 'AU' and SUBSTR(region_dma_code , 1, 2)='AU' )
        or (country_code = 'BE' and SUBSTR(region_dma_code , 1, 2)='BE' )
        or (country_code = 'BR' and SUBSTR(region_dma_code , 1, 2)='BR' )
        or (country_code = 'US' and REGEXP_CONTAINS(region_dma_code, r'^[0-9]')=true)
        or (country_code = 'DE' and SUBSTR(region_dma_code , 1, 2)='DE' )
        or (country_code = 'DK' and SUBSTR(region_dma_code , 1, 2)='DK' )
        or (country_code = 'NO' and SUBSTR(region_dma_code , 1, 2)='NO' )
        or (country_code = 'ES' and SUBSTR(region_dma_code , 1, 2)='ES' )
        or (country_code = 'FI' and SUBSTR(region_dma_code , 1, 2)='FI' )
        or (country_code = 'FR' and SUBSTR(region_dma_code , 1, 2)='FR' )
        or (country_code = 'GB' and SUBSTR(region_dma_code , 1, 2)='GB' )
        or (country_code = 'IT' and SUBSTR(region_dma_code , 1, 2)='IT' )
        or (country_code = 'MX' and SUBSTR(region_dma_code , 1, 2)='MX' )
        or (country_code = 'NL' and SUBSTR(region_dma_code , 1, 2)='NL' ))

GROUP BY report_date, isrc, canopus_id, resource_rollup_id, track_artist, track_title,
         country_code, country_name, region_dma_code, dma_name)
         ))))
WHERE rankTw <= 2000)