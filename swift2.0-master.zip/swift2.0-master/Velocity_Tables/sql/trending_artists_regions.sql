SELECT report_date, canopus_id,
       track_artist, country_code, country_name, region_dma_code, dma_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       streamsAllGrowth, streamsCollectionGrowth, effectiveGrowthFlag,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *
,case when stdTransformedDiff=0 or zScoreTransformedDiffDivider=0
        then 0
        else ((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider
        end as rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code, region_dma_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code, region_dma_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc,
CASE WHEN streamsCollectionGrowth >= streamsAllGrowth THEN 1 ELSE 0 END AS effectiveGrowthFlag
FROM
(SELECT *,
rank() over (partition by country_code, region_dma_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code, region_dma_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsLw is null or streamsLw = 0  THEN 100
     ELSE (streamsTw/streamsLw - 1) * 100 END AS streamsAllGrowth,
CASE WHEN streamsCollectionLw = 0 or streamsCollectionLw is null THEN 100
     ELSE (streamsCollectionTw/streamsCollectionLw - 1) * 100 END AS streamsCollectionGrowth
FROM
(SELECT report_date, canopus_id,
        track_artist, country_code, country_name,
        region_dma_code, dma_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'LW' THEN streamsCollection END) AS streamsCollectionLw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM `umg-tools.test.velocity_base_table`
WHERE _partitiontime = timestamp(@datePartition)
        and (track_artist != '' OR region_dma_code != '')
        and ((country_code = 'SE' and SUBSTR(region_dma_code , 1, 2)='SE' )
        or (country_code = 'AR' and SUBSTR(region_dma_code , 1, 2)='AR' )
        or (country_code = 'AU' and SUBSTR(region_dma_code , 1, 2)='AU' )
        or (country_code = 'BE' and SUBSTR(region_dma_code , 1, 2)='BE' )
        or (country_code = 'BR' and SUBSTR(region_dma_code , 1, 2)='BR' )
        or (country_code = 'US' and REGEXP_CONTAINS(region_dma_code, r'^[0-9]')=true)
        or (country_code = 'DE' and SUBSTR(region_dma_code , 1, 2)='DE' )
        or (country_code = 'DK' and SUBSTR(region_dma_code , 1, 2)='DK' )
        or (country_code = 'NO' and SUBSTR(region_dma_code , 1, 2)='NO' )
        or (country_code = 'ES' and SUBSTR(region_dma_code , 1, 2)='ES' )
        or (country_code = 'FI' and SUBSTR(region_dma_code , 1, 2)='FI' )
        or (country_code = 'FR' and SUBSTR(region_dma_code , 1, 2)='FR' )
        or (country_code = 'GB' and SUBSTR(region_dma_code , 1, 2)='GB' )
        or (country_code = 'IT' and SUBSTR(region_dma_code , 1, 2)='IT' )
        or (country_code = 'MX' and SUBSTR(region_dma_code , 1, 2)='MX' )
        or (country_code = 'NL' and SUBSTR(region_dma_code , 1, 2)='NL' ))
GROUP BY report_date, canopus_id, track_artist,
         country_code, country_name,
         region_dma_code, dma_name)))))
WHERE rankTw <= 1000)