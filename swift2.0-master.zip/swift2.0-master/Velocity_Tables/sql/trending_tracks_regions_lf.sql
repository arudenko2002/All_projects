# trending regions/DMAs for a track, trending tracks for each region/DMA by LF streams
SELECT report_date, d.isrc, l.sap_segment_name as label,
       rd.release_date, canopus_id,
       track_artist, track_title,
       country_code, country_name, region_dma_code, dma_name,
       streamsLw, streamsTw,
       streamsCollectionTw, streamsCollectionLw,
       streamsLfTw, streamsLfLw,
       collectionPerc, playlistsPerc, otherPerc,
       streamsAllGrowth, streamsCollectionGrowth, effectiveGrowthFlag,
       rankLfLw, rankLfTw,
CASE WHEN rankAdjScore > 0 AND (streamsLfTw < streamsLfLw OR rankLfTw > rankLfLw)
     THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
CASE WHEN stdTransformedDiff != 0 AND zScoreTransformedDiffDivider != 0
     THEN((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider END AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code, region_dma_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code, region_dma_code) AS stdTransformedDiff,
ASINH(LEAST(rankLfTw, rankLfLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLfLwConstrained - rankLfTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLfLw <= 5000 THEN rankLfLw ELSE 5000 END AS rankLfLwConstrained,
CASE WHEN rankLfTw <= 5000 THEN rankLfTw ELSE 5000 END AS rankLfTwConstrained,
CASE WHEN streamsCollectionGrowth >= streamsAllGrowth THEN 1 ELSE 0 END AS effectiveGrowthFlag
FROM
(SELECT *,
rank() over (partition by country_code, region_dma_code order by streamsLfLw  desc) AS rankLfLw,
rank() over (partition by country_code, region_dma_code order by streamsLfTw desc) AS rankLfTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc,
CASE WHEN streamsLw is not null  THEN (streamsTw/streamsLw - 1) * 100 END AS streamsAllGrowth,
CASE WHEN streamsCollectionLw != 0 and streamsCollectionLw is not null then
          (streamsCollectionTw/streamsCollectionLw - 1) * 100 END AS streamsCollectionGrowth
FROM
(SELECT report_date, isrc, canopus_id, track_artist, track_title, country_code, country_name,
        region_dma_code, dma_name,
        row_number () over (partition by report_date, isrc, country_code, region_dma_code) as rn_track_title,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'LW' THEN streamsCollection END) AS streamsCollectionLw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw,
SUM(CASE WHEN weekNum = 'LW' THEN streams - streamsPlaylists - streamsOther END) AS streamsLfLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams - streamsPlaylists - streamsOther END) AS streamsLfTw
FROM `umg-tools.test.velocity_base_table`
WHERE _partitiontime = timestamp(@datePartition) and region_dma_code != ''
      and ((country_code = 'SE' and SUBSTR(region_dma_code , 1, 2)='SE' )
        or (country_code = 'AR' and SUBSTR(region_dma_code , 1, 2)='AR' )
        or (country_code = 'AU' and SUBSTR(region_dma_code , 1, 2)='AU' )
        or (country_code = 'BE' and SUBSTR(region_dma_code , 1, 2)='BE' )
        or (country_code = 'BR' and SUBSTR(region_dma_code , 1, 2)='BR' )
        or (country_code = 'US' and REGEXP_CONTAINS(region_dma_code, r'^[0-9]')=true)
        or (country_code = 'DE' and SUBSTR(region_dma_code , 1, 2)='DE' )
        or (country_code = 'DK' and SUBSTR(region_dma_code , 1, 2)='DK' )
        or (country_code = 'NO' and SUBSTR(region_dma_code , 1, 2)='NO' )
        or (country_code = 'ES' and SUBSTR(region_dma_code , 1, 2)='ES' )
        or (country_code = 'FI' and SUBSTR(region_dma_code , 1, 2)='FI' )
        or (country_code = 'FR' and SUBSTR(region_dma_code , 1, 2)='FR' )
        or (country_code = 'GB' and SUBSTR(region_dma_code , 1, 2)='GB' )
        or (country_code = 'IT' and SUBSTR(region_dma_code , 1, 2)='IT' )
        or (country_code = 'MX' and SUBSTR(region_dma_code , 1, 2)='MX' )
        or (country_code = 'NL' and SUBSTR(region_dma_code , 1, 2)='NL' ))
GROUP BY report_date, isrc, canopus_id, track_artist, track_title,
         country_code, country_name,
         region_dma_code, dma_name)
WHERE rn_track_title = 1))))
WHERE rankLfTw <= 2000) d
LEFT JOIN
(SELECT isrc, earliest_resource_release_date as release_date
FROM `umg-marketing.metadata.product`
GROUP BY isrc, earliest_resource_release_date) rd
ON d.isrc = rd.isrc
LEFT JOIN
(SELECT isrc, sales_country_code, sap_segment_name
FROM `umg-marketing.metadata.local_product`
WHERE isrc != ''
GROUP BY isrc, sales_country_code, sap_segment_name
) l
ON d.isrc = l.isrc and d.country_code = l.sales_country_code