SELECT report_date, canopus_id,
       track_artist, country_code, country_name,
       streamsLw, streamsTw,
       collectionPerc, playlistsPerc, otherPerc,
       streamsAllGrowth, streamsCollectionGrowth, effectiveGrowthFlag,
       rankLw, rankTw,
CASE WHEN rankAdjScore > 0 AND (streamsTw < streamsLw OR rankTw > rankLw) THEN 0 ELSE rankAdjScore END AS rankAdjScore
FROM
(
SELECT *,
((transformedDiff - meanTransformedDiff)/stdTransformedDiff)/zScoreTransformedDiffDivider AS rankAdjScore
FROM
(
SELECT *,
AVG(transformedDiff) OVER (partition by country_code) AS meanTransformedDiff,
STDDEV(transformedDiff) OVER (partition by country_code) AS stdTransformedDiff,
ASINH(LEAST(rankTw, rankLw)) AS zScoreTransformedDiffDivider
FROM
(
SELECT *,
ASINH(rankLwConstrained - rankTwConstrained) AS transformedDiff
FROM
(
SELECT *,
CASE WHEN rankLw <= 5000 THEN rankLw ELSE 5000 END AS rankLwConstrained,
CASE WHEN rankTw <= 5000 THEN rankTw ELSE 5000 END AS rankTwConstrained,
CASE WHEN streamsCollectionGrowth >= streamsAllGrowth THEN 1 ELSE 0 END AS effectiveGrowthFlag
FROM
(SELECT *,
rank() over (partition by country_code order by streamsLw  desc) AS rankLw,
rank() over (partition by country_code order by streamsTw desc) AS rankTw,
CASE WHEN streamsTw != 0 THEN streamsCollectionTw/streamsTw ELSE null END AS collectionPerc,
CASE WHEN streamsTw != 0 THEN streamsPlaylistsTw/streamsTw ELSE null END AS playlistsPerc,
CASE WHEN streamsTw != 0 THEN streamsOtherTw/streamsTw ELSE null END AS otherPerc,
CASE WHEN streamsLw is null or streamsLw = 0  THEN 100
     ELSE (streamsTw/streamsLw - 1) * 100 END AS streamsAllGrowth,
CASE WHEN streamsCollectionLw = 0 or streamsCollectionLw is null THEN 100
     ELSE (streamsCollectionTw/streamsCollectionLw - 1) * 100 END AS streamsCollectionGrowth
FROM
(SELECT report_date, canopus_id, track_artist, country_code, country_name,
SUM(CASE WHEN weekNum = 'LW' THEN streams END) AS streamsLw,
SUM(CASE WHEN weekNum = 'TW' THEN streams END) AS streamsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsCollection END) AS streamsCollectionTw,
SUM(CASE WHEN weekNum = 'LW' THEN streamsCollection END) AS streamsCollectionLw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsPlaylists END) AS streamsPlaylistsTw,
SUM(CASE WHEN weekNum = 'TW' THEN streamsOther END) AS streamsOtherTw
FROM `umg-tools.test.velocity_base_table`
WHERE _partitiontime = timestamp(@datePartition) and track_artist != ''
GROUP BY report_date, canopus_id, track_artist, country_code, country_name)))))
WHERE rankTw <= 1000)