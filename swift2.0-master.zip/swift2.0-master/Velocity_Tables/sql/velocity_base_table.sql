SELECT *
FROM
(SELECT 
	   t.report_date AS report_date,
       cn.canopus_id AS canopus_id,
	   cn.default_name AS track_artist,
       c.formatted_title  AS track_title,
       t.user_country_code AS country_code,
       t.user_country_name AS country_name,
       t.region_dma_code AS region_dma_code,
       t.dma_name AS dma_name,
       t.isrc AS isrc,
       t.weekNum AS weekNum,
       t.streams AS streams,
       t.streamsCollection AS streamsCollection,
       t.streamsPlaylists AS streamsPlaylists,
       t.streamsOther AS streamsOther
FROM
(
SELECT *
FROM
    (SELECT
    @datePartition as report_date,
    user_country_code,
    user_country_name,
    CONCAT(user_dma_number, user_region_code) AS region_dma_code,
    user_dma_name AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS weekNum
    FROM `umg-partner.spotify.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    )
    UNION ALL
    (SELECT
    @datePartition as report_date,
    'XX' AS user_country_code,
    'Global' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS weekNum
    FROM `umg-partner.spotify.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    )
    UNION ALL
    (SELECT
    @datePartition as report_date,
    'EX-US' AS user_country_code,
    'Global Ex-U.S.' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streamsCollection,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streamsPlaylists,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streamsOther,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS weekNum
    FROM `umg-partner.spotify.streams`
        WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
              and user_country_code != 'US'
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, weekNum
    )
)AS t
LEFT JOIN
	(SELECT isrc, canopus_id, formatted_title, resource_rollup_id
	FROM `umg-tools.metadata.canopus_resource`
	GROUP BY isrc, canopus_id, formatted_title, resource_rollup_id)  AS c
	ON c.isrc = t.isrc
LEFT JOIN
	(SELECT canopus_id, default_name
	FROM `umg-tools.metadata.canopus_name`
	GROUP BY  canopus_id, default_name) AS cn
	ON cn.canopus_id = c.canopus_id
LEFT JOIN
	(SELECT canopus_id, resource_rollup_id 
	FROM `umg-tools.metadata.canopus_resource_rollup`
	GROUP BY  canopus_id, resource_rollup_id) AS cr
	ON c.canopus_id = cr.canopus_id AND c.resource_rollup_id = cr.resource_rollup_id)
WHERE track_artist is not null AND track_title is not null