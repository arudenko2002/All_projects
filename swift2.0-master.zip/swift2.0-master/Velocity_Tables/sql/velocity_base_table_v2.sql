/* The new velocity calculation will enable us to measure relative velocity between tracks at a global level or within country as well as to measure relative velocity of a track across markets (e.g. trending tracks as well as trending countries/regions for a track).
Track rank within a territory is the major metric we start with - it is easy to compare across different territories. The rank within market is essentially a crude way to normalize for different market sizes.
 
- Each track is restricted to have the highest possible rank equal to 5,000; 
- Start with difference in rank within market as our starting point (rank last week - rank this week)
- Normalize this across all tracks in the market
- Positive figure means track/artist is trending above the average for all tracks in the market
- However a movement of 10 places from say 20th to 10th rank will have the same value within the same market as a track moving from 1020th to 1010th
- So we need to weight this score by the actual rank position they end up at (smaller rank the better) – so it sounds like our weighting should be some transformation of (1/current rank) – we use current rank because every track will have a value here, unlike last week’s rank
- Use  1/Current as the weight
- Since positive velocity just means it’s trending above the average for all tracks/artists, and there are some cases where streams are falling, but we still say it has small but positive velocity if the whole market went down:
    - If the final Rank Adjusted Score is POSITIVE and either (TW Streams < LW Streams )  OR (TW Rank > LW Rank)   [i.e. the track is either falling in rank or overall streams] then we should set Rank Adjusted Score to Zero  
    - All other cases are left untouched */


#Step 1: create a base table
#The query takes around 3 minutes to run and returns 160 - 180 millions of records
#This is the base table to be used in further analysis - trending tracks, artists, countries, regions, etc.
SELECT *
FROM
(SELECT 
	   t.report_date AS report_date,
       cn.canopus_id AS canopus_id,
       c.resource_rollup_id AS resource_rollup_id,
	   cn.default_name AS track_artist,
       c.formatted_title  AS track_title,
       t.user_country_code AS country_code,
       t.user_country_name AS country_name,
       t.region_dma_code AS region_dma_code,
       t.dma_name AS dma_name,
       t.isrc AS isrc,
       t.week AS week,
       t.streams AS streams,
       t.streams_collection AS streams_collection,
       t.streams_playlist AS streams_playlist,
       t.streams_undeveloped_playlist AS streams_undeveloped_playlist,
       t.streams_other AS streams_other,
       t.streams_artist AS streams_artist,
       t.streams_album AS streams_album,
       t.streams_search AS streams_search
FROM
(
SELECT *
FROM
    (SELECT
    @datePartition as report_date,
    user_country_code,
    user_country_name,
    CONCAT(user_dma_number, user_region_code) AS region_dma_code,
    user_dma_name AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'artist' THEN 1 END) AS streams_artist,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri = '' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streams_playlist,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.spotify.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, week
    )
    UNION ALL
    (SELECT
    @datePartition as report_date,
    'XX' AS user_country_code,
    'Global' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'artist' THEN 1 END) AS streams_artist,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri = '' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streams_playlist,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.spotify.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, week
    )
    UNION ALL
    (SELECT
    @datePartition as report_date,
    'EX-US' AS user_country_code,
    'Global Ex-U.S.' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'artist' THEN 1 END) AS streams_artist,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri = '' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'others_playlist' AND source_uri != '' THEN 1 END) AS streams_playlist,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.spotify.streams`
        WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
              and user_country_code != 'US'
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, week
    )
)AS t
LEFT JOIN
	(SELECT isrc, canopus_id, formatted_title, resource_rollup_id
	FROM `umg-tools.metadata.canopus_resource`
	GROUP BY isrc, canopus_id, formatted_title, resource_rollup_id)  AS c
	ON c.isrc = t.isrc
LEFT JOIN
	(SELECT canopus_id, default_name
	FROM `umg-tools.metadata.canopus_name`
	GROUP BY  canopus_id, default_name) AS cn
	ON cn.canopus_id = c.canopus_id
)
WHERE track_artist is not null AND track_title is not null