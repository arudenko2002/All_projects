#!/usr/bin/env bash

bq mk --time_partitioning_type=DAY umg-tools:test.trending_artists_countries