/* The new velocity calculation will enable us to measure relative velocity between tracks at a global level or within country as well as to measure relative velocity of a track across markets (e.g. trending tracks as well as trending countries/regions for a track).
Track rank within a territory is the major metric we start with - it is easy to compare across different territories. The rank within market is essentially a crude way to normalize for different market sizes.
 
- Each track is restricted to have the highest possible rank equal to 5,000; 
- Start with difference in rank within market as our starting point (rank last week - rank this week)
- Normalize this across all tracks in the market
- Positive figure means track/artist is trending above the average for all tracks in the market
- However a movement of 10 places from say 20th to 10th rank will have the same value within the same market as a track moving from 1020th to 1010th
- So we need to weight this score by the actual rank position they end up at (smaller rank the better) – so it sounds like our weighting should be some transformation of (1/current rank) – we use current rank because every track will have a value here, unlike last week’s rank
- Use  1/Current as the weight
- Since positive velocity just means it’s trending above the average for all tracks/artists, and there are some cases where streams are falling, but we still say it has small but positive velocity if the whole market went down:
    - If the final Rank Adjusted Score is POSITIVE and either (TW Streams < LW Streams )  OR (TW Rank > LW Rank)   [i.e. the track is either falling in rank or overall streams] then we should set Rank Adjusted Score to Zero  
    - All other cases are left untouched */




#Step 1: create a base table
SELECT *
FROM
(SELECT 
       t.report_date AS report_date,
       cn.canopus_id AS canopus_id,
       c.resource_rollup_id AS resource_rollup_id,
       cn.default_name AS track_artist,
       c.formatted_title  AS track_title,
       t.user_country_code AS country_code,
       t.user_country_name AS country_name,
       t.region_dma_code AS region_dma_code,
       t.dma_name AS dma_name,
       t.isrc AS isrc,
       t.week AS week,
       t.streams AS streams,
       t.streams_collection AS streams_collection,
       t.streams_playlist AS streams_playlist,
       t.streams_undeveloped_playlist AS streams_undeveloped_playlist,
       t.streams_other AS streams_other,
       t.streams_album AS streams_album,
       t.streams_search AS streams_search,
       t.streams_radio AS streams_radio
FROM
(
SELECT *
FROM
    
    # prepare data on a country and region level
    (SELECT 
            report_date, user_country_code, user_country_name, 
            CONCAT(ifnull(zc.dma_id, ''), ifnull(pc.iso2, '')) AS region_dma_code,
            ifnull(zc.dma_name, '') AS dma_name,
            isrc, streams, streams_collection, streams_other,
            streams_album, streams_search, streams_undeveloped_playlist, streams_playlist, streams_radio, week      
    FROM
    (SELECT
    @datePartition as report_date,
    user_country_code,
    user_country_name,
    user_postal_code,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'playlist' THEN 1 END) AS streams_playlist,
    COUNT (CASE WHEN stream_source = 'radio' THEN 1 END) AS streams_radio,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.apple_music.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, user_postal_code, isrc, week
    ) AS s
    
    # derive DMA id and DMA name for the US and ISO2 region code for ex-US by postcode provided by Apple
    LEFT JOIN
      (SELECT *
      FROM
      (SELECT iso, postcode, iso2, row_number() over (partition by iso, postcode) AS rn
      FROM `umg-tools.metadata.country_subdivision`
      WHERE postcode != '' and iso2 != '') 
      WHERE rn = 1
      ) AS pc
      ON s.user_country_code = pc.iso and s.user_postal_code = pc.postcode
    LEFT JOIN `umg-tools.metadata.zip_to_dma` AS zc
      ON s.user_country_code = zc.country_code and s.user_postal_code = zc.zip_code
    )
    
    # prepare data on a global level, append to coutnry level data
    UNION ALL
    (SELECT
    @datePartition as report_date,
    'XX' AS user_country_code,
    'Global' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'playlist' THEN 1 END) AS streams_playlist,
    COUNT (CASE WHEN stream_source = 'radio' THEN 1 END) AS streams_radio,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.apple_music.streams`
    WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, week
    )
    UNION ALL

    # prepare data on ex-US level, append to country and US level data
    (SELECT
    @datePartition as report_date,
    'EX-US' AS user_country_code,
    'Global Ex-U.S.' AS user_country_name,
    '' AS region_dma_code,
    '' AS dma_name,
    isrc,
    COUNT (1) AS streams,
    COUNT (CASE WHEN stream_source = 'collection' THEN 1 END) AS streams_collection,
    COUNT (CASE WHEN stream_source = 'other' THEN 1 END) AS streams_other,
    COUNT (CASE WHEN stream_source = 'album' THEN 1 END) AS streams_album,
    COUNT (CASE WHEN stream_source = 'search' THEN 1 END) AS streams_search,
    COUNT (CASE WHEN stream_source = 'others_playlist' THEN 1 END) AS streams_undeveloped_playlist,
    COUNT (CASE WHEN stream_source = 'playlist' THEN 1 END) AS streams_playlist,
    COUNT (CASE WHEN stream_source = 'radio' THEN 1 END) AS streams_radio,
    CASE WHEN _partitiontime between timestamp(date_add(@datePartition, interval -13 day)) and timestamp(date_add(@datePartition, interval - 7 day)) THEN 'LW'
         WHEN _partitiontime between timestamp(date_add(@datePartition, interval -6 day)) and timestamp(@datePartition) THEN 'TW'
         END AS week
    FROM `umg-partner.apple_music.streams`
        WHERE _partitiontime between timestamp(date_add(@datePartition, interval - 13 day)) and timestamp(@datePartition)
              and user_country_code != 'US'
    GROUP BY user_country_code, user_country_name, region_dma_code, dma_name, isrc, week
    )
)AS t

# add metadata: canopus id, artist name, title, resource rollup id
LEFT JOIN
(SELECT isrc, canopus_id, formatted_title, resource_rollup_id
 FROM
  (SELECT isrc, canopus_id, formatted_title, resource_rollup_id,
        row_number() over (partition by isrc, canopus_id, resource_rollup_id) as rn_title
   FROM `umg-tools.metadata.canopus_resource`)
 WHERE rn_title = 1
 GROUP BY isrc, canopus_id, formatted_title, resource_rollup_id
 )  AS c
  ON c.isrc = t.isrc
LEFT JOIN
  (SELECT canopus_id, default_name
  FROM `umg-tools.metadata.canopus_name`
  GROUP BY  canopus_id, default_name) AS cn
  ON cn.canopus_id = c.canopus_id
)
WHERE track_artist is not null AND track_title is not null