/* The new velocity calculation will enable us to measure relative velocity between tracks at a global level or within country as well as to measure relative velocity of a track across markets (e.g. trending tracks as well as trending countries/regions for a track).
Track rank within a territory is the major metric we start with - it is easy to compare across different territories. The rank within market is essentially a crude way to normalize for different market sizes.
 
- Each track is restricted to have the highest possible rank equal to 5,000; 
- Start with difference in rank within market as our starting point (rank last week - rank this week)
- Normalize this across all tracks in the market
- Positive figure means track/artist is trending above the average for all tracks in the market
- However a movement of 10 places from say 20th to 10th rank will have the same value within the same market as a track moving from 1020th to 1010th
- So we need to weight this score by the actual rank position they end up at (smaller rank the better) – so it sounds like our weighting should be some transformation of (1/current rank) – we use current rank because every track will have a value here, unlike last week’s rank
- Use  1/Current as the weight
- Since positive velocity just means it’s trending above the average for all tracks/artists, and there are some cases where streams are falling, but we still say it has small but positive velocity if the whole market went down:
    - If the final Rank Adjusted Score is POSITIVE and either (TW Streams < LW Streams )  OR (TW Rank > LW Rank)   [i.e. the track is either falling in rank or overall streams] then we should set Rank Adjusted Score to Zero  
    - All other cases are left untouched */