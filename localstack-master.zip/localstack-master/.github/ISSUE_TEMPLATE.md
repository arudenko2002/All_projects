<!-- Love localstack? Please consider supporting our collective:
👉  https://opencollective.com/localstack/donate -->