# Authors of join-library

The following is the official list of authors for copyright purposes of this community-contributed module.

    Google Inc.
    Magnus Runesson, M.Runesson [at] gmail [dot] com
