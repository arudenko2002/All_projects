# Authors of 'hadoop' module

The following is the official list of authors for copyright purposes of this community-contributed module.

    Cloudera
    Tom White, tom [at] cloudera [dot] com
    Google Inc.