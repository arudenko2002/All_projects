/*
 * Copyright (C) 2015 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.google.cloud.dataflow.sdk.io;

import static com.google.common.base.Preconditions.checkState;

import com.google.cloud.dataflow.sdk.coders.Coder;
import com.google.cloud.dataflow.sdk.coders.Coder.Context;
import com.google.cloud.dataflow.sdk.coders.KvCoder;
import com.google.cloud.dataflow.sdk.coders.StringUtf8Coder;
import com.google.cloud.dataflow.sdk.io.Read.Bounded;
import com.google.cloud.dataflow.sdk.options.PipelineOptions;
import com.google.cloud.dataflow.sdk.runners.DataflowPipelineRunner;
import com.google.cloud.dataflow.sdk.runners.DirectPipelineRunner;
import com.google.cloud.dataflow.sdk.transforms.PTransform;
import com.google.cloud.dataflow.sdk.transforms.display.DisplayData;
import com.google.cloud.dataflow.sdk.util.IOChannelUtils;
import com.google.cloud.dataflow.sdk.values.KV;
import com.google.cloud.dataflow.sdk.values.PCollection;
import com.google.cloud.dataflow.sdk.values.PInput;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.protobuf.ByteString;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.SeekableByteChannel;
import java.util.NoSuchElementException;
import java.util.regex.Pattern;

import javax.annotation.Nullable;

/**
 * {@link PTransform}s for reading text files and returning the filename.
 *
 * <p>To read a {@link PCollection} from one or more text files, use {@link TextWithFilenameRead.Read}.
 * You can instantiate a transform using {@link TextWithFilenameRead.Read#from(String)} to specify
 * the path of the file(s) to read from (e.g., a local filename or
 * filename pattern if running locally, or a Google Cloud Storage
 * filename or filename pattern of the form
 * {@code "gs://<bucket>/<filepath>"}). You may optionally call
 * {@link TextWithFilenameRead.Read#named(String)} to specify the name of the pipeline step.
 *
 * <p>By default, {@link TextWithFilenameRead.Read} returns a {@link PCollection} of
 * {@code KV<String, String>}, each corresponding to a) the filename, and b) one line of an input
 * UTF-8 text file. To convert the file contents directly from the raw bytes (split into lines
 * delimited by '\n', '\r', or '\r\n') to another object of type {@code T}, supply a
 * {@code Coder<T>} using {@link TextWithFilenameRead.Read#withCoder(Coder)}.
 *
 * <p>See the following examples:
 *
 * <pre>{@code
 * Pipeline p = ...;
 *
 * // A simple Read of a local file (only runs locally):
 * PCollection<KV<String, String>> namesAndLines =
 *     p.apply(TextWithFilenameRead.Read.from("/local/path/to/file.txt"));
 *
 * // A fully-specified Read from a GCS file (runs locally and via the
 * // Google Cloud Dataflow service):
 * PCollection<KV<String, Integer>> namesAndNumbers =
 *     p.apply(TextWithFilenameRead.Read.named("ReadNumbers")
 *                        .from("gs://my_bucket/path/to/numbers-*.txt")
 *                        .withCoder(TextualIntegerCoder.of()));
 * }</pre>
 *
 * <h3>Permissions</h3>
 * <p>When run using the {@link DirectPipelineRunner}, your pipeline can read and write text files
 * on your local drive and remote text files on Google Cloud Storage that you have access to using
 * your {@code gcloud} credentials. When running in the Dataflow service using
 * {@link DataflowPipelineRunner}, the pipeline can only read and write files from GCS. For more
 * information about permissions, see the Cloud Dataflow documentation on
 * <a href="https://cloud.google.com/dataflow/security-and-permissions">Security and
 * Permissions</a>.
 */
public class TextWithFilenameRead {
    /** The default coder, which returns each line of the input file as a string. */
    public static final Coder<String> DEFAULT_TEXT_CODER = StringUtf8Coder.of();

    /**
     * A {@link PTransform} that reads from a text file (or multiple text
     * files matching a pattern) and returns a {@link PCollection} containing
     * the decoding of each of the lines of the text file(s). The
     * default decoding just returns each line as a {@link String}, but you may call
     * {@link #withCoder(Coder)} to change the return type.
     */
    public static class Read {
        /**
         * Returns a transform for reading text files that uses the given step name.
         */
        public static Bound<String> named(String name) {
            return new Bound<>(DEFAULT_TEXT_CODER).named(name);
        }

        /**
         * Returns a transform for reading text files that reads from the file(s)
         * with the given filename or filename pattern. This can be a local path (if running locally),
         * or a Google Cloud Storage filename or filename pattern of the form
         * {@code "gs://<bucket>/<filepath>"} (if running locally or via the Google Cloud Dataflow
         * service). Standard <a href="http://docs.oracle.com/javase/tutorial/essential/io/find.html"
         * >Java Filesystem glob patterns</a> ("*", "?", "[..]") are supported.
         */
        public static Bound<String> from(String filepattern) {
            return new Bound<>(DEFAULT_TEXT_CODER).from(filepattern);
        }

        /**
         * Returns a transform for reading text files that uses the given
         * {@code Coder<T>} to decode each of the lines of the file into a
         * value of type {@code T}.
         *
         * <p>By default, uses {@link StringUtf8Coder}, which just
         * returns the text lines as Java strings.
         *
         * @param <T> the type of the decoded elements, and the elements
         * of the resulting PCollection
         */
        public static <T> Bound<T> withCoder(Coder<T> coder) {
            return new Bound<>(coder);
        }

        /**
         * Returns a transform for reading text files that has GCS path validation on
         * pipeline creation disabled.
         *
         * <p>This can be useful in the case where the GCS input does not
         * exist at the pipeline creation time, but is expected to be
         * available at execution time.
         */
        public static Bound<String> withoutValidation() {
            return new Bound<>(DEFAULT_TEXT_CODER).withoutValidation();
        }

        /**
         * Returns a transform for reading text files that decompresses all input files
         * using the specified compression type.
         *
         * <p>If no compression type is specified, the default is {@link TextWithFilenameRead.CompressionType#AUTO}.
         * In this mode, the compression type of the file is determined by its extension
         * (e.g., {@code *.gz} is gzipped, {@code *.bz2} is bzipped, and all other extensions are
         * uncompressed).
         */
        public static Bound<String> withCompressionType(TextWithFilenameRead.CompressionType compressionType) {
            return new Bound<>(DEFAULT_TEXT_CODER).withCompressionType(compressionType);
        }

        // TODO: strippingNewlines, etc.

        /**
         * A {@link PTransform} that reads from one or more text files and returns a bounded
         * {@link PCollection} containing one element for each line of the input files.
         *
         * @param <T> the type of each of the elements of the resulting
         * {@link PCollection}. By default, each line is returned as a {@code KV<String, String>}, where
         * the key is the filename. However you may use {@link #withCoder(Coder)} to supply a
         * {@code Coder<T>} to produce a {@code PCollection<KV<String, T>>} instead.
         */
        public static class Bound<T> extends PTransform<PInput, PCollection<KV<String, T>>> {
            /** The filepattern to read from. */
            @Nullable private final String filepattern;

            /** The Coder to use to decode each line. */
            private final Coder<T> coder;

            /** An option to indicate if input validation is desired. Default is true. */
            private final boolean validate;

            /** Option to indicate the input source's compression type. Default is AUTO. */
            private final TextWithFilenameRead.CompressionType compressionType;

            Bound(Coder<T> coder) {
                this(null, null, coder, true, TextWithFilenameRead.CompressionType.AUTO);
            }

            private Bound(String name, String filepattern, Coder<T> coder, boolean validate,
                          TextWithFilenameRead.CompressionType compressionType) {
                super(name);
                this.coder = coder;
                this.filepattern = filepattern;
                this.validate = validate;
                this.compressionType = compressionType;
            }

            /**
             * Returns a new transform for reading from text files that's like this one but
             * with the given step name.
             *
             * <p>Does not modify this object.
             */
            public Bound<T> named(String name) {
                return new Bound<>(name, filepattern, coder, validate, compressionType);
            }

            /**
             * Returns a new transform for reading from text files that's like this one but that reads
             * from the file(s) with the given name or pattern. See {@link TextWithFilenameRead.Read#from}
             * for a description of filepatterns.
             *
             * <p>Does not modify this object.

             */
            public Bound<T> from(String filepattern) {
                return new Bound<>(name, filepattern, coder, validate, compressionType);
            }

            /**
             * Returns a new transform for reading from text files that's like this one but
             * that uses the given {@link Coder Coder<X>} to decode each of the
             * lines of the file into a value of type {@code X}.
             *
             * <p>Does not modify this object.
             *
             * @param <X> the type of the decoded elements, and the
             * elements of the resulting PCollection
             */
            public <X> Bound<X> withCoder(Coder<X> coder) {
                return new Bound<>(name, filepattern, coder, validate, compressionType);
            }

            /**
             * Returns a new transform for reading from text files that's like this one but
             * that has GCS path validation on pipeline creation disabled.
             *
             * <p>This can be useful in the case where the GCS input does not
             * exist at the pipeline creation time, but is expected to be
             * available at execution time.
             *
             * <p>Does not modify this object.
             */
            public Bound<T> withoutValidation() {
                return new Bound<>(name, filepattern, coder, false, compressionType);
            }

            /**
             * Returns a new transform for reading from text files that's like this one but
             * reads from input sources using the specified compression type.
             *
             * <p>If no compression type is specified, the default is
             * {@link TextWithFilenameRead.CompressionType#AUTO}. See
             * {@link TextWithFilenameRead.Read#withCompressionType} for more details.
             *
             * <p>Does not modify this object.
             */
            public Bound<T> withCompressionType(TextWithFilenameRead.CompressionType compressionType) {
                return new Bound<>(name, filepattern, coder, validate, compressionType);
            }

            @Override
            public PCollection<KV<String, T>> apply(PInput input) {
                if (filepattern == null) {
                    throw new IllegalStateException("need to set the filepattern of a TextWithFilename.Read transform");
                }

                if (validate) {
                    try {
                        checkState(
                                !IOChannelUtils.getFactory(filepattern).match(filepattern).isEmpty(),
                                "Unable to find any files matching %s",
                                filepattern);
                    } catch (IOException e) {
                        throw new IllegalStateException(
                                String.format("Failed to validate %s", filepattern), e);
                    }
                }

                // Create a source specific to the requested compression type.
                final Bounded<KV<String, T>> read;
                switch(compressionType) {
                    case UNCOMPRESSED:
                        read = com.google.cloud.dataflow.sdk.io.Read.from(
                                new TextSource<T>(filepattern, coder));
                        break;
                    case AUTO:
                        read = com.google.cloud.dataflow.sdk.io.Read.from(
                                CompressedSource.from(new TextSource<T>(filepattern, coder)));
                        break;
                    case BZIP2:
                        read = com.google.cloud.dataflow.sdk.io.Read.from(
                                CompressedSource.from(new TextSource<T>(filepattern, coder))
                                        .withDecompression(CompressedSource.CompressionMode.BZIP2));
                        break;
                    case GZIP:
                        read = com.google.cloud.dataflow.sdk.io.Read.from(
                                CompressedSource.from(new TextSource<T>(filepattern, coder))
                                        .withDecompression(CompressedSource.CompressionMode.GZIP));
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown compression mode: " + compressionType);
                }

                PCollection<KV<String, T>> pcol = input.getPipeline().apply("Read", read);
                // Honor the default output coder that would have been used by this PTransform.
                pcol.setCoder(getDefaultOutputCoder());
                return pcol;
            }

            @Override
            public void populateDisplayData(DisplayData.Builder builder) {
                super.populateDisplayData(builder);

                builder
                        .add(DisplayData.item("compressionType", compressionType.toString())
                                .withLabel("Compression Type"))
                        .addIfNotDefault(DisplayData.item("validation", validate)
                                .withLabel("Validation Enabled"), true)
                        .addIfNotNull(DisplayData.item("filePattern", filepattern)
                                .withLabel("File Pattern"));
            }

            @Override
            protected Coder<KV<String, T>> getDefaultOutputCoder() {
                return KvCoder.of(StringUtf8Coder.of(), coder);
            }

            public String getFilepattern() {
                return filepattern;
            }

            public boolean needsValidation() {
                return validate;
            }

            public TextWithFilenameRead.CompressionType getCompressionType() {
                return compressionType;
            }
        }

        /** Disallow construction of utility classes. */
        private Read() {}
    }


    /////////////////////////////////////////////////////////////////////////////

    /**
     * Possible text file compression types.
     */
    public static enum CompressionType {
        /**
         * Automatically determine the compression type based on filename extension.
         */
        AUTO(""),
        /**
         * Uncompressed (i.e., may be split).
         */
        UNCOMPRESSED(""),
        /**
         * GZipped.
         */
        GZIP(".gz"),
        /**
         * BZipped.
         */
        BZIP2(".bz2");

        private String filenameSuffix;

        private CompressionType(String suffix) {
            this.filenameSuffix = suffix;
        }

        /**
         * Determine if a given filename matches a compression type based on its extension.
         * @param filename the filename to match
         * @return true iff the filename ends with the compression type's known extension.
         */
        public boolean matches(String filename) {
            return filename.toLowerCase().endsWith(filenameSuffix.toLowerCase());
        }
    }

    // Pattern which matches old-style shard output patterns, which are now
    // disallowed.
    private static final Pattern SHARD_OUTPUT_PATTERN = Pattern.compile("@([0-9]+|\\*)");

    private static void validateOutputComponent(String partialFilePattern) {
        Preconditions.checkArgument(
                !SHARD_OUTPUT_PATTERN.matcher(partialFilePattern).find(),
                "Output name components are not allowed to contain @* or @N patterns: "
                        + partialFilePattern);
    }

    //////////////////////////////////////////////////////////////////////////////

    /** Disable construction of utility class. */
    private TextWithFilenameRead() {}

    /**
     * A {@link FileBasedSource} which can decode records delimited by new line characters.
     *
     * <p>This source splits the data into records using {@code UTF-8} {@code \n}, {@code \r}, or
     * {@code \r\n} as the delimiter. This source is not strict and supports decoding the last record
     * even if it is not delimited. Finally, no records are decoded if the stream is empty.
     *
     * <p>This source supports reading from any arbitrary byte position within the stream. If the
     * starting position is not {@code 0}, then bytes are skipped until the first delimiter is found
     * representing the beginning of the first record to be decoded.
     */
    @VisibleForTesting
    static class TextSource<T> extends FileBasedSource<KV<String, T>> {
        private final Coder<KV<String, T>> coder;
        /** The Coder to use to decode each line. */
        private final Coder<T> lineCoder;

        @VisibleForTesting
        TextSource(String fileSpec, Coder<T> coder) {
            super(fileSpec, 1L);
            this.lineCoder = coder;
            this.coder = KvCoder.of(StringUtf8Coder.of(), coder);
        }

        private TextSource(String fileName, long start, long end, Coder<T> coder) {
            super(fileName, 1L, start, end);
            this.lineCoder = coder;
            this.coder = KvCoder.of(StringUtf8Coder.of(), coder);
        }

        @Override
        protected TextSource<T> createForSubrangeOfFile(String fileName, long start, long end) {
            return new TextSource<>(fileName, start, end, lineCoder);
        }

        @Override
        protected TextReader<T> createSingleFileReader(PipelineOptions options) {
            return new TextReader<>(this);
        }

        @Override
        public boolean producesSortedKeys(PipelineOptions options) throws Exception {
            return false;
        }

        @Override
        public Coder<KV<String, T>> getDefaultOutputCoder() {
            return coder;
        }

        /**
         * A {@link FileBasedReader FileBasedReader}
         * which can decode records delimited by new line characters.
         *
         * See {@link TextSource} for further details.
         */
        @VisibleForTesting
        static class TextReader<T> extends FileBasedReader<KV<String, T>> {
            private static final int READ_BUFFER_SIZE = 8192;
            private final Coder<KV<String, T>> coder;
            private final Coder<T> lineCoder;
            private final ByteBuffer readBuffer = ByteBuffer.allocate(READ_BUFFER_SIZE);
            private ByteString buffer;
            private int startOfSeparatorInBuffer;
            private int endOfSeparatorInBuffer;
            private long startOfRecord;
            private volatile long startOfNextRecord;
            private volatile boolean eof;
            private volatile boolean elementIsPresent;
            private T currentValue;
            private ReadableByteChannel inChannel;

            private TextReader(TextSource<T> source) {
                super(source);
                coder = source.coder;
                lineCoder = source.lineCoder;
                buffer = ByteString.EMPTY;
            }

            @Override
            protected long getCurrentOffset() throws NoSuchElementException {
                if (!elementIsPresent) {
                    throw new NoSuchElementException();
                }
                return startOfRecord;
            }

            @Override
            public long getSplitPointsRemaining() {
                if (isStarted() && startOfNextRecord >= getCurrentSource().getEndOffset()) {
                    return isDone() ? 0 : 1;
                }
                return super.getSplitPointsRemaining();
            }

            @Override
            public KV<String, T> getCurrent() throws NoSuchElementException {
                if (!elementIsPresent) {
                    throw new NoSuchElementException();
                }
                return KV.of(getCurrentSource().getFileOrPatternSpec(), currentValue);
            }

            @Override
            protected void startReading(ReadableByteChannel channel) throws IOException {
                this.inChannel = channel;
                // If the first offset is greater than zero, we need to skip bytes until we see our
                // first separator.
                if (getCurrentSource().getStartOffset() > 0) {
                    checkState(channel instanceof SeekableByteChannel,
                            "%s only supports reading from a SeekableByteChannel when given a start offset"
                                    + " greater than 0.", TextSource.class.getSimpleName());
                    long requiredPosition = getCurrentSource().getStartOffset() - 1;
                    ((SeekableByteChannel) channel).position(requiredPosition);
                    findSeparatorBounds();
                    buffer = buffer.substring(endOfSeparatorInBuffer);
                    startOfNextRecord = requiredPosition + endOfSeparatorInBuffer;
                    endOfSeparatorInBuffer = 0;
                    startOfSeparatorInBuffer = 0;
                }
            }

            /**
             * Locates the start position and end position of the next delimiter. Will
             * consume the channel till either EOF or the delimiter bounds are found.
             *
             * <p>This fills the buffer and updates the positions as follows:
             * <pre>{@code
             * ------------------------------------------------------
             * | element bytes | delimiter bytes | unconsumed bytes |
             * ------------------------------------------------------
             * 0            start of          end of              buffer
             *              separator         separator           size
             *              in buffer         in buffer
             * }</pre>
             */
            private void findSeparatorBounds() throws IOException {
                int bytePositionInBuffer = 0;
                while (true) {
                    if (!tryToEnsureNumberOfBytesInBuffer(bytePositionInBuffer + 1)) {
                        startOfSeparatorInBuffer = endOfSeparatorInBuffer = bytePositionInBuffer;
                        break;
                    }

                    byte currentByte = buffer.byteAt(bytePositionInBuffer);

                    if (currentByte == '\n') {
                        startOfSeparatorInBuffer = bytePositionInBuffer;
                        endOfSeparatorInBuffer = startOfSeparatorInBuffer + 1;
                        break;
                    } else if (currentByte == '\r') {
                        startOfSeparatorInBuffer = bytePositionInBuffer;
                        endOfSeparatorInBuffer = startOfSeparatorInBuffer + 1;

                        if (tryToEnsureNumberOfBytesInBuffer(bytePositionInBuffer + 2)) {
                            currentByte = buffer.byteAt(bytePositionInBuffer + 1);
                            if (currentByte == '\n') {
                                endOfSeparatorInBuffer += 1;
                            }
                        }
                        break;
                    }

                    // Move to the next byte in buffer.
                    bytePositionInBuffer += 1;
                }
            }

            @Override
            protected boolean readNextRecord() throws IOException {
                startOfRecord = startOfNextRecord;
                findSeparatorBounds();

                // If we have reached EOF file and consumed all of the buffer then we know
                // that there are no more records.
                if (eof && buffer.size() == 0) {
                    elementIsPresent = false;
                    return false;
                }

                decodeCurrentElement();
                startOfNextRecord = startOfRecord + endOfSeparatorInBuffer;
                return true;
            }

            /**
             * Decodes the current element updating the buffer to only contain the unconsumed bytes.
             *
             * This invalidates the currently stored {@code startOfSeparatorInBuffer} and
             * {@code endOfSeparatorInBuffer}.
             */
            private void decodeCurrentElement() throws IOException {
                ByteString dataToDecode = buffer.substring(0, startOfSeparatorInBuffer);
                currentValue = lineCoder.decode(dataToDecode.newInput(), Context.OUTER);
                elementIsPresent = true;
                buffer = buffer.substring(endOfSeparatorInBuffer);
            }

            /**
             * Returns false if we were unable to ensure the minimum capacity by consuming the channel.
             */
            private boolean tryToEnsureNumberOfBytesInBuffer(int minCapacity) throws IOException {
                // While we aren't at EOF or haven't fulfilled the minimum buffer capacity,
                // attempt to read more bytes.
                while (buffer.size() <= minCapacity && !eof) {
                    eof = inChannel.read(readBuffer) == -1;
                    readBuffer.flip();
                    buffer = buffer.concat(ByteString.copyFrom(readBuffer));
                    readBuffer.clear();
                }
                // Return true if we were able to honor the minimum buffer capacity request
                return buffer.size() >= minCapacity;
            }
        }
    }

}

