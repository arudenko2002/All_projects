mvn package
java -cp target/SwiftTrendSubscriptions-0.1.jar TrackAction.TrackActionSubscription
java -cp target/SwiftTrendSubscriptions-0.1.jar TrackAction.SendTrackAction
