# swift-trends-alert-query
Run BQ Query per User's Subscribed Playlist to Alert Users for Changes
