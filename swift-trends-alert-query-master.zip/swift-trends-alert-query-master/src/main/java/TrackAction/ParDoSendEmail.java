package TrackAction;

import org.apache.beam.sdk.transforms.DoFn;
import org.json.JSONObject;

public class ParDoSendEmail  extends DoFn<String,String> {
    String whom = "justtome";
    Boolean gmail = true;
    Boolean alsome = true;
    String dividor="&&&";
    SSLEmail ssle=null;

    public ParDoSendEmail(String whom, Boolean gmail, Boolean alsome) throws Exception {
        this.whom = whom;
        this.gmail = gmail;
        this.alsome = alsome;
    }

    @ProcessElement
    public void processElement(ProcessContext c) throws Exception {
        String line = c.element();
        String[] lines = line.split(dividor);
        JsonToHTML jth = new JsonToHTML();
        jth.prepTemplate(jth.readTemplateFile());
        SSLEmail ssle = new SSLEmail();
        for (int i = 0; i < lines.length; i++) {
            JSONObject user = new JSONObject(line);
            String to = user.getString("email");
            String reportdate = user.getString("reportdate");
            String subject = "Track Activity Report";
            String body = jth.processJson(user, reportdate);
            Thread.sleep(10000);
            if (gmail) {
                ssle.sendMail(to, subject, body, whom);
                if (alsome)
                    ssle.sendMail("alexey.rudenko@umusic.com", subject, body, "justtome");
            } else {
                ssle.sendUMGMail(to, subject, body, whom);
                if (alsome)
                    ssle.sendUMGMail("alexey.rudenko@umusic.com", subject, body, "justtome");
            }
            System.out.println("EMAIL SENT");
            c.output(line);
        }
    }
}
