bq load metadata.playlist_geography ~/Downloads/Playlist_Geography_Transition.csv playlist_uri:string,old_playlist_uri:string,country:string
