docker-compose -f docker-compose-CeleryExecutor-version-1-8-1-custom.yml up
docker-compose -f docker-compose-CeleryExecutor-version-1-8-1-custom.yml down
docker-compose -f docker-compose-CeleryExecutor-version-1-8-1-custom.yml up -d
